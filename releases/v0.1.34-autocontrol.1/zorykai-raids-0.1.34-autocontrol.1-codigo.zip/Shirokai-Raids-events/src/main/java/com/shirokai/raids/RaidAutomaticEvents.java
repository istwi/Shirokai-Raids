package com.shirokai.raids;

import java.util.*;
import org.slf4j.LoggerFactory;

/** One durable opportunity per eligible victory, after capture/returns. Never a per-tick chance roll. */
final class RaidAutomaticEvents {
    static final List<String> IDS=List.of("shiny","ivs","drop","token","invasao","elemental","votacao","enfurecido","dupla");
    static final class Rule {
        boolean enabled=true;
        int weight=1;
        Double value;
        List<String> types,candidates;
    }
    static final class Config {
        boolean enabled=true;
        double chancePercent=1;
        int maximumWaitMinutes=30;
        Map<String,Rule> events=defaults();
        void validate(){
            require(Double.isFinite(chancePercent)&&chancePercent>=0&&chancePercent<=100,"automatic.chancePercent deve ser 0–100 (1 significa 1%)");
            require(maximumWaitMinutes>=1&&maximumWaitMinutes<=120,"automatic.maximumWaitMinutes deve ser 1–120");
            require(events!=null&&IDS.containsAll(events.keySet()),"Evento automático desconhecido");
            for(var e:events.entrySet()){
                var r=e.getValue();require(r!=null&&r.weight>=1&&r.weight<=10000,"Peso automático inválido: "+e.getKey());
                if(!r.enabled)continue;
                switch(e.getKey()){
                    case "shiny"->require(number(r.value,0,100),"Valor de Sorte Shiny deve ser 0–100%");
                    case "ivs"->require(number(r.value,1,6)&&r.value==Math.rint(r.value),"Valor de IVs Perfeitos deve ser inteiro de 1–6");
                    case "drop","token"->require(number(r.value,1,10),"Multiplicador automático deve ser 1–10");
                    case "elemental"->{require(r.types!=null&&!r.types.isEmpty()&&r.types.size()<=36,"Lista de tipos automática inválida");for(var t:r.types){require(t!=null,"Tipo automático ausente");RaidEvents.element(t);}}
                    case "votacao"->{require(r.candidates!=null&&r.candidates.size()<=256,"Lista de espécies da votação inválida");for(var id:r.candidates)require(id!=null&&id.matches("(?:[a-z0-9_.-]+:)?[a-z0-9_./-]+"),"Espécie automática inválida");}
                }
            }
        }
    }
    static final class State {
        String pendingRaid="",lastProcessedRaid="",lastResult="";
        long pendingAt;
        Config snapshot;
        void validate(){require(pendingRaid!=null&&lastProcessedRaid!=null&&lastResult!=null&&lastResult.length()<=1000&&pendingAt>=0,"Estado automático inválido");if(!pendingRaid.isEmpty()){UUID.fromString(pendingRaid);require(snapshot!=null,"Snapshot automático ausente");snapshot.validate();}if(!lastProcessedRaid.isEmpty())UUID.fromString(lastProcessedRaid);}
    }
    static Map<String,Rule> defaults(){
        var result=new LinkedHashMap<String,Rule>();for(var id:IDS){var rule=new Rule();switch(id){case "shiny"->rule.value=10d;case "ivs"->rule.value=3d;case "drop","token"->rule.value=2d;case "elemental"->rule.types=new ArrayList<>(new TreeSet<>(RaidEvents.TYPES));case "votacao"->rule.candidates=new ArrayList<>();}result.put(id,rule);}return result;
    }
    static boolean succeeds(double chance,Random random){return random.nextDouble()<chance/100d;}
    static String choose(Map<String,Rule> rules,Random random){int total=rules.values().stream().filter(r->r.enabled).mapToInt(r->r.weight).sum();if(total==0)return null;int roll=random.nextInt(total);for(var id:IDS){var r=rules.get(id);if(r!=null&&r.enabled){roll-=r.weight;if(roll<0)return id;}}throw new IllegalStateException("Sorteio de evento sem candidato");}
    static void finished(ShirokaiRaids mod,RaidArchive.Outcome outcome,Config config){
        var active=RaidEvents.get(mod,"active");if(active==null||!Set.of(RaidArchive.Outcome.VICTORY,RaidArchive.Outcome.TIMEOUT).contains(outcome)||!config.enabled)return;
        var boss=(RaidConfig.Boss)RaidEvents.get(active,"definition");if(boss.event!=null&&boss.event.duo&&boss.event.stage==1&&outcome==RaidArchive.Outcome.VICTORY)return;
        var damage=(com.shirokai.raids.core.RaidDamageTracker)RaidEvents.get(active,"damage");if(damage.ranking().stream().noneMatch(p->p.damage()>0))return;
        var auto=RaidEvents.state(mod).events.automatic;String id=(String)RaidEvents.get(active,"id");if(id.equals(auto.lastProcessedRaid)||id.equals(auto.pendingRaid))return;
        auto.pendingRaid=id;auto.pendingAt=System.currentTimeMillis();auto.snapshot=JsonFiles.copy(config,Config.class);
    }
    static void consumedByNewRaid(ShirokaiRaids mod){var a=RaidEvents.state(mod).events.automatic;if(!a.pendingRaid.isEmpty())complete(a,"Outra raid começou antes da oportunidade automática");}
    static void cancelPending(State a){if(!a.pendingRaid.isEmpty())complete(a,"Oportunidade cancelada pelo staff");}
    private static void complete(State a,String result){a.lastProcessedRaid=a.pendingRaid;a.pendingRaid="";a.pendingAt=0;a.snapshot=null;a.lastResult=result;}
    static void process(ShirokaiRaids mod,long now,Config current){
        var e=RaidEvents.state(mod).events;var auto=e.automatic;if(auto.pendingRaid.isEmpty())return;
        if(!current.enabled||current.chancePercent==0){complete(auto,"Automático desativado ou chance zerada");RaidEvents.save(mod);return;}
        if(e.next.configured()||e.vote!=null||e.second!=null||!e.chainRaid.isEmpty()){complete(auto,"Programação manual/sequência preservada");RaidEvents.save(mod);return;}
        if(RaidEvents.get(mod,"active")!=null){complete(auto,"Próxima raid já iniciada");RaidEvents.save(mod);return;}
        if(now-auto.pendingAt>auto.snapshot.maximumWaitMinutes*60_000L){complete(auto,"Espera máxima por capturas/retornos excedida");RaidEvents.save(mod);return;}
        if(!RaidEvents.safe(mod,now))return;
        var uuid=UUID.fromString(auto.pendingRaid);var random=new Random(uuid.getMostSignificantBits()^uuid.getLeastSignificantBits()^0x415243455553L);
        if(!succeeds(auto.snapshot.chancePercent,random)){complete(auto,"Sem evento neste sorteio");RaidEvents.save(mod);return;}
        var candidates=new LinkedHashMap<>(auto.snapshot.events);candidates.entrySet().removeIf(entry->current.events.get(entry.getKey())==null||!current.events.get(entry.getKey()).enabled);RaidEventPlan chosen=null;RaidEventState.Vote vote=null;String selected=null;
        while((selected=choose(candidates,random))!=null){
            try{
                var rule=candidates.get(selected);var plan=plan(selected,rule,random.nextLong());
                if(selected.equals("elemental")){
                    var types=new ArrayList<>(rule.types);Collections.shuffle(types,random);boolean valid=false;
                    for(var type:types){plan.element=RaidEvents.element(type);try{RaidEvents.select(mod,plan);valid=true;break;}catch(IllegalStateException|IllegalArgumentException unavailable){}}
                    if(!valid)throw new IllegalStateException("Nenhum tipo elegível");
                }else if(selected.equals("votacao")){
                    var catalog=(RaidCatalogSettings)RaidEvents.get(mod,"catalogSettings");var pool=RaidCatalogPokemon.species(catalog).stream().filter(s->RaidAutomaticCatalog.eligible(s,catalog)).filter(s->catalog.difficultyWeights.get(RaidAutomaticCatalog.difficulty(s))>0).map(RaidAutomaticCatalog.Species::id).sorted().toList();
                    var allowed=new HashSet<String>();for(var id:rule.candidates)allowed.add(id.contains(":")?id:"cobblemon:"+id);
                    var options=new ArrayList<>(pool.stream().filter(id->allowed.isEmpty()||allowed.contains(id)).toList());Collections.shuffle(options,random);
                    if(options.size()<2)throw new IllegalStateException("Votação exige duas espécies elegíveis");
                    vote=new RaidEventState.Vote();vote.options=new ArrayList<>(options.subList(0,Math.min(3,options.size())));vote.ends=now+RaidEvents.voteSeconds()*1000L;
                }else RaidEvents.select(mod,plan);
                var rewards=(RaidRewardSettings)RaidEvents.get(mod,"rewardSettings");if(!rewards.integrations.enabled&&(plan.drop!=1||plan.tokens!=1||plan.rage))throw new IllegalStateException("Recompensas modulares desativadas");
                chosen=plan;break;
            }catch(IllegalArgumentException|IllegalStateException invalid){candidates.remove(selected);vote=null;}
        }
        if(chosen==null){complete(auto,"Nenhum evento habilitado e elegível");RaidEvents.save(mod);return;}
        e.next=chosen;e.vote=vote;String name=RaidEvents.eventName(selected);complete(auto,"Evento selecionado: "+name);RaidEvents.save(mod);
        // Broadcast only after durable reservation. Never restart a draw to repeat this message.
        if(vote!=null)RaidEvents.announce("Arceus ouviu os treinadores! &eVoz dos Treinadores&f aberta para a próxima raid. Use &e/raid votar&f.");
        else RaidEvents.announce("Arceus sorriu para os treinadores! A próxima raid terá &e"+name+"&f.");
    }
    static RaidEventPlan plan(String id,Rule rule,long seed){
        var p=new RaidEventPlan();p.seed=seed;switch(id){case "shiny"->p.shiny=rule.value/100;case "ivs"->p.perfectIvs=rule.value.intValue();case "drop"->p.drop=rule.value;case "token"->p.tokens=rule.value;case "invasao"->p.invasion=true;case "enfurecido"->p.rage=true;case "dupla"->{p.duo=true;p.chainId=UUID.nameUUIDFromBytes(("auto-duo:"+seed).getBytes(java.nio.charset.StandardCharsets.UTF_8)).toString();}case "elemental","votacao"->{}default->throw new IllegalArgumentException("Evento automático desconhecido");}p.validate();return p;
    }
    static String status(Config config){var names=new ArrayList<String>();for(var id:IDS){var r=config.events.get(id);if(r!=null&&r.enabled)names.add(RaidEvents.eventName(id));}return "Automático: "+(config.enabled?"ligado":"desligado")+" | chance: "+config.chancePercent+"% por encerramento | lista: "+String.join(", ",names);}
    private static boolean number(Double n,double min,double max){return n!=null&&Double.isFinite(n)&&n>=min&&n<=max;}
    private static void require(boolean value,String reason){if(!value)throw new IllegalArgumentException(reason);}
}
