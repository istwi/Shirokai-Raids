package com.shirokai.raids;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.tree.CommandNode;
import net.minecraft.commands.*;
import java.util.*;

/** Typed command tree: admin branches are never sent to ordinary players. */
final class RaidEventCommands {
    private static final List<String> EVENTS=List.of("shiny","ivs","drop","token","invasao","elemental","votacao","enfurecido","dupla","automatico","cancelar","reload");
    static void register(CommandDispatcher<CommandSourceStack> dispatcher){
        var admin=Commands.literal("raidadmin").requires(RaidEventCommands::admin);
        // Replace only the old iniciar branch, otherwise Brigadier keeps its old suggestion provider.
        var parent=dispatcher.getRoot().getChild("raidadmin");
        if(parent!=null)for(var field:List.of("children","literals","arguments"))try{var f=CommandNode.class.getDeclaredField(field);f.setAccessible(true);((Map<?,?>)f.get(parent)).remove("iniciar");}catch(ReflectiveOperationException error){throw new IllegalStateException("Não foi possível atualizar /raidadmin iniciar",error);}
        admin.then(Commands.literal("iniciar").executes(c->run(c.getSource(),"iniciar",""))
            .then(Commands.argument("boss",StringArgumentType.word()).suggests((c,b)->SharedSuggestionProvider.suggest(startOptions(),b)).executes(c->run(c.getSource(),"iniciar",StringArgumentType.getString(c,"boss")))));
        admin.then(Commands.literal("proxima").then(Commands.argument("raridade",StringArgumentType.word()).suggests((c,b)->SharedSuggestionProvider.suggest(rarities(),b)).executes(c->run(c.getSource(),"proxima",StringArgumentType.getString(c,"raridade")))));
        admin.then(Commands.literal("eventos").executes(c->run(c.getSource(),"eventos","")));
        var event=Commands.literal("evento").executes(c->{c.getSource().sendSuccess(()->RaidEvents.text("Eventos: &e"+String.join("&7, &e",EVENTS)+"&f. Use TAB para escolher e ver os parâmetros."),false);return 1;});
        var automatic=Commands.literal("automatico").executes(c->run(c.getSource(),"automatico","status"));
        for(var operation:List.of("pausar","ligar","status"))automatic.then(Commands.literal(operation).executes(c->run(c.getSource(),"automatico",operation)));
        event.then(automatic);
        event.then(value("shiny","chance",List.of("1%","5%","10%","25%","50%","100%")));
        event.then(value("ivs","quantidade",List.of("1","2","3","4","5","6")));
        event.then(value("drop","multiplicador",List.of("1","1.5","2","3","5","10")));
        event.then(value("token","multiplicador",List.of("1","1.5","2","3","5","10")));
        var types=new TreeSet<String>(RaidEvents.TYPES);types.addAll(List.of("fogo","agua","eletrico","planta","gelo","lutador","venenoso","terra","voador","psiquico","inseto","pedra","fantasma","dragao","sombrio","aco","fada"));
        event.then(value("elemental","tipo",types));
        for(var name:List.of("invasao","enfurecido","cancelar","reload"))event.then(Commands.literal(name).executes(c->run(c.getSource(),"evento",name)));
        event.then(Commands.literal("dupla").executes(c->run(c.getSource(),"evento","dupla"))
            .then(Commands.argument("primeira",StringArgumentType.word()).suggests((c,b)->SharedSuggestionProvider.suggest(rarities(),b))
                .then(Commands.argument("segunda",StringArgumentType.word()).suggests((c,b)->SharedSuggestionProvider.suggest(rarities(),b))
                    .executes(c->run(c.getSource(),"evento","dupla "+StringArgumentType.getString(c,"primeira")+" "+StringArgumentType.getString(c,"segunda"))))));
        event.then(Commands.literal("votacao").then(Commands.argument("primeiro",ResourceLocationArgument.id()).suggests((c,b)->SharedSuggestionProvider.suggest(species(),b))
            .then(Commands.argument("segundo",ResourceLocationArgument.id()).suggests((c,b)->SharedSuggestionProvider.suggest(species().stream().filter(s->!s.equals(speciesArg(c,"primeiro"))).toList(),b))
                .executes(c->run(c.getSource(),"evento","votacao "+speciesArg(c,"primeiro")+" "+speciesArg(c,"segundo")))
                .then(Commands.argument("terceiro",ResourceLocationArgument.id()).suggests((c,b)->SharedSuggestionProvider.suggest(species().stream().filter(s->!s.equals(speciesArg(c,"primeiro"))&&!s.equals(speciesArg(c,"segundo"))).toList(),b))
                    .executes(c->run(c.getSource(),"evento","votacao "+speciesArg(c,"primeiro")+" "+speciesArg(c,"segundo")+" "+speciesArg(c,"terceiro")))))));
        admin.then(event);dispatcher.register(admin);
        dispatcher.register(Commands.literal("raid").then(Commands.literal("votar").executes(c->run(c.getSource(),"votar",""))
            .then(Commands.argument("numero",StringArgumentType.word()).suggests((c,b)->{var vote=RaidEvents.state(RaidEvents.mod()).events.vote;var options=new ArrayList<String>();if(vote!=null)for(int i=1;i<=vote.options.size();i++)options.add(Integer.toString(i));return SharedSuggestionProvider.suggest(options,b);}).executes(c->run(c.getSource(),"votar",StringArgumentType.getString(c,"numero"))))));
    }
    private static LiteralArgumentBuilder<CommandSourceStack> value(String event,String argument,Collection<String> examples){return Commands.literal(event).then(Commands.argument(argument,StringArgumentType.greedyString()).suggests((c,b)->SharedSuggestionProvider.suggest(examples,b)).executes(c->run(c.getSource(),"evento",event+" "+StringArgumentType.getString(c,argument))));}
    private static String speciesArg(CommandContext<CommandSourceStack> context,String name){return context.getNodes().stream().filter(n->n.getNode().getName().equals(name)).findFirst().orElseThrow().getRange().get(context.getInput());}
    private static boolean admin(CommandSourceStack source){return RaidPermissions.check(source,"shirokai.raids.admin",source.hasPermission(2));}
    private static int run(CommandSourceStack source,String action,String text){return RaidEvents.execute(source,action,text);}
    private static List<String> rarities(){var values=new ArrayList<>(RaidCatalogSettings.ORDER);values.add("aleatorio");return values;}
    private static Collection<String> startOptions(){var result=new TreeSet<>(rarities());var mod=RaidEvents.mod();if(mod!=null&&RaidEvents.get(mod,"bosses") instanceof Map<?,?> bosses)for(var id:bosses.keySet())result.add(id.toString());return result;}
    private static List<String> species(){var mod=RaidEvents.mod();if(mod==null)return List.of();var settings=(RaidCatalogSettings)RaidEvents.get(mod,"catalogSettings");var plan=RaidEvents.state(mod).events.next;return RaidCatalogPokemon.species(settings).stream().filter(s->RaidAutomaticCatalog.eligible(s,settings)).filter(s->plan.rarity.isEmpty()||RaidAutomaticCatalog.difficulty(s).equals(plan.rarity)).filter(s->!plan.invasion||Set.of("lendario","supremo").contains(RaidAutomaticCatalog.difficulty(s))).filter(s->RaidEvents.matchesElement(s.id(),plan.element)).map(s->s.id().startsWith("cobblemon:")?s.id().substring(10):s.id()).sorted().toList();}
}
