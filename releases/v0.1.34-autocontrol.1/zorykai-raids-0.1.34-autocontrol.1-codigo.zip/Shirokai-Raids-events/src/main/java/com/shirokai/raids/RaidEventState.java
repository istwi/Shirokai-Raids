package com.shirokai.raids;

import java.util.*;

final class RaidEventState {
    RaidEventPlan next=new RaidEventPlan();
    RaidAutomaticEvents.State automatic=new RaidAutomaticEvents.State();
    String chainRaid="";
    RaidEventPlan second;
    long safeSince,waitingSince;
    Vote vote;
    static final class Vote {List<String> options=new ArrayList<>();Map<String,Integer> votes=new HashMap<>();Map<String,Long> lastVotes=new HashMap<>();long ends;}
    void validate(){
        if(automatic==null)throw new IllegalArgumentException("Estado de automação ausente");automatic.validate();
        if(next==null)throw new IllegalArgumentException("Plano de eventos ausente");next.validate();
        if(second!=null)second.validate();
        if(chainRaid==null||safeSince<0||waitingSince<0)throw new IllegalArgumentException("Cadeia de eventos inválida");
        if(!chainRaid.isEmpty())UUID.fromString(chainRaid);
        if(vote!=null){if(vote.options==null||vote.options.size()<2||vote.options.size()>3||vote.votes==null||vote.lastVotes==null||vote.ends<=0)throw new IllegalArgumentException("Votação inválida");for(var id:vote.options)if(id==null||!id.matches("[a-z0-9_.-]+:[a-z0-9_./-]+"))throw new IllegalArgumentException("Opção inválida");for(var entry:vote.lastVotes.entrySet()){UUID.fromString(entry.getKey());if(entry.getValue()==null||entry.getValue()<0)throw new IllegalArgumentException("Intervalo de voto inválido");}for(var e:vote.votes.entrySet()){UUID.fromString(e.getKey());if(e.getValue()==null||e.getValue()<0||e.getValue()>=vote.options.size())throw new IllegalArgumentException("Voto inválido");}}
    }
}
