package com.shirokai.raids;

import static com.shirokai.raids.RaidMessages.msg;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.ItemLore;
import java.time.ZoneId;
import java.util.*;
import java.util.function.BooleanSupplier;

/** Unified, read-only projection of existing reservations. Clicking cannot manufacture items. */
final class PendingRewardMenu extends ChestMenu {
    private final ServerPlayer viewer;
    private final RaidState state;
    private final ZoneId zone;
    private final int page,pages;
    private final BooleanSupplier available;
    private final Runnable attempt;
    private final List<Entry> entries;
    private record Entry(RaidState.Pending legacy,RaidRewardJournal.Grant modular){}
    static boolean allowed(ServerPlayer player){var source=player.createCommandSourceStack();return RaidPermissions.check(source,"shirokai.raids.use",true)&&RaidPermissions.check(source,"shirokai.raids.rewards",true);}
    static void open(ServerPlayer player,RaidState state,ZoneId zone,int requestedPage,BooleanSupplier available,Runnable attempt){
        if(!available.getAsBoolean()||!allowed(player))return;
        var entries=new ArrayList<Entry>();String owner=player.getUUID().toString();
        state.pending.getOrDefault(owner,List.of()).forEach(p->entries.add(new Entry(p,null)));
        state.deliveries.values().stream().filter(d->d.player.equals(owner)).forEach(d->entries.add(new Entry(d.reward,null)));
        state.modularRewards.grants.values().stream().filter(g->g.player.equals(owner)&&g.status!=RaidRewardJournal.Status.DONE&&g.status!=RaidRewardJournal.Status.SKIPPED).forEach(g->entries.add(new Entry(null,g)));
        int pages=Math.max(1,(entries.size()+17)/18),page=Math.max(0,Math.min(pages-1,requestedPage));
        player.openMenu(new SimpleMenuProvider((id,inventory,p)->new PendingRewardMenu(id,player,state,zone,page,pages,available,attempt,entries),Component.literal("Recompensas pendentes · "+(page+1)+"/"+pages)));
    }
    private PendingRewardMenu(int id,ServerPlayer player,RaidState state,ZoneId zone,int page,int pages,BooleanSupplier available,Runnable attempt,List<Entry> entries){
        super(MenuType.GENERIC_9x3,id,player.getInventory(),new SimpleContainer(27),3);
        viewer=player;this.state=state;this.zone=zone;this.page=page;this.pages=pages;this.available=available;this.attempt=attempt;this.entries=List.copyOf(entries);
        for(int i=0;i<18&&page*18+i<entries.size();i++){
            var entry=entries.get(page*18+i);var lore=new ArrayList<Component>();ItemStack stack;
            if(entry.modular!=null){
                var grant=entry.modular;String reference=grant.choice.reward.reference,type=grant.choice.reward.type;
                stack=new ItemStack(item(type,reference));String label=type.equals("item")?stack.getHoverName().getString():ShirokaiRaids.rewardName(type,reference);
                stack.set(DataComponents.CUSTOM_NAME,Component.literal(label+" ×"+grant.choice.amount.toPlainString()));
                lore.add(Component.literal("Categoria: "+(grant.scope.equals("special")?"TOP 3":"Geral")));
                lore.add(Component.literal("Estado: "+switch(grant.status){case PENDING->"Pendente";case IN_FLIGHT->"Em processamento";case UNCERTAIN->"Em conferência";default->grant.status.toString();}));
                lore.add(Component.literal(RaidRewardDispatch.reason(state,player,grant)));
                lore.add(Component.literal("Prêmio: "+reference));lore.add(Component.literal("Raid: "+grant.raid));lore.add(Component.literal("Transação: "+grant.id));
            }else{
                var reward=entry.legacy;stack=new ItemStack(item("item",reward.item));
                lore.add(Component.literal("Quantidade pendente: "+reward.count));lore.add(Component.literal("Raid: "+reward.raid));
                lore.add(Component.literal(RaidInventory.locked(player)?"Finalize a captura e saia da raid":"Entrega sujeita a espaço e confirmação do recibo"));
                lore.add(Component.literal("Prêmio: "+reward.item));
            }
            lore.add(Component.literal("Clique no prêmio para resgatar, ou use o botão de resgate."));stack.set(DataComponents.LORE,new ItemLore(lore));getContainer().setItem(i,stack);
        }
        if(entries.isEmpty())getContainer().setItem(4,icon(Items.PAPER,"Nenhuma recompensa pendente"));
        if(page>0)getContainer().setItem(18,icon(Items.ARROW,msg("textos.pagina_anterior")));
        getContainer().setItem(19,icon(Items.BOOK,msg("textos.historico_pessoal")));getContainer().setItem(20,icon(Items.GOLD_INGOT,msg("textos.ranking_global")));
        getContainer().setItem(21,icon(Items.EMERALD,"Pendências: "+entries.size()));
        boolean claimable=entries.stream().anyMatch(e->e.legacy!=null||e.modular.status==RaidRewardJournal.Status.PENDING);
        getContainer().setItem(22,icon(!claimable||RaidInventory.locked(player)?Items.GRAY_DYE:Items.LIME_DYE,RaidInventory.locked(player)?"Saia da raid antes de receber itens":claimable?"Resgatar recompensas disponíveis":entries.isEmpty()?"Nenhuma recompensa para resgatar":"Pendências em conferência; contate a administração"));
        getContainer().setItem(23,icon(Items.CLOCK,"Atualizar lista e situação das entregas"));
        getContainer().setItem(24,icon(Items.PAPER,"Sem espaço: preservado. Em conferência: contate a administração."));getContainer().setItem(25,icon(Items.BARRIER,msg("textos.fechar")));
        if(page+1<pages)getContainer().setItem(26,icon(Items.ARROW,msg("textos.proxima_pagina")));
    }
    private static Item item(String type,String reference){
        if(type.equals("item")){var key=ResourceLocation.tryParse(reference);if(key!=null&&BuiltInRegistries.ITEM.containsKey(key)){var item=BuiltInRegistries.ITEM.get(key);if(item!=Items.AIR)return item;}return Items.BARRIER;}
        return switch(type){case "currency"->reference.equals("impactor:tokens")?Items.AMETHYST_SHARD:Items.GOLD_INGOT;case "fragment"->Items.PRISMARINE_SHARD;case "title"->Items.NAME_TAG;case "particle"->Items.FIREWORK_STAR;default->Items.CHEST;};
    }
    private static ItemStack icon(Item item,String name){var stack=new ItemStack(item);stack.set(DataComponents.CUSTOM_NAME,Component.literal(name));return stack;}
    @Override public boolean stillValid(Player player){return player==viewer&&available.getAsBoolean()&&allowed(viewer);}
    @Override public ItemStack quickMoveStack(Player player,int slot){return ItemStack.EMPTY;}
    @Override public boolean canDragTo(Slot slot){return false;}
    @Override public void clicked(int slot,int button,ClickType type,Player player){
        if(player!=viewer||viewer.containerMenu!=this)return;
        if(!stillValid(player)){viewer.closeContainer();return;}
        if(type==ClickType.PICKUP&&button==0){
            if(slot>=0&&slot<18&&page*18+slot<entries.size()){var entry=entries.get(page*18+slot);if(entry.modular!=null){RaidRewardDispatch.requestOne(state,viewer,entry.modular.id);open(viewer,state,zone,page,available,attempt);return;}}
            if(slot==25){viewer.closeContainer();return;}
            if(slot==19||slot==20){RaidMenu.open(viewer,state,zone,slot==20,RaidArchive.Metric.PARTICIPATIONS,0,available);return;}
            if(slot==22){attempt.run();if(!available.getAsBoolean()){viewer.closeContainer();return;}}
            if(slot==22||slot==23||slot==18&&page>0||slot==26&&page+1<pages)open(viewer,state,zone,slot==18?page-1:slot==26?page+1:page,available,attempt);
        }
        broadcastFullState();
    }
}
