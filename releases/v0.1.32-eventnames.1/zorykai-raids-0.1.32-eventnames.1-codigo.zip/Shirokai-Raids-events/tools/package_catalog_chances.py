#!/usr/bin/env python3
"""Overlay only catalog settings/selection/UI onto the latest complete Zorykai binary."""
import argparse,hashlib,json,zipfile,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--java',required=True);p.add_argument('--tools-cp',required=True);p.add_argument('--candidate',required=True,type=Path);p.add_argument('--output',required=True,type=Path);p.add_argument('--version',required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[1];base=root/'releases/zorykai/v0.1.25-returnspawn.1/Zorykai-Raids-0.1.25-returnspawn.1-fabric-1.21.1.jar'
classes=('RaidCatalogSettings','RaidAutomaticCatalog','RaidSpecialMenu','ItemRaidRewards')
with zipfile.ZipFile(base) as old,zipfile.ZipFile(a.candidate) as candidate,tempfile.TemporaryDirectory() as work:
 replacements={n:candidate.read(n) for n in candidate.namelist() if n.endswith('.class') and any(n=='com/shirokai/raids/'+c+'.class' or n.startswith('com/shirokai/raids/'+c+'$') for c in classes)}
 assert all('com/shirokai/raids/'+c+'.class' in replacements for c in classes)
 main='com/shirokai/raids/ShirokaiRaids.class';b=Path(work)/'base';c=Path(work)/'candidate';out=Path(work)/'patched';b.write_bytes(old.read(main));c.write_bytes(candidate.read(main))
 subprocess.run([a.java,'-cp',a.tools_cp,'PatchCatalogMethods',str(b),str(c),str(out)],check=True);replacements[main]=out.read_bytes()
 metadata=json.loads(old.read('fabric.mod.json'));assert metadata['version']=='0.1.25-returnspawn.1' and metadata['name']=='Zorykai Raids';metadata['version']=a.version;replacements['fabric.mod.json']=(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n').encode()
 a.output.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(a.output,'w',zipfile.ZIP_DEFLATED) as target:
  for entry in old.infolist():target.writestr(entry,replacements.get(entry.filename,old.read(entry.filename)))
  for n in sorted(replacements.keys()-set(old.namelist())):target.writestr(n,replacements[n])
with zipfile.ZipFile(base) as old,zipfile.ZipFile(a.output) as new:
 assert new.testzip() is None and set(old.namelist())<=set(new.namelist())
 changed=[n for n in old.namelist() if old.read(n)!=new.read(n)];assert set(changed)<=set(replacements)
 preserved=['RaidAuthentication','GuardRaidAccess','RaidReturnPersistence','RaidReturnFallback','RaidCapture','RaidInventory','RaidQuizGuard','TraditionalRaidBattles','RaidRewardJournal']
 for name in preserved:assert old.read('com/shirokai/raids/'+name+'.class')==new.read('com/shirokai/raids/'+name+'.class')
report={'baseSHA256':hashlib.sha256(base.read_bytes()).hexdigest(),'artifactSHA256':hashlib.sha256(a.output.read_bytes()).hexdigest(),'changedEntries':changed,'preservedClasses':preserved,'version':a.version,'note':'Only specialProgress, catalogStatus and its two lambdas replaced in main class; startup now registers native item handler; return/capture/auth/combat/reward methods retained from latest complete 0.1.25.'}
a.output.with_suffix('.audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
