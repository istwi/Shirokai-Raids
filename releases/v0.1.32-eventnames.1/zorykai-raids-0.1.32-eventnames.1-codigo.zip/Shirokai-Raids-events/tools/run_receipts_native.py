from pathlib import Path
import json,shutil,zipfile,subprocess,os,urllib.parse,sys
repo=Path(__file__).resolve().parents[1];r=Path(sys.argv[1]);entry=sys.argv[2] if len(sys.argv)>2 else 'com.shirokai.raids.CatalogChancesIntegration';r.mkdir(exist_ok=False);base=Path('/workspace/shared/raids-test-server')
for n in ['server.jar','libraries','fabric-server-launch.jar']:(r/n).symlink_to(base/n,target_is_directory=(base/n).is_dir())
(r/'mods').mkdir()
for p in (base/'mods').glob('*.jar'):
 if not p.name.startswith('Shirokai-Raids-'):shutil.copy2(p,r/'mods'/p.name)
version=next(x.split('=',1)[1] for x in (repo/'gradle.properties').read_text().splitlines() if x.startswith('mod_version='))
shutil.copy2(repo/('build/libs/Zorykai-Raids-'+version+'-fabric-1.21.1.jar'),r/'mods/raids.jar')
with zipfile.ZipFile(repo/'build/integration/shirokai-raids-integration.jar') as z,zipfile.ZipFile(r/'mods/checks.jar','w',zipfile.ZIP_DEFLATED) as out:
 for n in z.namelist():
  data=z.read(n)
  if n=='fabric.mod.json':
   d=json.loads(data);d['entrypoints']['main']=[entry];d.pop('mixins',None);data=json.dumps(d).encode()
  out.writestr(n,data)
if entry.endswith('ItemRewardsIntegration'):
 with zipfile.ZipFile('/workspace/deliverables/raid-rewards-ajustadas/rewards-v2-ajustadas.zip') as z:
  fixture=r/'fixture-rewards';fixture.mkdir()
  for name in z.namelist():
   if name.endswith('.json'):(fixture/Path(name).name).write_bytes(z.read(name))
(r/'eula.txt').write_text('eula=true\n');(r/'server.properties').write_text('server-ip=127.0.0.1\nserver-port=PORT_PLACEHOLDER\nonline-mode=false\nenforce-secure-profile=false\nview-distance=2\nsimulation-distance=2\ngenerate-structures=false\nlevel-type=minecraft:flat\n')
cfg=r/'config/shirokai-raids';cfg.mkdir(parents=True);(r/'server.properties').write_text((r/'server.properties').read_text().replace('PORT_PLACEHOLDER',os.environ.get('RAID_TEST_PORT','25584')));(cfg/'config.json').write_text(json.dumps({'automaticRaids':False,'menuTimeZone':'America/Sao_Paulo'}))
jvm=[]
for scheme in ['http','https']:
 u=urllib.parse.urlsplit(os.environ.get(scheme.upper()+'_PROXY',''))
 if u.hostname:jvm+=['-D'+scheme+'.proxyHost='+u.hostname,'-D'+scheme+'.proxyPort='+str(u.port or 80)]
jvm+=['-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts','-Dhttp.nonProxyHosts=localhost|127.*|[::1]']
with (r/'server.log').open('w') as log:
 p=subprocess.Popen(['/workspace/shared/jdk/bin/java',*jvm,'-Xmx3G','-Xverify:all','-jar','fabric-server-launch.jar','nogui'],cwd=r,stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT)
 try:code=p.wait(timeout=200)
 finally:
  if p.poll() is None:p.terminate();p.wait(timeout=30)
print('exit',code)
if entry.endswith('CatalogChancesIntegration'):
 d=json.loads((r/'catalog-chances-results.json').read_text());print(json.dumps(d,indent=2));assert d['passed']

if entry.endswith('ItemRewardsIntegration'):
 d=json.loads((r/'item-rewards-results.json').read_text());print(json.dumps(d,indent=2));assert d['passed']

if entry.endswith('RewardRetryIntegration'):
 d=json.loads((r/'reward-retry-results.json').read_text());print(json.dumps(d,indent=2));assert d['passed']

if entry.endswith('ReceiptRecoveryIntegration'):
 d=json.loads((r/'receipt-recovery-results.json').read_text());print(json.dumps(d,indent=2));assert d['passed']

if entry.endswith('EventsIntegration'):
 d=json.loads((r/'events-results.json').read_text());print(json.dumps(d,indent=2));assert d['passed']

if entry.endswith('EventDisplayIntegration'):
 d=json.loads((r/'event-display-results.json').read_text());print(json.dumps(d,indent=2));assert d['passed']
