from pathlib import Path
import sys,subprocess,time,json
source=Path(__file__).with_name('run_receipts_native.py').read_text()
exec(compile(source.split("with (r/'server.log').open('w') as log:")[0],'raid-runtime-setup','exec'))
def launch(phase):
 log=(r/(phase+'.log')).open('w')
 p=subprocess.Popen(['/workspace/shared/jdk/bin/java',*jvm,'-Draid.receipt.phase='+phase,'-Xmx3G','-Xverify:all','-jar','fabric-server-launch.jar','nogui'],cwd=r,stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT)
 return p,log
p,log=launch('prepare')
try:
 deadline=time.monotonic()+220
 while not (r/'receipt-crash-ready').exists():
  if p.poll() is not None:raise RuntimeError('Prepare process exited; inspect prepare.log')
  if time.monotonic()>deadline:raise TimeoutError('Prepare timed out')
  time.sleep(.1)
 p.kill();p.wait(timeout=20);log.close()
 assert 'Stopping server' not in (r/'prepare.log').read_text()
 tx=(r/'receipt-crash-ready').read_text().strip();state=json.loads((r/'world/data/shirokai-raids/state.json').read_text());before=state['modularRewards']['grants'][tx]['status'];assert before!='DONE',before
 p,log=launch('verify');code=p.wait(timeout=220);log.close()
 result=json.loads((r/'receipt-restart-results.json').read_text());result['twoJvm']=True;result['preparedJournalStatus']=before;result['termination']='SIGKILL';(r/'receipt-restart-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));assert code==0 and result['passed']
finally:
 if p.poll() is None:p.kill();p.wait(timeout=20)
