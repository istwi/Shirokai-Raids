import java.nio.file.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
public final class PatchCatalogMethods {
 public static void main(String[] a)throws Exception{
  var base=new ClassNode();var candidate=new ClassNode();
  new ClassReader(Files.readAllBytes(Path.of(a[0]))).accept(base,0);
  new ClassReader(Files.readAllBytes(Path.of(a[1]))).accept(candidate,0);
  int count=0;
  for(var method:candidate.methods)if(method.name.equals("specialProgress")||method.name.equals("catalogStatus")||method.name.startsWith("lambda$catalogStatus$")){
   base.methods.removeIf(m->m.name.equals(method.name)&&m.desc.equals(method.desc));base.methods.add(method);count++;
  }
  if(count!=4)throw new IllegalStateException("Expected two catalog methods and two catalog lambdas, got "+count);
  int itemHook=0;
  for(var method:base.methods)if(method.name.equals("started"))for(var insn:method.instructions.toArray())
   if(insn instanceof MethodInsnNode call&&call.owner.equals("com/shirokai/raids/RaidRewardJournal")&&call.name.equals("recover")){
    var add=new InsnList();add.add(new VarInsnNode(Opcodes.ALOAD,0));
    add.add(new FieldInsnNode(Opcodes.GETFIELD,base.name,"modularRewards","Lcom/shirokai/raids/RaidRewardJournal;"));
    add.add(new LdcInsnNode("item"));add.add(new TypeInsnNode(Opcodes.NEW,"com/shirokai/raids/ItemRaidRewards"));add.add(new InsnNode(Opcodes.DUP));add.add(new VarInsnNode(Opcodes.ALOAD,1));
    add.add(new MethodInsnNode(Opcodes.INVOKESPECIAL,"com/shirokai/raids/ItemRaidRewards","<init>","(Lnet/minecraft/server/MinecraftServer;)V",false));
    add.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,"com/shirokai/raids/RaidRewardJournal","register","(Ljava/lang/String;Lcom/shirokai/raids/RaidRewardHandler;)V",false));
    method.instructions.insertBefore(insn,add);itemHook++;
   }
  if(itemHook!=1)throw new IllegalStateException("Expected exactly one item handler startup registration");
  var w=new ClassWriter(ClassWriter.COMPUTE_MAXS);base.accept(w);Files.write(Path.of(a[2]),w.toByteArray());
 }
}
