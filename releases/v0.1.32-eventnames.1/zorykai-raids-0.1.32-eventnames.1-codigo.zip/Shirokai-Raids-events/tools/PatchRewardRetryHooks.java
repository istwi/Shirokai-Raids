import java.nio.file.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
/** Retains the entire 0.1.27 main class, adding dispatcher startup and replacing only claim(). */
public final class PatchRewardRetryHooks {
 public static void main(String[] args)throws Exception{
  var base=new ClassNode();var candidate=new ClassNode();new ClassReader(Files.readAllBytes(Path.of(args[0]))).accept(base,0);new ClassReader(Files.readAllBytes(Path.of(args[1]))).accept(candidate,0);
  int hooks=0,claims=0;
  for(var method:base.methods)if(method.name.equals("started"))for(var insn:method.instructions.toArray())if(insn instanceof MethodInsnNode call&&call.owner.equals("com/shirokai/raids/RaidRewardJournal")&&call.name.equals("recover")){
   // Existing stack already contains the receiver for recover(); this static call balances its own arguments.
   var add=new InsnList();add.add(new VarInsnNode(Opcodes.ALOAD,0));add.add(new FieldInsnNode(Opcodes.GETFIELD,base.name,"modularRewards","Lcom/shirokai/raids/RaidRewardJournal;"));add.add(new VarInsnNode(Opcodes.ALOAD,1));
   add.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"com/shirokai/raids/RaidRewardDispatch","configure","(Lcom/shirokai/raids/RaidRewardJournal;Lnet/minecraft/server/MinecraftServer;)V",false));method.instructions.insertBefore(insn,add);hooks++;
  }
  for(var method:candidate.methods)if((method.name.equals("claim")||method.name.equals("retryRewards"))){base.methods.removeIf(m->m.name.equals(method.name)&&m.desc.equals(method.desc));base.methods.add(method);claims++;}
  if(hooks!=1||claims!=2)throw new IllegalStateException("Expected one startup hook and claim and retry maintenance methods: "+hooks+"/"+claims);
  var writer=new ClassWriter(ClassWriter.COMPUTE_MAXS);base.accept(writer);Files.write(Path.of(args[2]),writer.toByteArray());
 }
}
