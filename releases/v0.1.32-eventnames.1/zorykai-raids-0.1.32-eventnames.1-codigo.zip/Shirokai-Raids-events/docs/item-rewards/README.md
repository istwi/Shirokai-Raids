# Zorykai Raids 0.1.27-itemrewards.1 — entrega de itens do rewards-v2

## Problema confirmado

O JAR completo 0.1.25 e a alteração de chances 0.1.26 registravam provedores de `currency` e `fragment`, mas não um provedor nativo de `item`. O JSON aceitava esse tipo e gerava reservas; o dispatcher pulava as reservas porque não havia handler. Por isso gemas, doces e itens competitivos permaneciam em PENDING.

## Correção

A inicialização agora registra ItemRaidRewards antes da recuperação do journal. Ele consulta os itens reais no registro Minecraft/Cobblemon e reutiliza o protocolo existente PlayerRewardTarget: inserção no inventário principal, recibo por UUID de transação salvo junto do inventário e verificação do recibo no arquivo do jogador. Jogador offline, inventário bloqueado ou espaço insuficiente deixam a reserva para tentativa posterior. A entrega é integral; não joga itens no chão. Falhas de salvamento continuam preservando os dados e exigindo diagnóstico; a correção não ignora erros de persistência.

As reservas antigas de itens em PENDING passam a poder ser processadas após instalar o JAR, sem novo sorteio ou exclusão do histórico. Nada converte automaticamente UNCERTAIN para PENDING/DONE. O fragmento incerto exibido pelo usuário exige conferência separada com o log `Entrega: UNCERTAIN`; não é possível concluir pela imagem se ele já foi entregue.

## Instalação

1. Pare o servidor e faça backup do JAR, da pasta config/shirokai-raids e dos dados do mundo.
2. Substitua somente o JAR do Raids por Zorykai-Raids-0.1.27-itemrewards.1-fabric-1.21.1.jar. Não deixe versões duplicadas.
3. Preserve rewards-v2 e o arquivo de estado existente. Não apague pendências, state.json, dados do jogador ou recibos.
4. Inicie o servidor. Com o jogador online, inventário liberado da raid e espaço suficiente, as reservas de itens em PENDING entram na fila automática.

Não é necessário alterar o ZIP de recompensas novamente nem habilitar legacyItems. Esta versão também inclui as chances de dificuldade 30/30/25/12/3 da 0.1.26 e mantém o modo cycle opcional. Níveis e demais configurações existentes continuam no catalog.json. A documentação das chances acompanha o código.

## Compatibilidade e validação

Minecraft 1.21.1, Fabric, Java 21 e Cobblemon 1.8.3. Nome Zorykai preservado. Empacotado sobre a distribuição completa 0.1.25, conservando captura, autenticação, retorno ao spawn, avisos privados de dano e código do journal anterior. O único hook adicional na inicialização registra o handler nativo de itens; fragmentos e moedas não foram alterados. Consulte o .audit.json.

135 testes JUnit passaram. Em servidor Fabric isolado, 252 verificações passaram: todos os IDs de itens nas cinco tabelas do ZIP existem; os 34 tipos foram sorteados pelo journal de produção e entregues com quantidades corretas; repetição de transação não duplica; conteúdo e recibo persistem ao recarregar jogador; offline retorna RETRY; inventário cheio não cria recibo nem drop e entrega após liberar espaço. Outras 19 verificações nativas confirmaram o sorteio por dificuldade e reload da versão anterior.

Esses testes usam jogadores simulados, inventários reais do Minecraft e arquivos salvos em disco; não houve cliente gráfico, batalha completa nem ensaio do modpack da VPS. O sorteio da fixture usa chance 100% apenas dentro do teste para cobrir todos os itens; as chances do ZIP entregue não foram modificadas.

Nenhuma alteração na VPS e nenhuma publicação no GitHub nesta entrega.
