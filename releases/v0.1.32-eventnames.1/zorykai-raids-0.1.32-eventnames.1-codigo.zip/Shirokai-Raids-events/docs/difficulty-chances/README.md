# Chances por dificuldade — Zorykai Raids 0.1.26-chances.1

Base: branch `fix/raid-return-spawn`, commit `b33356c`, distribuição completa 0.1.25-returnspawn.1. Compatível com Minecraft 1.21.1, Fabric, Java 21 e Cobblemon 1.8.3. O nome visual continua Zorykai Raids.

## Instalação e configuração

Pare o servidor e faça backup do JAR atual e da pasta `config/shirokai-raids`. Substitua somente o JAR de Raids pelo `Zorykai-Raids-0.1.26-chances.1-fabric-1.21.1.jar`; não mantenha versões duplicadas. Preserve os arquivos de estado, recompensas, filtros, arena, perfis e dados dos jogadores.

No arquivo existente `config/shirokai-raids/catalog.json`, adicione estas propriedades no nível principal, junto de `enabled` e `profiles`:

```json
"selectionMode": "weighted",
"difficultyWeights": {
  "normal": 30,
  "raro": 30,
  "epico": 25,
  "lendario": 12,
  "supremo": 3
}
```

Respeite as vírgulas do JSON. Não substitua o arquivo completo pelo trecho acima. Os seus níveis, IVs/EVs, dano e vida continuam configurados em `profiles`. Se as novas propriedades estiverem ausentes, esta versão já usa `weighted` com 30/30/25/12/3 por padrão, preservando os valores existentes dos outros campos. A atualização não reescreve automaticamente arquivos existentes para inserir as propriedades.

Depois de iniciar, alterações futuras nesse JSON podem ser aplicadas por `/raidadmin reload`, desde que não exista raid ativa nem animação de vitória. Confira em `/raidadmin catalogo` ou no painel `/raidadmin especial`.

## Sorteio

Primeiro é sorteada a dificuldade, depois uma espécie elegível daquela dificuldade. Assim, haver mais espécies normais no catálogo não aumenta a chance de uma raid normal. As chances devem ser números finitos entre 0 e 100, conter as cinco categorias e somar 100. Uma chance 0 desativa a categoria.

O perfil não transforma uma espécie comum em lendária: a classificação existente por força e rótulos foi preservada. Espécies bloqueadas, não implementadas, intermediárias, pequenas/grandes demais ou sem golpes elegíveis continuam excluídas. A proteção contra repetição continua funcionando dentro da categoria sorteada.

Sem espécies elegíveis numa categoria, sua chance é redistribuída proporcionalmente entre as categorias disponíveis com chance positiva. Exemplo: se apenas normal e rara estiverem disponíveis, com 30 e 30, cada uma terá 50%. Se nenhuma categoria com chance positiva tiver espécies elegíveis, o início falha explicitamente; não libera espécies bloqueadas nem categorias com chance 0.

Os percentuais são probabilidades independentes por raid: não garantem uma lendária em determinado número de partidas. No modo `weighted`, uma lendária/suprema pode sair já na primeira raid. Não há mais garantia de especial na vigésima.

Raids manuais não usam esses pesos. Os campos de recompensa não mudam. As configurações de maior chance de itens podem ser instaladas separadamente; este JAR não substitui recompensas.

## Voltar ao ciclo antigo

Use `"selectionMode": "cycle"`. Esse modo conserva uma especial a cada 20 inícios automáticos, sem usar os pesos no sorteio. O histórico e o contador existente não são apagados ao trocar de modo. O painel administrativo volta a mostrar o contador nesse modo.

## Validação e limites

135 testes JUnit passaram, incluindo os testes anteriores do ciclo e novos testes de distribuição com 100 mil sorteios, categoria única, chance zero, ausência de espécies, validação de valores, estado antigo e painel.

19 verificações automatizadas passaram em um servidor Fabric/Minecraft 1.21.1 com Cobblemon 1.8.3: catálogo real nas cinco categorias, 10 mil sorteios, criação/treino de Pokémon de cada dificuldade, reload entre modos e alteração de chances, status e painel reais. Não houve cliente gráfico nem batalha completa neste ensaio.

O empacotamento preserva todas as entradas do JAR completo 0.1.25 e altera somente classes do catálogo/painel, metadados de versão e os métodos `specialProgress`, `catalogStatus` e suas lambdas na classe principal. Autenticação, captura, prevenção de quiz, fallback de retorno, combate e recompensas são preservados do artefato anterior; veja o arquivo `.audit.json`. A compilação simples intermediária do código antigo não deve ser usada em produção: use exclusivamente o JAR final de `build/libs`.

Também passaram 50 verificações nativas de regressão do retorno ao spawn, usando o fixture existente da base 0.1.25, sem Guard/Essentials instalados.

Nenhuma mudança foi aplicada à VPS ou publicada no GitHub durante esta entrega.
