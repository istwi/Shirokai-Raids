package com.shirokai.raids;

import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.MinecraftServer;

/** Runtime policy only: no grant, amount, receipt, or draw is changed. */
final class RaidRewardDispatch {
    private static RaidRewardJournal current;
    private static final java.util.Map<java.util.UUID,Long> clicks=new java.util.HashMap<>();
    static void maintain(RaidState state,MinecraftServer server){
        var outstanding=new java.util.HashMap<String,java.util.Set<String>>();var online=new java.util.HashSet<String>();
        for(var player:server.getPlayerList().getPlayers())online.add(player.getUUID().toString());
        if(current!=null&&current.matches(state.modularRewards)){var ids=new java.util.HashSet<java.util.UUID>();for(var player:server.getPlayerList().getPlayers())ids.add(player.getUUID());current.reconcile(ids,1);}
        for(var grant:state.modularRewards.grants.values())if(online.contains(grant.player)&&grant.status!=RaidRewardJournal.Status.DONE&&grant.status!=RaidRewardJournal.Status.SKIPPED)outstanding.computeIfAbsent(grant.player,k->new java.util.HashSet<>()).add(grant.id);
        for(var player:server.getPlayerList().getPlayers())new PlayerRewardTarget(server,player,"shirokai_modular:").prune(outstanding.getOrDefault(player.getUUID().toString(),java.util.Set.of()));
    }
    static void requestOne(RaidState state,net.minecraft.server.level.ServerPlayer player,String transaction){
        if(current==null||!current.matches(state.modularRewards))return;
        if(RaidInventory.locked(player)){player.sendSystemMessage(net.minecraft.network.chat.Component.literal("Finalize a captura e saia da raid antes de resgatar."));return;}
        long now=java.util.concurrent.TimeUnit.NANOSECONDS.toMillis(System.nanoTime());Long previous=clicks.get(player.getUUID());if(previous!=null&&now-previous<5000){player.sendSystemMessage(net.minecraft.network.chat.Component.literal("Aguarde cinco segundos entre pedidos de resgate."));return;}
        clicks.put(player.getUUID(),now);
        current.reconcile(player.getUUID(),1);
        boolean accepted=current.requestOne(player.getUUID(),transaction);player.sendSystemMessage(net.minecraft.network.chat.Component.literal(accepted?"Pedido de resgate enviado. A entrega só é confirmada após salvar o recibo.":"Recompensa em processamento, em conferência ou já concluída. Atualize o menu."));
    }
    static String reason(RaidState state,net.minecraft.server.level.ServerPlayer player,RaidRewardJournal.Grant grant){
        if(grant.status==RaidRewardJournal.Status.UNCERTAIN)return current!=null&&current.matches(state.modularRewards)&&current.hasReceipt(grant)?"Recibo encontrado; aguardando confirmação do salvamento":"Sem recibo confirmado; conferência administrativa necessária";
        if(grant.status==RaidRewardJournal.Status.IN_FLIGHT||current!=null&&current.matches(state.modularRewards)&&current.processing(grant))return "Entrega em processamento; aguarde a confirmação";
        if(RaidInventory.locked(player))return "Finalize a captura e saia da raid antes de receber itens";
        if(current==null||!current.matches(state.modularRewards))return "Serviço de resgate indisponível";
        var handler=current.handlers().get(grant.choice.reward.type);
        try {
            if(handler==null||!handler.available(grant.choice.reward.reference))return "Integração ou prêmio indisponível";
            if(!handler.ready(player.getUUID(),grant.id,grant.choice.reward.reference,grant.choice.amount))return "Sem espaço ou inventário temporariamente bloqueado";
            return "Clique neste prêmio para resgatar; confirmação aparece no chat";
        }catch(RuntimeException|LinkageError error){return "Integração indisponível; pendência preservada";}
    }
    static String request(RaidRewardJournal journal,RaidState state,net.minecraft.server.level.ServerPlayer player,int legacyDelivered){
        if(journal!=null){journal.reconcile(player.getUUID(),1);journal.attempt(player.getUUID(),4);}
        int pending=state.pending.getOrDefault(player.getUUID().toString(),java.util.List.of()).size();int uncertain=0;
        for(var delivery:state.deliveries.values())if(delivery.player.equals(player.getUUID().toString()))pending++;
        for(var grant:state.modularRewards.grants.values())if(grant.player.equals(player.getUUID().toString())){
            if(grant.status==RaidRewardJournal.Status.PENDING||grant.status==RaidRewardJournal.Status.IN_FLIGHT)pending++;
            else if(grant.status==RaidRewardJournal.Status.UNCERTAIN)uncertain++;
        }
        if(pending==0&&uncertain==0)return legacyDelivered>0?legacyDelivered+" item(ns) entregue(s). Nenhuma pendência restante.":"Você não tem recompensas pendentes.";
        return "Pedido de entrega enviado. Na fila: "+pending+" recompensa(s). Em conferência: "+uncertain+". "+(legacyDelivered>0?legacyDelivered+" item(ns) entregue(s). ":"")+"Veja /raid recompensas; cada entrega concluída é confirmada no chat.";
    }
    static void configure(RaidRewardJournal journal,MinecraftServer server) {
        current=journal;clicks.clear();journal.manual(true);
        journal.online(id -> server.getPlayerList().getPlayer(id)!=null);
        journal.onConfirmed(grant->{var player=server.getPlayerList().getPlayer(java.util.UUID.fromString(grant.player));if(player!=null&&player.containerMenu instanceof PendingRewardMenu menu)menu.refreshReceipt();});
        journal.onReconciled(grant->{var player=server.getPlayerList().getPlayer(java.util.UUID.fromString(grant.player));if(player!=null){player.sendSystemMessage(RaidMessages.chat("Recibo confirmado: pendência resolvida sem reenviar "+ShirokaiRaids.rewardName(grant.choice.reward.type,grant.choice.reward.reference)+" x"+grant.choice.amount));if(player.containerMenu instanceof PendingRewardMenu menu)menu.refreshReceipt();}});
        ServerPlayConnectionEvents.JOIN.register((connection,sender,current)->{
            if(current==server){journal.wake(connection.getPlayer().getUUID());journal.reconcile(connection.getPlayer().getUUID(),1);}
        });
        ServerPlayConnectionEvents.DISCONNECT.register((connection,currentServer)->{if(currentServer==server){journal.cancel(connection.getPlayer().getUUID());clicks.remove(connection.getPlayer().getUUID());}});
    }
}
