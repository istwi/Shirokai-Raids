package com.shirokai.raids;

import java.util.*;

/** Immutable by convention once attached to a boss/reward snapshot. */
public final class RaidEventPlan {
    String rarity="",element="",species="",excludedSpecies="";
    double shiny=-1,drop=1,tokens=1;
    int perfectIvs;
    boolean invasion,rage,duo;
    String secondRarity="",chainId="";
    int stage=1;
    long seed=new Random().nextLong();
    boolean configured(){return !rarity.isEmpty()||!element.isEmpty()||!species.isEmpty()||shiny>=0||drop!=1||tokens!=1||perfectIvs>0||invasion||rage||duo;}
    void validate(){
        require(rarity.isEmpty()||RaidCatalogSettings.ORDER.contains(rarity),"Raridade inválida");
        require(element.isEmpty()||RaidEvents.TYPES.contains(element),"Tipo inválido");
        require(species.isEmpty()||species.matches("[a-z0-9_.-]+:[a-z0-9_./-]+"),"Espécie inválida");
        require(excludedSpecies!=null&&(excludedSpecies.isEmpty()||excludedSpecies.matches("[a-z0-9_.-]+:[a-z0-9_./-]+")),"Exclusão de espécie inválida");
        require(Double.isFinite(shiny)&&(shiny==-1||shiny>=0&&shiny<=1),"Shiny deve estar entre 0% e 100%");
        require(Double.isFinite(drop)&&drop>=1&&drop<=10&&Double.isFinite(tokens)&&tokens>=1&&tokens<=10,"Multiplicadores devem estar entre 1 e 10");
        require(perfectIvs>=0&&perfectIvs<=6&&(secondRarity.isEmpty()||RaidCatalogSettings.ORDER.contains(secondRarity))&&stage>=1&&stage<=2,"Evento inválido");
        require(!invasion||rarity.isEmpty()||Set.of("lendario","supremo").contains(rarity),"Chamado Lendário exige lendário ou supremo");
        require(chainId!=null&&(chainId.isEmpty()||chainId.matches("[a-f0-9-]{36}")),"Cadeia inválida");
    }
    int ivMask(){var indices=new ArrayList<>(List.of(0,1,2,3,4,5));Collections.shuffle(indices,new Random(seed));int mask=0;for(int i=0;i<perfectIvs;i++)mask|=1<<indices.get(i);return mask;}
    String describe(){var parts=new ArrayList<String>();if(!rarity.isEmpty())parts.add("raridade "+rarity);if(!species.isEmpty())parts.add("boss "+species);if(shiny>=0)parts.add("Sorte Shiny: "+String.format(Locale.ROOT,"%.2f%%",shiny*100));if(perfectIvs>0)parts.add("IVs Perfeitos: pelo menos "+perfectIvs+" IVs 31");if(drop!=1)parts.add("Drop Turbinado: "+drop+"x chance de itens/fragmentos");if(tokens!=1)parts.add("Tokens Extras: "+tokens+"x tokens");if(invasion)parts.add("Chamado Lendário");if(!element.isEmpty())parts.add("Raid Elemental: "+element);if(rage)parts.add("Boss Enfurecido: +50% dano, itens e tokens (quantidade de fragmentos mantida)");if(duo)parts.add("Desafio Duplo: etapa "+stage+"/2; segunda "+(secondRarity.isEmpty()?"aleatória":secondRarity));return parts.isEmpty()?"sem eventos especiais":String.join(" | ",parts);}
    static void require(boolean b,String text){if(!b)throw new IllegalArgumentException(text);}
}
