package com.shirokai.raids;

import java.util.*;

/** Prize reservation cooldown, per owner and eligible victorious participation; no inventory inspection. */
final class HeldItemPolicy {
    static Set<String> defaults(){var result=new LinkedHashSet<String>();for(var name:List.of("choice_band","choice_specs","choice_scarf","leftovers","black_sludge","life_orb","focus_sash","focus_band","rocky_helmet","expert_belt","air_balloon","heavy_duty_boots","eviolite","weakness_policy","assault_vest","scope_lens","wide_lens","zoom_lens","muscle_band","wise_glasses","light_clay","mental_herb","white_herb","power_herb","quick_claw","kings_rock","razor_claw","razor_fang","safety_goggles","clear_amulet","covert_cloak","punching_glove","loaded_dice","ability_shield","booster_energy"))result.add("cobblemon:"+name);return result;}
    static void validate(RaidRewardSettings.Integrations settings){if(settings==null||settings.heldItemCooldownRaids<0||settings.heldItemCooldownRaids>10||settings.heldItems==null||settings.heldItems.size()>256||settings.heldItems.stream().anyMatch(s->s==null||!s.matches("[a-z0-9_.-]+:[a-z0-9_./-]+")))throw new IllegalArgumentException("Cooldown de held items inválido: 0–10 raids e IDs válidos");}
    static boolean held(RaidRewardSettings.Reward reward,RaidRewardSettings.Integrations settings){return reward.type.equals("item")&&settings.heldItems.contains(reward.reference);}
    static Set<String> blocked(List<Set<String>> history,int count){var result=new HashSet<String>();for(int i=Math.max(0,history.size()-count);i<history.size();i++)result.addAll(history.get(i));return result;}
    static List<Set<String>> advance(List<Set<String>> history,Set<String> selected,int count){var result=new ArrayList<Set<String>>(history);result.add(Set.copyOf(selected));while(result.size()>count+1)result.removeFirst();return result;}
    static List<RaidLootRoller.Drop> legacy(List<RaidLootRoller.Drop> rolls,ShirokaiRaids mod,com.shirokai.raids.core.RaidDamageTracker.Entry participant){
        var active=RaidEvents.get(mod,"active");String raid=(String)RaidEvents.get(active,"id"),owner=participant.player().toString();
        var settings=((RaidRewardSettings)RaidEvents.get(active,"rewardSettings")).integrations;validate(settings);
        var data=RaidEvents.state(mod).modularRewards;var history=data.heldHistory.getOrDefault(owner,List.of());
        boolean current=raid.equals(data.heldHistoryRaid.get(owner));
        var previous=current?history.subList(0,Math.max(0,history.size()-1)):history;
        var selected=new HashSet<String>();if(current&&!history.isEmpty())selected.addAll(history.getLast());
        var blocked=blocked(previous,settings.heldItemCooldownRaids);var filtered=new ArrayList<RaidLootRoller.Drop>();
        for(var drop:rolls){if(!settings.heldItems.contains(drop.item())){filtered.add(drop);continue;}if(blocked.contains(drop.item())||!selected.add(drop.item()))continue;filtered.add(new RaidLootRoller.Drop(drop.item(),1,drop.tier(),drop.rarity()));}
        data.heldHistory.put(owner,advance(previous,selected,settings.heldItemCooldownRaids));data.heldHistoryRaid.put(owner,raid);return List.copyOf(filtered);
    }
    static void validateHistory(Map<String,List<Set<String>>> history){if(history==null)throw new IllegalArgumentException("Histórico de held items ausente");for(var entry:history.entrySet()){UUID.fromString(entry.getKey());if(entry.getValue()==null||entry.getValue().size()>11)throw new IllegalArgumentException("Histórico de held items inválido");for(var row:entry.getValue())if(row==null||row.size()>256||row.stream().anyMatch(s->s==null||!s.matches("[a-z0-9_.-]+:[a-z0-9_./-]+")))throw new IllegalArgumentException("Item no histórico inválido");}}
}
