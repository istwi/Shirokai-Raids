package com.shirokai.raids;

import java.math.*;

final class RaidEventRewards {
    static boolean physical(RaidRewardSettings.Reward r){return r.type.equals("item")||r.type.equals("fragment");}
    static double chance(RaidRewardSettings.Reward r,double base,RaidEventPlan event){return Math.min(1,base*(event!=null&&physical(r)?event.drop:1));}
    static BigDecimal amount(RaidRewardSettings.Reward r,BigDecimal base,RaidEventPlan e,long cap){
        if(e==null)return base;
        double factor=r.type.equals("currency")&&r.reference.equals("impactor:tokens")?e.tokens*(e.rage?1.5:1):r.type.equals("item")&&e.rage?1.5:1;
        if(factor==1)return base;
        long maximum=r.type.equals("fragment")?Math.min(64,cap):cap;
        return base.multiply(BigDecimal.valueOf(factor)).setScale(0,r.type.equals("item")?RoundingMode.CEILING:RoundingMode.DOWN).max(BigDecimal.ONE).min(BigDecimal.valueOf(maximum));
    }
}
