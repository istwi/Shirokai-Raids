package com.shirokai.raids;

import com.cobblemon.mod.common.api.pokemon.PokemonSpecies;
import com.cobblemon.mod.common.api.pokemon.stats.Stats;
import com.cobblemon.mod.common.entity.pokemon.PokemonEntity;
import com.cobblemon.mod.common.pokemon.Pokemon;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.commands.*;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import org.slf4j.LoggerFactory;
import java.lang.reflect.*;
import java.nio.file.Path;
import java.util.*;

/** Narrow hooks into the complete latest distribution; never replaces return/authentication/capture logic. */
public final class RaidEvents implements ModInitializer {
    static final Set<String> TYPES=Set.of("normal","fire","water","electric","grass","ice","fighting","poison","ground","flying","psychic","bug","rock","ghost","dragon","dark","steel","fairy");
    private static MinecraftServer server;
    private static long nextTick;
    private static boolean stopped;
    private static String announcedDuo="";
    private static Settings settings=new Settings();
    static final class Settings {
        int schema=1,voteSeconds=60,duoDelaySeconds=30,duoMaximumWaitSeconds=900;
        int eventBarSeconds=4,normalBarSeconds=8,eventBarIntervalSeconds=60;
        void validate(){if(eventBarIntervalSeconds<30||eventBarIntervalSeconds>3600||eventBarIntervalSeconds<=eventBarSeconds)throw new IllegalArgumentException("Intervalo de aviso deve ser 30–3600s e maior que a exibição");if(eventBarSeconds<2||eventBarSeconds>30||normalBarSeconds<2||normalBarSeconds>60)throw new IllegalArgumentException("Alternância inválida: evento 2–30s, normal 2–60s");if(schema!=1||voteSeconds<15||voteSeconds>600||duoDelaySeconds<10||duoDelaySeconds>300||duoMaximumWaitSeconds<300||duoMaximumWaitSeconds>7200)throw new IllegalArgumentException("events.json inválido: voto 15–600s, intervalo 10–300s, espera 300–7200s");}
    }
    @Override public void onInitialize(){
        CommandRegistrationCallback.EVENT.register((dispatcher,access,environment)->RaidEventCommands.register(dispatcher));
        ServerLifecycleEvents.SERVER_STARTED.register(s->{server=s;stopped=false;nextTick=0;announcedDuo="";try{
            loadSettings();RaidEventPresentation.reset();var state=state(mod());var e=state.events;
            // Restart never reruns a started chain or resurrects capture opportunities.
            if(e.vote!=null||e.second!=null||!e.chainRaid.isEmpty()){
                e.vote=null;e.second=null;e.chainRaid="";e.safeSince=0;e.waitingSince=0;save(mod());
                log("Reinício: votação/sequência em andamento cancelada; recompensas e retornos preservados.");
            }
        }catch(Exception error){stopped=true;log("Eventos suspensos: "+error);}});
        ServerLifecycleEvents.SERVER_STOPPING.register(s->stopped=true);
        ServerLifecycleEvents.SERVER_STOPPED.register(s->server=null);
        ServerTickEvents.END_SERVER_TICK.register(s->{long now=System.currentTimeMillis();if(stopped||now<nextTick)return;nextTick=now+1000;try{tick(mod(),now);}catch(Exception error){stopped=true;log("Eventos suspensos; nenhuma nova etapa será iniciada: "+error);}});
        ServerPlayConnectionEvents.JOIN.register((handler,sender,s)->{try{if(state(mod()).events.vote!=null)handler.getPlayer().sendSystemMessage(text("Voz dos Treinadores aberta. Use /raid votar para ver as opções."));}catch(Exception ignored){}});
    }
    private static boolean admin(CommandSourceStack s){return RaidPermissions.check(s,"shirokai.raids.admin",s.hasPermission(2));}
    static boolean allowedEventCommand(String command){return command.strip().matches("raid +votar(?: +[1-3])?");}
    static int execute(CommandSourceStack source,String action,String options){
        try{
            var mod=mod();if((stopped&&!(action.equals("evento")&&options.equals("reload")))||!Boolean.TRUE.equals(get(mod,"healthy")))throw new IllegalStateException("Raids/eventos indisponíveis; confira o console");
            var e=state(mod).events;var args=options.isBlank()?new String[0]:options.strip().split("\\s+");
            switch(action){
                case "eventos"->{reply(source,"Próxima raid: "+e.next.describe());if(e.second!=null)reply(source,"Desafio Duplo em andamento: aguardando a segunda etapa.");if(e.vote!=null)reply(source,voteText(e.vote));return 1;}
                case "votar"->{
                    if(e.vote==null||System.currentTimeMillis()>=e.vote.ends)throw new IllegalArgumentException("Nenhuma votação aberta");
                    if(args.length==0){reply(source,voteText(e.vote));return 1;}
                    var player=source.getPlayerOrException();int index=Integer.parseInt(args[0])-1;
                    if(index<0||index>=e.vote.options.size())throw new IllegalArgumentException("Escolha de 1 a "+e.vote.options.size());
                    String voter=player.getUUID().toString();long now=System.currentTimeMillis();
                    if(Objects.equals(e.vote.votes.get(voter),index)){reply(source,"Seu voto já está nessa opção.");return 1;}
                    if(now-e.vote.lastVotes.getOrDefault(voter,0L)<2000)throw new IllegalArgumentException("Aguarde 2 segundos para trocar o voto.");
                    var old=new HashMap<>(e.vote.votes);var oldTimes=new HashMap<>(e.vote.lastVotes);e.vote.votes.put(voter,index);e.vote.lastVotes.put(voter,now);try{save(mod);}catch(RuntimeException error){e.vote.votes=old;e.vote.lastVotes=oldTimes;throw error;}reply(source,"Voto registrado: "+e.vote.options.get(index));return 1;
                }
                case "iniciar"->{
                    if(e.vote!=null||e.second!=null||!e.chainRaid.isEmpty())throw new IllegalStateException("Aguarde a votação/sequência atual");
                    var plan=copy(e.next);if(args.length>1)throw new IllegalArgumentException("Use /raidadmin iniciar [raridade|boss]");
                    if(args.length==1){
                        try{plan.rarity=rarity(args[0]);}
                        catch(IllegalArgumentException invalid){
                            if(!((Map<?,?>)get(mod,"bosses")).containsKey(args[0]))throw invalid;
                            call(mod,"begin",new Class<?>[]{String.class},args[0]);return 1;
                        }
                    }
                    plan.validate();
                    start(mod,plan,false);return 1;
                }
                case "proxima"->{
                    mutable(e);if(args.length!=1)throw new IllegalArgumentException("Use /raidadmin proxima <normal|raro|epico|lendario|supremo>");
                    var plan=copy(e.next);plan.rarity=rarity(args[0]);update(mod,plan);reply(source,"Próxima raridade: &e"+plan.rarity+"&f.");return 1;
                }
                case "evento"->{
                    if(args.length==1&&args[0].equals("reload")){loadSettings();stopped=false;nextTick=0;reply(source,"events.json recarregado; snapshots das raids preservados.");return 1;}
                    if(args.length==1&&args[0].equals("cancelar")){
                        var old=JsonFiles.copy(e,RaidEventState.class);e.next=new RaidEventPlan();e.vote=null;e.second=null;e.chainRaid="";e.safeSince=0;e.waitingSince=0;
                        try{save(mod);}catch(RuntimeException error){state(mod).events=old;throw error;}
                        if(old.vote!=null)announce("Voz dos Treinadores cancelada.");else if(old.second!=null)announce("Próxima etapa da Desafio Duplo cancelada.");reply(source,"Programação futura cancelada; raid atual preservada.");return 1;
                    }
                    mutable(e);if(args.length==0)throw new IllegalArgumentException("Eventos: shiny, ivs, drop, token, invasao, elemental, votacao, enfurecido, dupla, cancelar, reload");
                    var plan=copy(e.next);
                    switch(args[0]){
                        case "shiny"->{exact(args,2);plan.shiny=Double.parseDouble(args[1].replace("%","").replace(',','.'))/100d;}
                        case "ivs"->{exact(args,2);plan.perfectIvs=Integer.parseInt(args[1]);if(plan.perfectIvs<1)throw new IllegalArgumentException("Escolha de 1 a 6 IVs");}
                        case "drop"->{exact(args,2);plan.drop=Double.parseDouble(args[1].replace(',','.'));}
                        case "token","tokens"->{exact(args,2);plan.tokens=Double.parseDouble(args[1].replace(',','.'));}
                        case "invasao"->{exact(args,1);plan.invasion=true;}
                        case "elemental"->{exact(args,2);plan.element=element(args[1]);}
                        case "enfurecido"->{exact(args,1);plan.rage=true;}
                        case "dupla"->{if(args.length!=1&&args.length!=3)throw new IllegalArgumentException("Use /raidadmin evento dupla [raridade1 raridade2]");plan.duo=true;plan.chainId=UUID.randomUUID().toString();plan.stage=1;plan.rarity=args.length==3?rarity(args[1]):"";plan.secondRarity=args.length==3?rarity(args[2]):"";}
                        case "votacao"->{
                            if(args.length<3||args.length>4)throw new IllegalArgumentException("Use /raidadmin evento votacao <especie1> <especie2> [especie3]");
                            var vote=new RaidEventState.Vote();for(int i=1;i<args.length;i++){String id=args[i].contains(":")?args[i]:"cobblemon:"+args[i];var test=copy(plan);test.species=id;select(mod,test);if(vote.options.contains(id))throw new IllegalArgumentException("Espécies repetidas");vote.options.add(id);}
                            vote.ends=System.currentTimeMillis()+settings.voteSeconds*1000L;e.vote=vote;try{save(mod);}catch(RuntimeException error){e.vote=null;throw error;}announce(voteText(vote));return 1;
                        }
                        default->throw new IllegalArgumentException("Evento desconhecido");
                    }
                    update(mod,plan);reply(source,"Evento configurado para a próxima raid: &e"+eventName(args[0])+(args.length>1?" "+String.join(" ",Arrays.copyOfRange(args,1,args.length)):"")+"&f.");return 1;
                }
                default->throw new IllegalArgumentException("Comando inválido");
            }
        }catch(Exception error){Throwable reason=error instanceof InvocationTargetException i?i.getCause():error;source.sendFailure(text(reason.getMessage()==null?reason.toString():reason.getMessage()));return 0;}
    }
    private static void mutable(RaidEventState e){if(e.vote!=null||e.second!=null||!e.chainRaid.isEmpty())throw new IllegalStateException("Aguarde a votação/dupla ou use /raidadmin evento cancelar");}
    private static void exact(String[] args,int count){if(args.length!=count)throw new IllegalArgumentException("Quantidade de argumentos inválida");}
    static String rarity(String input){return switch(input.toLowerCase(Locale.ROOT)){case "aleatorio","aleatória","aleatório","random"->"";case "normal"->"normal";case "raro","rara"->"raro";case "epico","epica","épico","épica"->"epico";case "lendario","lendaria","lendário","lendária"->"lendario";case "supremo","suprema"->"supremo";default->throw new IllegalArgumentException("Raridade inválida: "+input);};}
    static String element(String input){String value=switch(input.toLowerCase(Locale.ROOT)){case "fogo"->"fire";case "agua","água"->"water";case "eletrico","elétrico"->"electric";case "planta"->"grass";case "gelo"->"ice";case "lutador"->"fighting";case "venenoso"->"poison";case "terra"->"ground";case "voador"->"flying";case "psiquico","psíquico"->"psychic";case "inseto"->"bug";case "pedra"->"rock";case "fantasma"->"ghost";case "dragao","dragão"->"dragon";case "sombrio"->"dark";case "aco","aço"->"steel";case "fada"->"fairy";default->input.toLowerCase(Locale.ROOT);};if(!TYPES.contains(value))throw new IllegalArgumentException("Tipo inválido");return value;}
    private static void update(ShirokaiRaids mod,RaidEventPlan plan){
        plan.validate();select(mod,plan);var rewardConfig=(RaidRewardSettings)get(mod,"rewardSettings");if(!rewardConfig.integrations.enabled&&(plan.drop!=1||plan.tokens!=1||plan.rage))throw new IllegalStateException("Ative as recompensas modulares antes de configurar bônus");if(plan.duo){var second=copy(plan);second.rarity=plan.secondRarity;second.species="";second.stage=2;select(mod,second);}
        var old=state(mod).events.next;state(mod).events.next=plan;try{save(mod);}catch(RuntimeException error){state(mod).events.next=old;throw error;}
    }
    @SuppressWarnings("unchecked") private static RaidAutomaticCatalog.Draw select(ShirokaiRaids mod,RaidEventPlan plan){
        plan.validate();var c=JsonFiles.copy((RaidCatalogSettings)get(mod,"catalogSettings"),RaidCatalogSettings.class);
        if(!c.enabled)throw new IllegalStateException("Ative o catálogo automático para usar seleção/eventos");
        c.selectionMode="weighted";if(!plan.rarity.isEmpty())for(var id:RaidCatalogSettings.ORDER)c.difficultyWeights.put(id,id.equals(plan.rarity)?100d:0d);
        else if(plan.invasion){c.difficultyWeights.replaceAll((id,w)->id.equals("lendario")?80d:id.equals("supremo")?20d:0d);}
        var pool=RaidCatalogPokemon.species(c).stream().filter(s->plan.species.isEmpty()||s.id().equals(plan.species)).filter(s->!plan.invasion||Set.of("lendario","supremo").contains(RaidAutomaticCatalog.difficulty(s))).filter(s->{
            return matchesElement(s.id(),plan.element);
        }).toList();
        var viable=pool.stream().filter(s->RaidAutomaticCatalog.eligible(s,c)&&c.difficultyWeights.get(RaidAutomaticCatalog.difficulty(s))>0).toList();
        var different=viable.stream().filter(s->!s.id().equals(plan.excludedSpecies)).toList();
        var choices=different.isEmpty()?viable:different;
        var state=state(mod);return RaidAutomaticCatalog.draw(choices,c,state.automaticRaidStarts,state.catalogRecentNormal,state.catalogRecentSpecial,new Random(plan.seed));
    }
    static boolean matchesElement(String id,String element){if(element.isEmpty())return true;var species=PokemonSpecies.getByIdentifier(ResourceLocation.parse(id));if(species==null)return false;var form=species.getStandardForm();return form.getPrimaryType().getName().equalsIgnoreCase(element)||form.getSecondaryType()!=null&&form.getSecondaryType().getName().equalsIgnoreCase(element);}
    private static void start(ShirokaiRaids mod,RaidEventPlan plan,boolean automatic){
        if(!safe(mod,System.currentTimeMillis()))throw new IllegalStateException("Aguarde capturas, batalhas e retornos da raid anterior");
        var draw=select(mod,plan);var definition=JsonFiles.copy(draw.boss(),RaidConfig.Boss.class);definition.event=copy(plan);
        call(mod,"begin",new Class<?>[]{RaidConfig.Boss.class,RaidAutomaticCatalog.Draw.class},definition,automatic?draw:null);
        if(!RaidEventPresentation.names(plan).isEmpty())announce("Raid especial iniciada: &e"+shortNames(plan)+"&f. Acompanhe os eventos na boss bar.");
    }
    /** Called before the original automatic selector. True suppresses only this scheduled attempt. */
    static boolean overrideAutomatic(ShirokaiRaids mod){
        var e=state(mod).events;if(stopped||e.vote!=null||e.second!=null||!e.chainRaid.isEmpty())return true;
        if(!e.next.configured())return false;start(mod,copy(e.next),true);return true;
    }
    /** Called at the very beginning of the original begin(Boss,Draw), before training and snapshotting. */
    static RaidConfig.Boss decorate(ShirokaiRaids mod,RaidConfig.Boss source){
        var e=state(mod).events;
        if(source.event==null&&(e.vote!=null||e.second!=null||!e.chainRaid.isEmpty()))throw new IllegalStateException("Uma votação/dupla reservou a próxima raid");
        if(source.event==null&&e.next.configured())throw new IllegalStateException("Use /raidadmin iniciar para respeitar os eventos da próxima raid");
        var boss=JsonFiles.copy(source,RaidConfig.Boss.class);var plan=boss.event;if(plan==null)return boss;plan.validate();
        if(plan.shiny>=0)boss.shiny=new Random(plan.seed^0x5348494e59L).nextDouble()<plan.shiny;
        if(plan.rage)boss.damageMultiplier=Math.min(100,boss.damageMultiplier*1.5);
        var rewards=(RaidRewardSettings)get(mod,"rewardSettings");
        if(!rewards.integrations.enabled&&(plan.drop!=1||plan.tokens!=1||plan.rage))throw new IllegalStateException("Bônus de recompensas exigem integrações modulares habilitadas");
        boss.validate();return boss;
    }
    /** Executed after entity insertion, immediately before the existing atomic state save. */
    static void consumeActive(ShirokaiRaids mod){
        Object active=get(mod,"active");var boss=(RaidConfig.Boss)get(active,"definition");if(boss.event==null)return;
        var reward=(RaidRewardSettings)get(active,"rewardSettings");reward.event=copy(boss.event);
        var e=state(mod).events;e.next=new RaidEventPlan();
        if(boss.event.duo&&boss.event.stage==1){e.chainRaid=(String)get(active,"id");e.second=copy(boss.event);e.second.stage=2;e.second.seed=new Random(boss.event.seed^0x4455504c41L).nextLong();e.second.rarity=e.second.secondRarity;e.second.species="";e.second.excludedSpecies=boss.species.contains(":")?boss.species:"cobblemon:"+boss.species;e.safeSince=0;e.waitingSince=0;}
        else if(boss.event.duo){e.chainRaid="";e.second=null;e.safeSince=0;e.waitingSince=0;}
    }
    /** The original finish saves this alongside rewards/completed before cleanup. */
    static void finished(ShirokaiRaids mod,RaidArchive.Outcome outcome){
        var e=state(mod).events;var active=get(mod,"active");if(active==null||!Objects.equals(get(active,"id"),e.chainRaid))return;
        e.chainRaid="";e.safeSince=0;if(outcome==RaidArchive.Outcome.VICTORY)e.waitingSince=System.currentTimeMillis();else{e.second=null;e.waitingSince=0;}
    }
    static void applyIvs(Pokemon pokemon,RaidConfig.Boss boss){if(boss.event==null)return;int mask=boss.event.ivMask();var stats=List.of(Stats.HP,Stats.ATTACK,Stats.DEFENCE,Stats.SPECIAL_ATTACK,Stats.SPECIAL_DEFENCE,Stats.SPEED);for(int i=0;i<6;i++)if((mask&(1<<i))!=0)pokemon.setIV(stats.get(i),31);if(mask!=0)pokemon.heal();}
    static void captureIvs(PokemonEntity entity,RaidConfig.Boss boss){applyIvs(entity.getPokemon(),boss);}
    static boolean safe(ShirokaiRaids mod,long now){
        if(get(mod,"active")!=null||get(mod,"victory")!=null)return false;
        var captures=(RaidCapture)get(mod,"captures");if(captures!=null&&captures.anyActive())return false;
        var state=state(mod);if(state.captures.values().stream().anyMatch(g->!g.resolved&&g.expiresAt>now))return false;
        for(var player:server.getPlayerList().getPlayers())if(state.returns.containsKey(player.getUUID().toString())||RaidInventory.locked(player))return false;
        return true;
    }
    private static void tick(ShirokaiRaids mod,long now){
        if(mod==null||!Boolean.TRUE.equals(get(mod,"healthy")))return;var e=state(mod).events;
        if(e.vote!=null&&now>=e.vote.ends){
            var vote=e.vote;int[] count=new int[vote.options.size()];for(int n:vote.votes.values())count[n]++;int best=Arrays.stream(count).max().orElse(0);var ties=new ArrayList<Integer>();for(int i=0;i<count.length;i++)if(count[i]==best)ties.add(i);
            var next=copy(e.next);next.species=vote.options.get(ties.get(new Random(next.seed).nextInt(ties.size())));select(mod,next);
            e.next=next;e.vote=null;save(mod);announce("Voz dos Treinadores encerrada! Próximo boss: &e"+next.species.replace("cobblemon:","")+"&f.");
        }
        if(e.second==null||!e.chainRaid.isEmpty())return;
        if(e.waitingSince==0)e.waitingSince=now;
        if(now-e.waitingSince>settings.duoMaximumWaitSeconds*1000L){e.second=null;e.safeSince=0;e.waitingSince=0;save(mod);announce("Desafio Duplo interrompida: não foi possível liberar a arena com segurança. Prêmios da primeira etapa preservados.");return;}
        if(!safe(mod,now)){if(e.safeSince!=0){e.safeSince=0;save(mod);}return;}
        if(e.safeSince==0){e.safeSince=now;save(mod);if(!e.second.chainId.equals(announcedDuo)){announcedDuo=e.second.chainId;announce("Desafio Duplo: segunda raid em &e"+settings.duoDelaySeconds+"s&f.");}return;}
        if(now-e.safeSince<settings.duoDelaySeconds*1000L)return;
        try{start(mod,copy(e.second),false);}catch(RuntimeException error){e.second=null;e.safeSince=0;e.waitingSince=0;save(mod);announce("Segunda etapa cancelada por segurança; prêmios preservados.");log("Dupla não iniciada: "+error);}
    }
    private static String eventName(String command){return switch(command){case "shiny"->"Sorte Shiny";case "ivs"->"IVs Perfeitos";case "drop"->"Drop Turbinado";case "token","tokens"->"Tokens Extras";case "invasao"->"Chamado Lendário";case "elemental"->"Raid Elemental";case "votacao"->"Voz dos Treinadores";case "enfurecido"->"Boss Enfurecido";case "dupla"->"Desafio Duplo";default->command;};}
    private static String shortNames(RaidEventPlan plan){var names=RaidEventPresentation.names(plan);return names.getFirst()+(names.size()>1?" e +"+(names.size()-1)+" bônus":"");}
    private static String voteText(RaidEventState.Vote vote){var text=new StringBuilder("Voz dos Treinadores: ");for(int i=0;i<vote.options.size();i++)text.append(i+1).append(" = ").append(vote.options.get(i)).append("; ");return text+"use /raid votar <número>. Restam "+Math.max(0,(vote.ends-System.currentTimeMillis())/1000)+"s. Um voto por jogador; pode trocar.";}
    private static void loadSettings()throws Exception{Path path=(Path)get(mod(),"configDir");path=path.resolve("events.json");JsonFiles.defaultFile(path,new Settings());var candidate=JsonFiles.read(path,Settings.class);candidate.validate();settings=candidate;}
    static RaidEventPlan copy(RaidEventPlan p){return JsonFiles.copy(p,RaidEventPlan.class);}
    static ShirokaiRaids mod(){return (ShirokaiRaids)getStatic(ShirokaiRaids.class,"instance");}
    static RaidState state(ShirokaiRaids mod){return (RaidState)get(mod,"state");}
    static Object get(Object owner,String field){try{Field f=owner.getClass().getDeclaredField(field);f.setAccessible(true);return f.get(owner);}catch(ReflectiveOperationException error){throw new IllegalStateException("Campo incompatível: "+field,error);}}
    private static Object getStatic(Class<?> owner,String field){try{var f=owner.getDeclaredField(field);f.setAccessible(true);return f.get(null);}catch(ReflectiveOperationException error){throw new IllegalStateException(error);}}
    static Object call(Object owner,String name,Class<?>[] types,Object... args){try{var method=owner.getClass().getDeclaredMethod(name,types);method.setAccessible(true);return method.invoke(owner,args);}catch(InvocationTargetException error){if(error.getCause() instanceof RuntimeException r)throw r;throw new IllegalStateException(error.getCause());}catch(ReflectiveOperationException error){throw new IllegalStateException("Método incompatível: "+name,error);}}
    static void save(ShirokaiRaids mod){call(mod,"save",new Class<?>[0]);}
    static Component text(String message){return RaidMessages.chat(message);}
    private static void reply(CommandSourceStack source,String message){source.sendSuccess(()->text(message),false);}
    private static void announce(String message){if(server!=null)server.getPlayerList().broadcastSystemMessage(text(message),false);else log(message);}
    static int duoDelaySeconds(){return settings.duoDelaySeconds;}
    static int eventBarSeconds(){return settings.eventBarSeconds;}
    static int normalBarSeconds(){return settings.eventBarIntervalSeconds-settings.eventBarSeconds;}
    private static void log(String message){LoggerFactory.getLogger("zorykai-raid-events").info(message);}
}
