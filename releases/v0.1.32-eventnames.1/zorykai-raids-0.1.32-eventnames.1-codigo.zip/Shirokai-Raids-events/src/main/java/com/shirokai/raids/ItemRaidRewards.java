package com.shirokai.raids;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.Items;
import java.math.BigDecimal;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

/** Native item rewards use the existing durable inventory + per-transaction receipt protocol. */
final class ItemRaidRewards implements RaidRewardHandler {
    private final MinecraftServer server;
    ItemRaidRewards(MinecraftServer server){this.server=server;}
    public boolean hasReceipt(UUID owner,String transaction){var player=server.getPlayerList().getPlayer(owner);return player!=null&&new PlayerRewardTarget(server,player,"shirokai_modular:").received(transaction);}
    public CompletionStage<Boolean> confirmReceipt(UUID owner,String transaction){try{return CompletableFuture.completedFuture(PlayerRewardTarget.confirmExistingReceipt(server,owner,transaction));}catch(Exception e){return CompletableFuture.failedFuture(e);}}
    public boolean retrySafe(){return true;}
    public boolean available(String reference){
        var id=ResourceLocation.tryParse(reference);
        return id!=null&&BuiltInRegistries.ITEM.containsKey(id)&&BuiltInRegistries.ITEM.get(id)!=Items.AIR;
    }
    public boolean ready(UUID id,String transaction,String reference,BigDecimal amount){
        var player=server.getPlayerList().getPlayer(id);
        if(player==null||RaidInventory.locked(player)||!available(reference))return false;
        try {
            var target=new PlayerRewardTarget(server,player,"shirokai_modular:");
            if(target.received(transaction))return true;
            int count=amount.intValueExact();
            var transfer=target.plan(reference,count);
            return transfer!=null&&transfer.count()==count;
        }catch(RuntimeException invalid){return true;} // Let deliver preserve/report a permanent error.
    }
    public CompletionStage<Result> deliver(UUID id,String transaction,String reference,BigDecimal amount){
        var player=server.getPlayerList().getPlayer(id);
        if(player==null||RaidInventory.locked(player)||!available(reference))return CompletableFuture.completedFuture(Result.RETRY);
        try{
            int count=amount.intValueExact();if(count<1)throw new IllegalArgumentException("Quantidade de item inválida");
            var target=new PlayerRewardTarget(server,player,"shirokai_modular:");
            if(!target.received(transaction)){
                var transfer=target.plan(reference,count);
                if(transfer==null||transfer.count()!=count)return CompletableFuture.completedFuture(Result.RETRY);
                transfer.apply(transaction);
            }
            target.saveAndVerify(transaction);
            return CompletableFuture.completedFuture(Result.APPLIED);
        }catch(Exception error){return CompletableFuture.failedFuture(error);}
    }
}
