package com.shirokai.raids;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;
import java.math.BigDecimal;
import com.shirokai.raids.core.RaidDamageTracker;

class HeldItemPolicyTest {
    static final UUID PLAYER=new UUID(0,1);
    RaidRewardSettings settings(){var s=RaidRewardSettings.defaults();var held=new RaidRewardSettings.Reward("band","item","cobblemon:choice_band",3,3);held.chance=1;s.general.pools.put("normal",List.of(held,new RaidRewardSettings.Reward("candy","item","cobblemon:exp_candy_l",5,5)));s.top3.chances.put("normal",List.of(0d,0d,0d));return s;}
    String award(RaidRewardJournal.Data data,RaidRewardSettings s){String raid=UUID.randomUUID().toString();new RaidRewardJournal(data,()->{},Runnable::run,x->{}).award(raid,"boss","normal",100,List.of(new RaidDamageTracker.Entry(PLAYER,"P",100,1,1,Set.of())),s,new Random(3));return raid;}
    long held(RaidRewardJournal.Data data,String raid){return data.grants.values().stream().filter(g->g.raid.equals(raid)&&g.choice.reward.reference.equals("cobblemon:choice_band")).count();}
    @Test void blockNextEligibleVictoryThenAllowAgain(){var d=new RaidRewardJournal.Data();var s=settings();String a=award(d,s),b=award(d,s),c=award(d,s);assertEquals(1,held(d,a));assertEquals(0,held(d,b));assertEquals(1,held(d,c));assertEquals(3,d.grants.values().stream().filter(g->g.choice.reward.reference.equals("cobblemon:exp_candy_l")).count());}
    @Test void singleHeldQuantityEvenWithRage(){var d=new RaidRewardJournal.Data();var s=settings();s.event=new RaidEventPlan();s.event.rage=true;String raid=award(d,s);assertEquals(BigDecimal.ONE,d.grants.values().stream().filter(g->g.raid.equals(raid)&&g.choice.reward.reference.equals("cobblemon:choice_band")).findFirst().orElseThrow().choice.amount);}
    @Test void persistsCooldownWithoutChangingOldPendingPrizes(){var d=new RaidRewardJournal.Data();var s=settings();String a=award(d,s);var copy=JsonFiles.copy(d,RaidRewardJournal.Data.class);copy.validate();assertEquals(0,held(copy,award(copy,s)));assertEquals(1,held(copy,a));assertEquals(RaidRewardJournal.Status.PENDING,copy.grants.values().iterator().next().status);}
    @Test void sameRaidCannotAwardSameHeldFromGeneralAndSpecial(){var d=new RaidRewardJournal.Data();var s=settings();var held=new RaidRewardSettings.Reward("other_band","item","cobblemon:choice_band",1,1);s.special.pools.put("normal",List.of(held));s.top3.chances.put("normal",List.of(1d,1d,1d));assertEquals(1,held(d,award(d,s)));}
    @Test void otherPlayersDoNotBurnOwnersCooldown(){var d=new RaidRewardJournal.Data();var s=settings();award(d,s);var j=new RaidRewardJournal(d,()->{},Runnable::run,x->{});j.award(UUID.randomUUID().toString(),"boss","normal",100,List.of(new RaidDamageTracker.Entry(new UUID(0,2),"Other",100,1,1,Set.of())),s,new Random(1));assertEquals(0,held(d,award(d,s)));}
    @Test void retrySameAwardDoesNotAdvanceCooldownTwice(){var d=new RaidRewardJournal.Data();var s=settings();String raid=award(d,s);var before=JsonFiles.copy(d,RaidRewardJournal.Data.class);new RaidRewardJournal(d,()->{},Runnable::run,x->{}).award(raid,"boss","normal",100,List.of(),s,new Random(1));assertEquals(before.heldHistory,d.heldHistory);}
    @Test void configuredTwoRaidCooldownAndDisable(){var d=new RaidRewardJournal.Data();var s=settings();s.integrations.heldItemCooldownRaids=2;assertEquals(1,held(d,award(d,s)));assertEquals(0,held(d,award(d,s)));assertEquals(0,held(d,award(d,s)));assertEquals(1,held(d,award(d,s)));s.integrations.heldItemCooldownRaids=0;assertEquals(1,held(d,award(d,s)));}
    @Test void settingsRejectInvalidBounds(){var s=settings();s.integrations.heldItemCooldownRaids=11;assertThrows(IllegalArgumentException.class,()->HeldItemPolicy.validate(s.integrations));}
    @Test void cooldownIsStoredBeforeManualRedemption(){var d=new RaidRewardJournal.Data();var s=settings();award(d,s);assertTrue(d.grants.values().stream().allMatch(g->g.status==RaidRewardJournal.Status.PENDING));assertEquals(0,held(d,award(d,s)));}
}
