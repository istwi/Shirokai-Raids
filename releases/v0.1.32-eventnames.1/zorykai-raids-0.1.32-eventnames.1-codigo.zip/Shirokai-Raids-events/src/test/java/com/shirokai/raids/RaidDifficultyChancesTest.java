package com.shirokai.raids;
import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
class RaidDifficultyChancesTest {
 static List<RaidAutomaticCatalog.Species> pool(){
  var a=new ArrayList<RaidAutomaticCatalog.Species>();
  int[] powers={500,550,610,600,700};
  for(int i=0;i<5;i++){int stat=powers[i]/6;int hp=powers[i]-stat*5;
   a.add(new RaidAutomaticCatalog.Species("cobblemon:test"+i,"test"+i,true,true,hp,stat,stat,stat,stat,stat,2,i>=3?Set.of("legendary"):Set.of(),List.of("tackle","scratch")));}
  return a;
 }
 @Test void distributionUsesDifficultyRatherThanSpeciesCount(){
  var c=new RaidCatalogSettings();c.minimumOffense=70;c.minimumBaseStats=400;
  var pool=new ArrayList<>(pool());var common=pool.getFirst();
  for(int i=0;i<100;i++)pool.add(new RaidAutomaticCatalog.Species("cobblemon:extra"+i,"extra",true,true,common.hp(),common.attack(),common.defence(),common.specialAttack(),common.specialDefence(),common.speed(),2,Set.of(),common.moves()));
  var counts=new HashMap<String,Integer>();var random=new Random(241);
  for(int i=0;i<100000;i++)counts.merge(RaidAutomaticCatalog.chooseDifficulty(pool,c,random),1,Integer::sum);
  for(var key:RaidCatalogSettings.ORDER)assertEquals(c.difficultyWeights.get(key)/100,counts.getOrDefault(key,0)/100000d,.008,key);
 }
 @Test void singleDifficultyAndZeroWeightsAreRespectedIncludingSpecialOnFirstRaid(){
  for(String id:RaidCatalogSettings.ORDER){var c=new RaidCatalogSettings();c.minimumOffense=70;c.minimumBaseStats=400;c.difficultyWeights.replaceAll((k,v)->k.equals(id)?100d:0d);c.validate();
   for(int i=0;i<40;i++){var draw=RaidAutomaticCatalog.draw(pool(),c,0,List.of(),List.of(),new Random(i));assertEquals(id,draw.boss().difficulty);assertEquals(Set.of("lendario","supremo").contains(id),draw.special());}
  }
 }
 @Test void unavailableCategoriesRedistributeOnlyAmongEnabledAvailableOnes(){
  var c=new RaidCatalogSettings();c.minimumOffense=70;c.minimumBaseStats=400;
  for(int i=0;i<100;i++)assertEquals("normal",RaidAutomaticCatalog.chooseDifficulty(List.of(pool().getFirst()),c,new Random(i)));
  c.difficultyWeights.replaceAll((k,v)->k.equals("supremo")?100d:0d);
  assertThrows(IllegalStateException.class,()->RaidAutomaticCatalog.draw(List.of(pool().getFirst()),c,0,List.of(),List.of(),new Random()));
 }
 @Test void invalidWeightsModeAndTotalsAreRejected(){
  for(double value:new double[]{-1,Double.NaN,Double.POSITIVE_INFINITY,101}){var c=new RaidCatalogSettings();c.difficultyWeights.put("normal",value);assertThrows(IllegalArgumentException.class,c::validate);}
  var c=new RaidCatalogSettings();c.difficultyWeights.put("normal",20d);assertThrows(IllegalArgumentException.class,c::validate);
  c=new RaidCatalogSettings();c.difficultyWeights.remove("raro");var missing=c;assertThrows(IllegalArgumentException.class,missing::validate);
  c=new RaidCatalogSettings();c.selectionMode="unknown";var invalid=c;assertThrows(IllegalArgumentException.class,invalid::validate);
 }
 @Test void oldConfigLoadsWithNewDefaultsWithoutChangingProfilesOrHistory(){
  var c=new com.google.gson.Gson().fromJson("{\"expectedPlayers\":7}",RaidCatalogSettings.class);
  assertTrue(c.weighted());assertEquals(7,c.expectedPlayers);assertEquals(12d,c.difficultyWeights.get("lendario"));
  var state=new com.google.gson.Gson().fromJson("{\"automaticRaidStarts\":19,\"catalogRecentSpecial\":[\"cobblemon:mewtwo\"]}",RaidState.class);state.validate();assertEquals(19,state.automaticRaidStarts);assertEquals(1,state.catalogRecentSpecial.size());
 }
 @Test void adminMenuDoesNotPromiseCountdownInWeightedMode(){
  var p=new RaidSpecialMenu.Progress(19,true,true,"weighted",RaidCatalogSettings.defaultWeights());
  assertTrue(p.lines().stream().anyMatch(s->s.contains("não há contagem")));assertFalse(p.lines().contains("A próxima raid automática será especial!"));
 }
}
