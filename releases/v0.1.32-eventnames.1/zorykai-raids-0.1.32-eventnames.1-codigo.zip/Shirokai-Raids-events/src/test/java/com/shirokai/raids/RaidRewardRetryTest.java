package com.shirokai.raids;
import com.shirokai.raids.core.RaidDamageTracker;
import org.junit.jupiter.api.Test;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;
class RaidRewardRetryTest {
    private RaidRewardJournal.Data pending(){
        var settings=RaidRewardSettings.defaults();settings.general.pools.put("normal",List.of(new RaidRewardSettings.Reward("coins","currency","impactor:dollars",100,100)));settings.top3.chances.put("normal",List.of(0d,0d,0d));
        var data=new RaidRewardJournal.Data();new RaidRewardJournal(data,()->{},Runnable::run,s->{}).award(UUID.randomUUID().toString(),"rayquaza","normal",1000,List.of(new RaidDamageTracker.Entry(UUID.randomUUID(),"Owner",1000,1,1,Set.of())),settings,new Random(1));return data;
    }
    @Test void thousandOfflineReservationsCauseZeroDeliveriesWritesOrLogsForSimulatedHour(){
        var data=pending();var original=data.grants.values().iterator().next();data.grants.clear();
        for(int i=0;i<1000;i++){var g=JsonFiles.copy(original,RaidRewardJournal.Grant.class);g.id=UUID.randomUUID().toString();g.player=new UUID(0,i+1).toString();data.grants.put(g.id,g);}
        var writes=new AtomicInteger();var logs=new AtomicInteger();var calls=new AtomicInteger();var available=new AtomicInteger();var clock=new AtomicLong();
        var e=new RaidRewardJournal(data,writes::incrementAndGet,Runnable::run,s->logs.incrementAndGet(),clock::get);e.online(id->false);
        e.register("currency",new RaidRewardHandler(){public boolean available(String ref){available.incrementAndGet();return true;}public CompletionStage<Result> deliver(UUID p,String tx,String ref,BigDecimal n){calls.incrementAndGet();return CompletableFuture.completedFuture(Result.APPLIED);}});
        e.recover();for(int i=0;i<3600;i++){clock.addAndGet(1000);e.tick(4);}
        assertEquals(0,calls.get());assertEquals(0,writes.get());assertEquals(0,logs.get());assertEquals(0,available.get());assertEquals(1000,data.grants.size());assertTrue(data.grants.values().stream().allMatch(g->g.status==RaidRewardJournal.Status.PENDING));
        var target=new UUID(0,1000);e.online(id->id.equals(target));e.wake(target);e.tick(4);assertEquals(1,calls.get());assertEquals(2,writes.get());assertEquals(1,data.grants.values().stream().filter(g->g.status==RaidRewardJournal.Status.DONE).count());
    }
    @Test void blockedPreflightBacksOffWithoutPersistingAndControlledWakeDeliversExactlyOnce(){
        var data=pending();var g=data.grants.values().iterator().next();var clock=new AtomicLong();var writes=new AtomicInteger();var logs=new AtomicInteger();var readyCalls=new AtomicInteger();var delivered=new AtomicInteger();var space=new AtomicBoolean();
        var e=new RaidRewardJournal(data,writes::incrementAndGet,Runnable::run,s->logs.incrementAndGet(),clock::get);
        e.register("currency",new RaidRewardHandler(){public boolean available(String r){return true;}public boolean ready(UUID p,String tx,String ref,BigDecimal amount){readyCalls.incrementAndGet();return space.get();}public CompletionStage<Result> deliver(UUID p,String tx,String ref,BigDecimal amount){delivered.incrementAndGet();return CompletableFuture.completedFuture(Result.APPLIED);}});
        for(int i=0;i<1000;i++){clock.set(i);e.tick(4);}assertEquals(1,readyCalls.get());assertEquals(0,writes.get());assertEquals(0,logs.get());
        clock.set(10000);e.tick(4);assertEquals(2,readyCalls.get());clock.set(39999);e.tick(4);assertEquals(2,readyCalls.get());clock.set(40000);e.tick(4);assertEquals(3,readyCalls.get());clock.set(100000);e.tick(4);assertEquals(4,readyCalls.get());
        space.set(true);clock.set(100001);e.tick(4);assertEquals(0,delivered.get());e.attempt(UUID.fromString(g.player),4);assertEquals(1,delivered.get());assertEquals(RaidRewardJournal.Status.DONE,g.status);e.attempt(UUID.fromString(g.player),4);assertEquals(1,delivered.get());assertEquals(2,writes.get());
    }
    @Test void providerRetryIsDurablyPreservedButDoesNotSpamConsoleOrWriteEveryTick(){
        var data=pending();var clock=new AtomicLong();var calls=new AtomicInteger();var writes=new AtomicInteger();var logs=new AtomicInteger();
        var e=new RaidRewardJournal(data,writes::incrementAndGet,Runnable::run,s->logs.incrementAndGet(),clock::get);e.register("currency",new RaidRewardHandler(){public boolean available(String r){return true;}public CompletionStage<Result> deliver(UUID p,String tx,String ref,BigDecimal n){calls.incrementAndGet();return CompletableFuture.completedFuture(Result.RETRY);}});
        e.tick(4);for(int i=0;i<1000;i++){clock.set(i);e.tick(4);}assertEquals(1,calls.get());assertEquals(2,writes.get());assertEquals(0,logs.get());assertEquals(RaidRewardJournal.Status.PENDING,data.grants.values().iterator().next().status);clock.set(10000);e.tick(4);assertEquals(2,calls.get());assertEquals(4,writes.get());assertEquals(0,logs.get());
    }
    @Test void disconnectDuringAsyncOwnershipQueryDoesNotStartExternalDelivery(){
        var data=pending();var g=data.grants.values().iterator().next();g.choice.reward.type="title";g.choice.reward.reference="raid_champion";g.resolved=false;var online=new AtomicBoolean(true);var query=new CompletableFuture<Boolean>();var calls=new AtomicInteger();
        var e=new RaidRewardJournal(data,()->{},Runnable::run,s->{});e.online(id->online.get());e.register("title",new RaidRewardHandler(){public boolean available(String r){return true;}public CompletionStage<Boolean> owns(UUID p,String r){return query;}public CompletionStage<Result> deliver(UUID p,String tx,String ref,BigDecimal n){calls.incrementAndGet();return CompletableFuture.completedFuture(Result.APPLIED);}});
        e.tick(4);online.set(false);query.complete(false);assertEquals(0,calls.get());assertEquals(RaidRewardJournal.Status.PENDING,g.status);online.set(true);e.wake(UUID.fromString(g.player));e.tick(4);assertEquals(1,calls.get());assertEquals(RaidRewardJournal.Status.DONE,g.status);
    }
    @Test void manualWakeCannotReplayUncertainOrInFlightTransactions(){
        for(var status:List.of(RaidRewardJournal.Status.UNCERTAIN,RaidRewardJournal.Status.IN_FLIGHT)){var data=pending();var g=data.grants.values().iterator().next();g.status=status;var calls=new AtomicInteger();var e=new RaidRewardJournal(data,()->{},Runnable::run,s->{});e.register("currency",new RaidRewardHandler(){public boolean available(String r){return true;}public CompletionStage<Result> deliver(UUID p,String tx,String ref,BigDecimal n){calls.incrementAndGet();return CompletableFuture.completedFuture(Result.APPLIED);}});e.attempt(UUID.fromString(g.player),4);assertEquals(0,calls.get());assertEquals(status,g.status);}
    }

    @Test void manualModeHasNoAutomaticWorkAndOnlySelectedAwardIsAuthorized(){
        var data=pending();var first=data.grants.values().iterator().next();var second=JsonFiles.copy(first,RaidRewardJournal.Grant.class);second.id=UUID.randomUUID().toString();data.grants.put(second.id,second);var calls=new AtomicInteger();var writes=new AtomicInteger();var e=new RaidRewardJournal(data,writes::incrementAndGet,Runnable::run,line->{});e.manual(true);e.register("currency",new RaidRewardHandler(){public boolean available(String r){return true;}public CompletionStage<Result> deliver(UUID p,String id,String ref,BigDecimal n){calls.incrementAndGet();return CompletableFuture.completedFuture(Result.APPLIED);}});
        for(int i2=0;i2<10000;i2++)e.tick(4);assertEquals(0,writes.get());assertEquals(0,calls.get());assertFalse(e.requestOne(UUID.randomUUID(),first.id));assertTrue(e.requestOne(UUID.fromString(first.player),first.id));assertEquals(1,calls.get());assertEquals(RaidRewardJournal.Status.DONE,first.status);for(int i2=0;i2<1000;i2++)e.tick(4);assertEquals(RaidRewardJournal.Status.PENDING,second.status);assertEquals(1,calls.get());
    }
    @Test void failedManualRequestDoesNotAutomaticallyResumeAfterSpaceOrReconnect(){
        var data=pending();var g=data.grants.values().iterator().next();var space=new AtomicBoolean(false);var online=new AtomicBoolean(true);var calls=new AtomicInteger();var clock=new AtomicLong();var e=new RaidRewardJournal(data,()->{},Runnable::run,s->{},clock::get);e.manual(true);e.online(id->online.get());e.register("currency",new RaidRewardHandler(){public boolean available(String r){return true;}public boolean ready(UUID p,String tx,String ref,BigDecimal n){return space.get();}public CompletionStage<Result> deliver(UUID p,String id,String ref,BigDecimal n){calls.incrementAndGet();return CompletableFuture.completedFuture(Result.APPLIED);}});
        e.requestOne(UUID.fromString(g.player),g.id);space.set(true);clock.set(1000000);for(int i2=0;i2<100;i2++)e.tick(4);assertEquals(0,calls.get());online.set(false);e.requestOne(UUID.fromString(g.player),g.id);online.set(true);e.wake(UUID.fromString(g.player));e.tick(4);assertEquals(0,calls.get());e.requestOne(UUID.fromString(g.player),g.id);assertEquals(1,calls.get());
    }

    @Test void asynchronousPreparationCannotResumeCanceledManualClaimOnFastReconnect(){
        var data=pending();var g=data.grants.values().iterator().next();g.choice.reward.type="title";g.choice.reward.reference="raid_champion";g.resolved=false;var query=new CompletableFuture<Boolean>();var calls=new AtomicInteger();var e=new RaidRewardJournal(data,()->{},Runnable::run,s->{});e.manual(true);e.register("title",new RaidRewardHandler(){public boolean available(String r){return true;}public CompletionStage<Boolean> owns(UUID p,String r){return query;}public CompletionStage<Result> deliver(UUID p,String tx,String ref,BigDecimal n){calls.incrementAndGet();return CompletableFuture.completedFuture(Result.APPLIED);}});
        var owner=UUID.fromString(g.player);e.requestOne(owner,g.id);e.cancel(owner);e.wake(owner);query.complete(false);e.tick(4);assertEquals(0,calls.get());assertEquals(RaidRewardJournal.Status.PENDING,g.status);e.requestOne(owner,g.id);assertEquals(1,calls.get());
    }
}
