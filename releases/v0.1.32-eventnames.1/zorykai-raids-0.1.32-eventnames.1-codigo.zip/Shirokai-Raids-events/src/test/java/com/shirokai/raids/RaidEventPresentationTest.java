package com.shirokai.raids;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class RaidEventPresentationTest {
 @Test void alternatesWithoutStarvingNormalTitle(){assertTrue(RaidEventPresentation.eventWindow(0,4,8));assertTrue(RaidEventPresentation.eventWindow(3999,4,8));assertFalse(RaidEventPresentation.eventWindow(4000,4,8));assertFalse(RaidEventPresentation.eventWindow(11999,4,8));assertTrue(RaidEventPresentation.eventWindow(12000,4,8));}
 @Test void rotatesEachEventAcrossCycles(){assertEquals(0,RaidEventPresentation.eventIndex(0,4,8,3));assertEquals(1,RaidEventPresentation.eventIndex(12000,4,8,3));assertEquals(2,RaidEventPresentation.eventIndex(24000,4,8,3));assertEquals(0,RaidEventPresentation.eventIndex(36000,4,8,3));}
 @Test void raritySelectionAloneIsNotSpecialEvent(){var p=new RaidEventPlan();p.rarity="epico";assertTrue(RaidEventPresentation.names(p).isEmpty());}
 @Test void fractionalPercentIsNotRoundedToZero(){var p=new RaidEventPlan();p.shiny=.001;assertTrue(RaidEventPresentation.names(p).getFirst().contains("0.1%"));}
}
