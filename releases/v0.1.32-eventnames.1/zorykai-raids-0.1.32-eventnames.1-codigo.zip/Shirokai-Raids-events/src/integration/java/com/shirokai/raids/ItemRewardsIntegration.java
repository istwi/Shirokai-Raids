package com.shirokai.raids;
import net.fabricmc.api.ModInitializer;
import com.shirokai.raids.core.RaidDamageTracker;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.*;
import net.minecraft.server.players.PlayerList;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.*;
import net.minecraft.nbt.*;
import net.minecraft.world.level.storage.LevelResource;
import com.mojang.authlib.GameProfile;
import java.lang.reflect.*;
import java.math.BigDecimal;
import java.nio.file.*;
import java.util.*;

public final class ItemRewardsIntegration implements ModInitializer {
 int ticks,phase,checks;boolean done;ServerPlayer player;RaidRewardJournal journal;RaidState state;RaidRewardSettings settings;Map<String,Integer> expected=new LinkedHashMap<>();String replay;
 void require(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
 ServerPlayer add(MinecraftServer s,UUID id)throws Exception{
  var p=new ServerPlayer(s,s.overworld(),new GameProfile(id,"ItemRewardProbe"),ClientInformation.createDefault());
  p.connection=FakePlayer.get(s.overworld(),new GameProfile(UUID.randomUUID(),"RewardConnection")).connection;p.connection.player=p;
  for(var field:PlayerList.class.getDeclaredFields())if(field.getGenericType() instanceof ParameterizedType type&&type.getRawType()==Map.class&&Arrays.equals(type.getActualTypeArguments(),new Type[]{UUID.class,ServerPlayer.class})){field.setAccessible(true);((Map<UUID,ServerPlayer>)field.get(s.getPlayerList())).put(id,p);break;}
  s.getPlayerList().getPlayers().removeIf(x->x.getUUID().equals(id));s.getPlayerList().getPlayers().add(p);return p;
 }
 int count(String reference){var item=BuiltInRegistries.ITEM.get(ResourceLocation.parse(reference));int n=0;for(var stack:player.getInventory().items)if(stack.is(item))n+=stack.getCount();return n;}
 public void onInitialize(){ServerTickEvents.END_SERVER_TICK.register(s->{if(done||++ticks<30)return;try{
  if(phase==0){
   var f=ShirokaiRaids.class.getDeclaredField("instance");f.setAccessible(true);var mod=f.get(null);var field=ShirokaiRaids.class.getDeclaredField("modularRewards");field.setAccessible(true);journal=(RaidRewardJournal)field.get(mod);
   field=ShirokaiRaids.class.getDeclaredField("state");field.setAccessible(true);state=(RaidState)field.get(mod);
   require(journal.handlers().containsKey("item"),"Production startup registers item handler");var handler=journal.handlers().get("item");require(handler.retrySafe(),"Native receipt handler is retry-safe");
   settings=RaidRewardSettings.load(Path.of("fixture-rewards"));
   for(var list:settings.general.pools.values())for(var reward:list)if(reward.type.equals("item"))require(handler.available(reward.reference),"Actual Cobblemon registry contains "+reward.reference);
   player=add(s,UUID.randomUUID());
   for(var reward:settings.general.pools.get("normal")){reward.chance=reward.type.equals("item")?1:0;if(reward.type.equals("item"))expected.put(reward.reference,(int)reward.minimum);}
   for(var row:settings.top3.chances.entrySet())row.setValue(List.of(0d,0d,0d));
   journal.award(UUID.randomUUID().toString(),"fixture_boss","normal",1000,List.of(new RaidDamageTracker.Entry(player.getUUID(),"ItemRewardProbe",1000,1,1,Set.of())),settings,new Random(7));
   require(state.modularRewards.grants.size()==34,"All 34 item rewards reserved through production award flow");journal.attempt(player.getUUID(),128);phase=1;
  }else if(phase==1){
   journal.tick(128);
   for(var g:state.modularRewards.grants.values())if(g.status==RaidRewardJournal.Status.UNCERTAIN)throw new AssertionError(g.audit.toString());
   if(state.modularRewards.grants.values().stream().allMatch(g->g.status==RaidRewardJournal.Status.DONE)){
    for(var e:expected.entrySet())require(count(e.getKey())==e.getValue(),"Actual item delivered: "+e.getKey());
    require(expected.size()==34,"All configured item kinds covered");
    var grant=state.modularRewards.grants.values().iterator().next();replay=grant.id;var handler=journal.handlers().get("item");int before=count(grant.choice.reward.reference);
    require(handler.deliver(player.getUUID(),replay,grant.choice.reward.reference,grant.choice.amount).toCompletableFuture().join()==RaidRewardHandler.Result.APPLIED,"Duplicate transaction is acknowledged from receipt");require(count(grant.choice.reward.reference)==before,"Replay does not duplicate items");
    var saved=NbtIo.readCompressed(s.getWorldPath(LevelResource.PLAYER_DATA_DIR).resolve(player.getUUID()+".dat"),NbtAccounter.unlimitedHeap());var id=player.getUUID();player=add(s,id);player.load(saved);
    for(var e:expected.entrySet())require(count(e.getKey())==e.getValue(),"Saved and reloaded inventory retains "+e.getKey());
    require(handler.deliver(id,replay,grant.choice.reward.reference,grant.choice.amount).toCompletableFuture().join()==RaidRewardHandler.Result.APPLIED,"Persisted receipt acknowledges replay after player reload");require(count(grant.choice.reward.reference)==before,"Player reload replay does not duplicate");
    require(handler.deliver(UUID.randomUUID(),UUID.randomUUID().toString(),"minecraft:apple",BigDecimal.ONE).toCompletableFuture().join()==RaidRewardHandler.Result.RETRY,"Offline player remains retryable");
    require(!handler.available("missing:not_an_item")&&!handler.available("minecraft:air"),"Invalid item references rejected");
    for(int i=0;i<36;i++)player.getInventory().items.set(i,new ItemStack(Items.STONE,64));String tx=UUID.randomUUID().toString();
    require(handler.deliver(id,tx,"minecraft:apple",BigDecimal.valueOf(4)).toCompletableFuture().join()==RaidRewardHandler.Result.RETRY,"Full inventory remains pending without drops");require(!player.getTags().contains("shirokai_modular:"+tx),"Failed capacity does not add receipt");
    player.getInventory().items.set(35,ItemStack.EMPTY);require(handler.deliver(id,tx,"minecraft:apple",BigDecimal.valueOf(4)).toCompletableFuture().join()==RaidRewardHandler.Result.APPLIED,"Retry delivers after inventory space opens");require(count("minecraft:apple")==4,"Exactly requested count after retry");
    finish(s,true,"Native item rewards delivered; receipt, reload, offline and capacity checks passed");
   }
  }
  if(ticks>800)throw new AssertionError("Timed out waiting for native item delivery");
 }catch(Throwable e){e.printStackTrace();finish(s,false,e.toString());}});}
 void finish(MinecraftServer s,boolean passed,String message){done=true;var result=new com.google.gson.JsonObject();result.addProperty("passed",passed);result.addProperty("checks",checks);result.addProperty("message",message);result.addProperty("itemTypes",expected.size());result.addProperty("uncertainFragmentsModified",false);try{Files.writeString(Path.of("item-rewards-results.json"),new com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(result));}catch(Exception e){throw new RuntimeException(e);}s.halt(false);}
}
