package com.shirokai.raids;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import java.util.*;
import java.nio.file.*;
public final class CatalogChancesIntegration implements ModInitializer {
 int ticks,checks;boolean done;Map<String,Integer> counts=new LinkedHashMap<>();Map<String,Long> available=new LinkedHashMap<>();
 void require(boolean yes,String message){checks++;if(!yes)throw new AssertionError(message);}
 public void onInitialize(){ServerTickEvents.END_SERVER_TICK.register(s->{if(done||++ticks!=30)return;done=true;var result=new com.google.gson.JsonObject();try{
  var settings=new RaidCatalogSettings();settings.validate();
  var species=RaidCatalogPokemon.species(settings);species.stream().filter(p->RaidAutomaticCatalog.eligible(p,settings)).forEach(p->available.merge(RaidAutomaticCatalog.difficulty(p),1L,Long::sum));
  require(available.keySet().containsAll(RaidCatalogSettings.ORDER),"Loaded Cobblemon species cover all five difficulties");
  var random=new Random(726);
  for(int i=0;i<10000;i++)counts.merge(RaidAutomaticCatalog.chooseDifficulty(species,settings,random),1,Integer::sum);
  for(String id:RaidCatalogSettings.ORDER)require(Math.abs(counts.get(id)/10000d-settings.difficultyWeights.get(id)/100)<.02,"Actual species distribution: "+id);
  for(String id:RaidCatalogSettings.ORDER){settings.difficultyWeights.replaceAll((k,v)->k.equals(id)?100d:0d);settings.validate();
   var draw=RaidAutomaticCatalog.draw(species,settings,0,List.of(),List.of(),random);require(draw.boss().difficulty.equals(id),"Forced category "+id);
   var pokemon=com.cobblemon.mod.common.api.pokemon.PokemonProperties.Companion.parse(draw.boss().species," ","=").create();
   pokemon.setLevel(draw.boss().level);RaidCatalogPokemon.train(pokemon,draw.boss());require(pokemon.getLevel()==draw.boss().level,"Native Pokemon generated/trained for "+id);
  }
  var path=Path.of("config/shirokai-raids/catalog.json");var old=Files.readString(path);try{
   var legacy=new RaidCatalogSettings();legacy.selectionMode="cycle";JsonFiles.write(path,legacy);s.getCommands().performPrefixedCommand(s.createCommandSourceStack(),"raidadmin reload");
   var f=ShirokaiRaids.class.getDeclaredField("instance");f.setAccessible(true);var mod=f.get(null);var cfg=ShirokaiRaids.class.getDeclaredField("catalogSettings");cfg.setAccessible(true);
   require(((RaidCatalogSettings)cfg.get(mod)).selectionMode.equals("cycle"),"Reload selects legacy cycle");
   var next=new RaidCatalogSettings();next.difficultyWeights.replaceAll((k,v)->k.equals("epico")?100d:0d);JsonFiles.write(path,next);s.getCommands().performPrefixedCommand(s.createCommandSourceStack(),"raidadmin reload");
   require(((RaidCatalogSettings)cfg.get(mod)).difficultyWeights.get("epico")==100d,"Reload applies edited chances");
   var progress=ShirokaiRaids.class.getDeclaredMethod("specialProgress");progress.setAccessible(true);var view=(RaidSpecialMenu.Progress)progress.invoke(mod);require(view.lines().stream().anyMatch(t->t.contains("epico: 100.0%")),"Production admin progress shows chances, not countdown");
   s.getCommands().performPrefixedCommand(s.createCommandSourceStack(),"raidadmin catalogo");
  }finally{Files.writeString(path,old);}
  result.addProperty("passed",true);
 }catch(Throwable e){e.printStackTrace();result.addProperty("passed",false);result.addProperty("error",e.toString());}finally{
  result.addProperty("checks",checks);result.add("availableSpecies",new com.google.gson.Gson().toJsonTree(available));result.add("distribution10000",new com.google.gson.Gson().toJsonTree(counts));try{Files.writeString(Path.of("catalog-chances-results.json"),new com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(result));}catch(Exception e){throw new RuntimeException(e);}s.halt(false);
 }});}
}
