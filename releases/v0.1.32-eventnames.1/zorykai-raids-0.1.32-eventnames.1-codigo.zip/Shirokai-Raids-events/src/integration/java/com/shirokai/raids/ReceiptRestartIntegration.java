package com.shirokai.raids;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.nbt.*;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.item.Items;
import com.shirokai.raids.core.RaidDamageTracker;
import java.util.*;
import java.util.concurrent.atomic.*;
import java.nio.file.*;
/** Test-only injected failure after actual inventory receipt save, followed by external SIGKILL. */
public final class ReceiptRestartIntegration implements ModInitializer {
 static final UUID OWNER=UUID.fromString("32c87885-d6c9-4bbb-bca4-14a7897be3c3");int ticks,checks;boolean done,started;RaidRewardJournal journal;RaidState state;String tx;net.minecraft.server.level.ServerPlayer player;
 void check(String name,boolean ok){checks++;if(!ok)throw new AssertionError(name);}
 public void onInitialize(){ServerTickEvents.END_SERVER_TICK.register(s->{if(done||++ticks<30)return;try{if(!started){started=true;setup(s);}else if(System.getProperty("raid.receipt.phase").equals("verify"))verify(s);if(ticks>1000)throw new AssertionError("Restart fixture timeout");}catch(Throwable error){error.printStackTrace();finish(s,false,error.toString());}});}
 void setup(MinecraftServer s)throws Exception{var f=ShirokaiRaids.class.getDeclaredField("instance");f.setAccessible(true);var mod=f.get(null);var sf=ShirokaiRaids.class.getDeclaredField("state");sf.setAccessible(true);state=(RaidState)sf.get(mod);var jf=ShirokaiRaids.class.getDeclaredField("modularRewards");jf.setAccessible(true);var original=(RaidRewardJournal)jf.get(mod);var save=ShirokaiRaids.class.getDeclaredMethod("save");save.setAccessible(true);player=new ItemRewardsIntegration().add(s,OWNER);
  if(System.getProperty("raid.receipt.phase").equals("prepare")){
   var calls=new AtomicInteger();journal=new RaidRewardJournal(state.modularRewards,()->{try{if(calls.incrementAndGet()==2){Files.writeString(Path.of("receipt-crash-ready"),tx);throw new IllegalStateException("Injected failure between saved item receipt and journal DONE");}save.invoke(mod);}catch(Exception error){throw new IllegalStateException(error);}},s,line->{});for(var e:original.handlers().entrySet())journal.register(e.getKey(),e.getValue());jf.set(mod,journal);RaidRewardDispatch.configure(journal,s);
   var settings=RaidRewardSettings.defaults();var reward=new RaidRewardSettings.Reward("crash","item","minecraft:apple",4,4);reward.baseMultiplier=1;reward.damageMultiplier=0;settings.general.pools.put("normal",List.of(reward));settings.top3.chances.put("normal",List.of(0d,0d,0d));journal.award(UUID.randomUUID().toString(),"rayquaza","normal",1000,List.of(new RaidDamageTracker.Entry(OWNER,"Proof",1000,1,1,Set.of())),settings,new Random(1));tx=state.modularRewards.grants.values().iterator().next().id;save.invoke(mod);journal.attempt(OWNER,1);
  }else{journal=original;tx=Files.readString(Path.of("receipt-crash-ready")).trim();var saved=NbtIo.readCompressed(s.getWorldPath(LevelResource.PLAYER_DATA_DIR).resolve(OWNER+".dat"),NbtAccounter.unlimitedHeap());player.load(saved);check("Fresh JVM loaded existing receipt with four apples",count()==4&&player.getTags().contains("shirokai_modular:"+tx));RaidRewardDispatch.maintain(state,s);}
 }
 int count(){int n=0;for(var stack:player.getInventory().items)if(stack.is(Items.APPLE))n+=stack.getCount();return n;}
 void verify(MinecraftServer s){if(state.modularRewards.grants.get(tx).status!=RaidRewardJournal.Status.DONE)return;check("Fresh JVM automatically resolved interrupted journal from saved receipt",true);check("Process-kill recovery did not issue four more apples",count()==4);check("Original transaction identifier is retained",state.modularRewards.grants.get(tx).id.equals(tx));for(int i=0;i<100;i++){journal.reconcile(OWNER,1);journal.tick(4);}check("Repeated reconciliation and ticks cannot duplicate the recovered reward",count()==4);finish(s,true,"Actual interrupted post-receipt confirmation recovered across two JVMs without reissue");}
 void finish(MinecraftServer s,boolean passed,String message){done=true;try{var json=new com.google.gson.JsonObject();json.addProperty("passed",passed);json.addProperty("checks",checks);json.addProperty("message",message);Files.writeString(Path.of("receipt-restart-results.json"),json.toString());}catch(Exception e){throw new RuntimeException(e);}s.halt(false);}
}
