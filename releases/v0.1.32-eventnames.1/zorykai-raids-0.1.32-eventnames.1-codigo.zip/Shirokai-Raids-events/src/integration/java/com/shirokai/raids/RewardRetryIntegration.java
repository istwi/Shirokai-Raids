package com.shirokai.raids;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.*;
import net.minecraft.world.inventory.*;
import java.nio.file.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.atomic.*;
import java.time.ZoneId;
import com.shirokai.raids.core.RaidDamageTracker;

public final class RewardRetryIntegration implements ModInitializer {
 int ticks,phase,checks;boolean done;Object mod;RaidState state;RaidRewardJournal journal;ServerPlayer owner,other,reconnected;String onlineGrant,otherGrant,offlineGrant;UUID offlineId;final AtomicInteger writes=new AtomicInteger();final List<String> logs=new ArrayList<>();
 void check(String message,boolean ok){checks++;if(!ok)throw new AssertionError(message);}
 Object field(String name)throws Exception{var f=ShirokaiRaids.class.getDeclaredField(name);f.setAccessible(true);return f.get(mod);}
 RaidRewardJournal.Grant reserve(UUID player,String reference){var settings=RaidRewardSettings.defaults();var reward=new RaidRewardSettings.Reward("native","item",reference,4,4);reward.baseMultiplier=1;reward.damageMultiplier=0;settings.general.pools.put("normal",List.of(reward));settings.top3.chances.put("normal",List.of(0d,0d,0d));String raid=UUID.randomUUID().toString();journal.award(raid,"rayquaza","normal",1000,List.of(new RaidDamageTracker.Entry(player,"Probe",1000,1,1,Set.of())),settings,new Random(1));return state.modularRewards.grants.values().stream().filter(g->g.raid.equals(raid)).findFirst().orElseThrow();}
 boolean lore(ItemStack stack,String text){var lore=stack.get(DataComponents.LORE);return lore!=null&&lore.lines().stream().anyMatch(c->c.getString().toLowerCase(java.util.Locale.ROOT).contains(text.toLowerCase(java.util.Locale.ROOT)));}
 int count(ServerPlayer player,net.minecraft.world.item.Item item){int count=0;for(var stack:player.getInventory().items)if(stack.is(item))count+=stack.getCount();return count;}
 public void onInitialize(){ServerTickEvents.END_SERVER_TICK.register(s->{if(done||++ticks<30)return;try{run(s);if(ticks>500)throw new AssertionError("Retry fixture timeout");}catch(Throwable e){e.printStackTrace();finish(s,false,e.toString());}});}
 void run(MinecraftServer s)throws Exception{
  if(phase==0){var f=ShirokaiRaids.class.getDeclaredField("instance");f.setAccessible(true);mod=f.get(null);state=(RaidState)field("state");var original=(RaidRewardJournal)field("modularRewards");
   owner=new ItemRewardsIntegration().add(s,UUID.randomUUID());other=new ItemRewardsIntegration().add(s,UUID.randomUUID());
   var save=ShirokaiRaids.class.getDeclaredMethod("save");save.setAccessible(true);journal=new RaidRewardJournal(state.modularRewards,()->{writes.incrementAndGet();try{save.invoke(mod);}catch(Exception e){throw new IllegalStateException(e);}},s,logs::add);
   for(var entry:original.handlers().entrySet())journal.register(entry.getKey(),entry.getValue());var jf=ShirokaiRaids.class.getDeclaredField("modularRewards");jf.setAccessible(true);jf.set(mod,journal);RaidRewardDispatch.configure(journal,s);
   for(int i=0;i<1000;i++){var g=reserve(UUID.randomUUID(),"minecraft:apple");if(i==0){offlineId=UUID.fromString(g.player);offlineGrant=g.id;}}
   save.invoke(mod);writes.set(0);int baseline=logs.size();for(int i=0;i<1000;i++)journal.tick(4);
   check("1000 offline reservations: zero journal writes over 1000 dispatcher calls",writes.get()==0);check("Offline recipients generate no delivery or retry logs",logs.size()==baseline);check("Offline awards keep amounts IDs and PENDING status",state.modularRewards.grants.size()==1000&&state.modularRewards.grants.values().stream().allMatch(g->g.status==RaidRewardJournal.Status.PENDING&&g.choice.amount.intValueExact()==4));
   var own=reserve(owner.getUUID(),"minecraft:apple");onlineGrant=own.id;for(int i=0;i<21;i++)reserve(owner.getUUID(),"minecraft:apple").status=RaidRewardJournal.Status.UNCERTAIN;otherGrant=reserve(other.getUUID(),"minecraft:diamond").id;
   for(int i=0;i<36;i++)owner.getInventory().items.set(i,new ItemStack(Items.STONE,64));save.invoke(mod);writes.set(0);baseline=logs.size();for(int i=0;i<1000;i++)journal.tick(4);
   check("Full inventory preflight does not write IN_FLIGHT or PENDING repeatedly",writes.get()==0);check("Full inventory does not produce retry console spam",logs.size()==baseline);check("Online recipients also receive nothing until explicit manual request",state.modularRewards.grants.get(otherGrant).status==RaidRewardJournal.Status.PENDING);journal.attempt(other.getUUID(),4);
   PendingRewardMenu.open(owner,state,ZoneId.of("America/Sao_Paulo"),0,()->true,()->s.getCommands().performPrefixedCommand(owner.createCommandSourceStack(),"raid resgatar"));
   var menu=(ChestMenu)owner.containerMenu;check("New modular pending item is visible in main list even without legacy rewards",menu.getContainer().getItem(0).is(Items.APPLE));check("Menu explains insufficient space",lore(menu.getContainer().getItem(0),"Sem espaço"));check("Uncertain reward explicitly requires administration",lore(menu.getContainer().getItem(1),"Conferência administrativa"));check("All pending rewards are paginated",menu.getContainer().getItem(26).is(Items.ARROW));check("No false empty-paper when modular reservations exist",!menu.getContainer().getItem(4).is(Items.PAPER));
   menu.clicked(0,0,ClickType.QUICK_MOVE,owner);check("Pending reward icons cannot be shift-clicked into inventory",count(owner,Items.APPLE)==0);
   menu.clicked(26,0,ClickType.PICKUP,owner);check("Second page displays modular reservations",((ChestMenu)owner.containerMenu).getContainer().getItem(0).is(Items.APPLE));
   owner.getInventory().items.set(35,ItemStack.EMPTY);PendingRewardMenu.open(owner,state,ZoneId.of("America/Sao_Paulo"),0,()->true,()->s.getCommands().performPrefixedCommand(owner.createCommandSourceStack(),"raid resgatar"));menu=(ChestMenu)owner.containerMenu;check("Freeing inventory space is reflected in claim availability",lore(menu.getContainer().getItem(0),"Clique neste prêmio"));menu.clicked(0,0,ClickType.PICKUP,owner);phase=1;
  }else if(phase==1){
   if(state.modularRewards.grants.get(onlineGrant).status!=RaidRewardJournal.Status.DONE||state.modularRewards.grants.get(otherGrant).status!=RaidRewardJournal.Status.DONE){journal.tick(4);return;}
   check("Clicking individual menu reward dispatches exactly the selected modular item",count(owner,Items.APPLE)==4);check("Offline/full reservations do not starve another online recipient",count(other,Items.DIAMOND)==4);
   for(int i=0;i<10;i++)s.getCommands().performPrefixedCommand(owner.createCommandSourceStack(),"raid resgatar");check("Repeated claim commands do not duplicate delivered items",count(owner,Items.APPLE)==4);check("Claim never replays UNCERTAIN grants",state.modularRewards.grants.values().stream().filter(g->g.player.equals(owner.getUUID().toString())&&g.status==RaidRewardJournal.Status.UNCERTAIN).count()==21);
   PendingRewardMenu.open(owner,state,ZoneId.of("America/Sao_Paulo"),0,()->true,()->{});check("Remaining uncertain rewards stay visible after successful deliveries",lore(((ChestMenu)owner.containerMenu).getContainer().getItem(0),"Conferência administrativa"));
   reconnected=new ItemRewardsIntegration().add(s,offlineId);journal.wake(offlineId);for(int i=0;i<100;i++)journal.tick(4);check("Reconnection alone does not deliver pending items",count(reconnected,Items.APPLE)==0&&state.modularRewards.grants.get(offlineGrant).status==RaidRewardJournal.Status.PENDING);state.pending.computeIfAbsent(offlineId.toString(),id->new ArrayList<>()).add(new RaidState.Pending(UUID.randomUUID().toString(),"minecraft:emerald",2));s.getCommands().performPrefixedCommand(reconnected.createCommandSourceStack(),"raid resgatar");phase=2;
  }else if(phase==2){if(state.modularRewards.grants.get(offlineGrant).status!=RaidRewardJournal.Status.DONE){journal.tick(4);return;}
   check("Previously offline recipient receives exact saved award only after manual claim",count(reconnected,Items.APPLE)==4);var g=state.modularRewards.grants.get(offlineGrant);g.status=RaidRewardJournal.Status.IN_FLIGHT;journal.recover();for(int i=0;i<100;i++)journal.tick(4);check("Receipt recovery also waits for explicit manual resgate",g.status==RaidRewardJournal.Status.PENDING);journal.attempt(offlineId,4);phase=3;
  }else if(phase==3){if(state.modularRewards.grants.get(offlineGrant).status!=RaidRewardJournal.Status.DONE)return;check("Existing transaction receipt prevents duplicate item after restart recovery",count(reconnected,Items.APPLE)==4);check("Patched resgatar handles legacy and modular pending awards together",count(reconnected,Items.EMERALD)==2&&state.pending.getOrDefault(offlineId.toString(),List.of()).isEmpty());check("Remaining offline players are never marked paid or removed",state.modularRewards.grants.values().stream().filter(g->!g.player.equals(owner.getUUID().toString())&&!g.player.equals(other.getUUID().toString())&&!g.player.equals(offlineId.toString())).allMatch(g->g.status==RaidRewardJournal.Status.PENDING));finish(s,true,"Offline/full inventory dispatch suppressed; real menu and claim deliver modular rewards with receipt protection");}
 }
 void finish(MinecraftServer server,boolean passed,String message){done=true;var json=new com.google.gson.JsonObject();json.addProperty("passed",passed);json.addProperty("checks",checks);json.addProperty("message",message);try{Files.writeString(Path.of("reward-retry-results.json"),new com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(json));}catch(Exception e){throw new RuntimeException(e);}server.halt(false);}
}
