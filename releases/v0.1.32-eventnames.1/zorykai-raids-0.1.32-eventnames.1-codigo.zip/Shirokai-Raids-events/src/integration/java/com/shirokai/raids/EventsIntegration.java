package com.shirokai.raids;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.storage.LevelResource;
import com.cobblemon.mod.common.entity.pokemon.PokemonEntity;
import com.cobblemon.mod.common.api.pokemon.stats.Stats;
import com.shirokai.raids.core.RaidDamageTracker;
import java.nio.file.*;
import java.util.*;

/** Real Fabric commands, actual Cobblemon entities and persisted state; simulated player, no visual client. */
public final class EventsIntegration implements ModInitializer {
    int ticks,checks;boolean done;MinecraftServer server;ShirokaiRaids mod;RaidState state;ServerPlayer player;
    final List<String> passed=new ArrayList<>();
    void check(boolean yes,String description){checks++;if(!yes)throw new AssertionError(description);passed.add(description);}
    int command(String command)throws Exception{return server.getCommands().getDispatcher().execute(command,server.createCommandSourceStack());}
    Object active(){return RaidEvents.get(mod,"active");}
    RaidConfig.Boss boss(){return (RaidConfig.Boss)RaidEvents.get(active(),"definition");}
    void finish(RaidArchive.Outcome outcome){RaidEvents.call(mod,"finish",new Class<?>[]{RaidArchive.Outcome.class,String.class},outcome,"");if(RaidEvents.get(mod,"victory")!=null)RaidEvents.call(mod,"cancelVictory",new Class<?>[0]);}
    void tick(long now)throws Exception{var m=RaidEvents.class.getDeclaredMethod("tick",ShirokaiRaids.class,long.class);m.setAccessible(true);m.invoke(null,mod,now);}
    void set(Object owner,String field,Object value)throws Exception{var f=owner.getClass().getDeclaredField(field);f.setAccessible(true);f.set(owner,value);}
    public void onInitialize(){ServerTickEvents.END_SERVER_TICK.register(s->{if(done||++ticks!=40)return;server=s;try{run();finishReport(true,"");}catch(Throwable e){e.printStackTrace();finishReport(false,e.toString());}});}
    void run()throws Exception{
        mod=RaidEvents.mod();state=RaidEvents.state(mod);check(Boolean.TRUE.equals(RaidEvents.get(mod,"healthy")),"Latest mod starts healthy with optional event state");
        check(Files.exists(Path.of("config/shirokai-raids/events.json")),"Events settings generated without editing existing configs");
        var config=(RaidConfig)RaidEvents.get(mod,"config");
        check(command("raidadmin proxima normal")==1,"Admin can select next rarity");
        check(command("raidadmin evento shiny 100%")==1,"Shiny percentage command accepted");
        check(command("raidadmin evento ivs 6")==1,"Six perfect IVs accepted");
        check(command("raidadmin evento drop 2")==1&&command("raidadmin evento token 2")==1,"Probability and token bonuses compose");
        check(command("raidadmin evento enfurecido")==1,"Rage can compose with next-raid events");
        long seed=state.events.next.seed;check(command("raidadmin iniciar")==0&&active()==null&&state.events.next.seed==seed,"Missing arena refuses start without consuming queued modifiers");
        config.spawnConfigured=true;config.x=0;config.y=200;config.z=0;config.automaticRaids=false;
        for(int x=-8;x<=8;x++)for(int z=-8;z<=8;z++)server.overworld().setBlock(new BlockPos(x,199,z),Blocks.STONE.defaultBlockState(),3);
        check(command("raidadmin iniciar")==1&&active()!=null,"Start uses actual existing lifecycle and creates a native boss");
        var definition=boss();var entity=(PokemonEntity)RaidEvents.get(active(),"boss");
        check(definition.difficulty.equals("normal")&&entity.getPokemon().getShiny(),"Selected rarity and 100% shiny reach actual spawned Pokemon");
        for(var stat:List.of(Stats.HP,Stats.ATTACK,Stats.DEFENCE,Stats.SPECIAL_ATTACK,Stats.SPECIAL_DEFENCE,Stats.SPEED))check(entity.getPokemon().getIvs().getOrDefault(stat)==31,"Real boss has perfect IV: "+stat);
        double base=((RaidCatalogSettings)RaidEvents.get(mod,"catalogSettings")).profiles.get("normal").damageMultiplier;
        check(definition.damageMultiplier==base*1.5,"Rage scales existing battle damage input without replacing battle engine");
        var snapshot=(RaidRewardSettings)RaidEvents.get(active(),"rewardSettings");
        check(snapshot.event.drop==2&&snapshot.event.tokens==2&&snapshot.event.rage,"All rewards hold the boss event snapshot");
        check(!state.events.next.configured(),"Successful spawn consumes next event once");
        check(command("raidadmin evento token 3")==1&&snapshot.event.tokens==2,"Changing future events cannot change an active raid snapshot");
        player=new ItemRewardsIntegration().add(server,UUID.randomUUID());player.setPos(200,200,200);
        try{server.getCommands().getDispatcher().execute("raidadmin evento token 10",player.createCommandSourceStack().withPermission(0));throw new AssertionError("Admin privilege bypass");}catch(com.mojang.brigadier.exceptions.CommandSyntaxException expected){check(true,"Non-admin cannot alter event or start a raid");}
        var damage=(RaidDamageTracker)RaidEvents.get(active(),"damage");damage.record(player.getUUID(),"EventProbe",UUID.randomUUID(),definition.hp,System.currentTimeMillis());String raid=(String)RaidEvents.get(active(),"id");
        finish(RaidArchive.Outcome.VICTORY);
        var grants=state.modularRewards.grants.values().stream().filter(g->g.raid.equals(raid)).toList();check(!grants.isEmpty()&&grants.stream().allMatch(g->g.status==RaidRewardJournal.Status.PENDING),"Victory only reserves prizes; manual redemption policy preserved");
        check(grants.stream().allMatch(g->g.event!=null&&g.event.tokens==2),"Victory uses original snapshot after future bonus edit");
        var disk=JsonFiles.read(server.getWorldPath(LevelResource.ROOT).resolve("data/shirokai-raids/state.json"),RaidState.class);disk.validate();check(disk.modularRewards.grants.size()==state.modularRewards.grants.size(),"Rewards and event state share original atomic state transaction");
        command("raidadmin evento cancelar");check(command("raidadmin evento invasao")==1,"Legendary invasion queued");
        var previous=RaidEvents.copy(state.events.next);check(command("raidadmin proxima normal")==0&&state.events.next.invasion&&state.events.next.rarity.equals(previous.rarity),"Incompatible invasion rarity rejected without changing plan");
        check(command("raidadmin iniciar")==1&&Set.of("lendario","supremo").contains(boss().difficulty),"Invasion creates only legendary/supreme category");finish(RaidArchive.Outcome.CANCELLED);
        check(command("raidadmin evento elemental fogo")==1&&command("raidadmin iniciar")==1,"Elemental fire selects a loaded eligible Cobblemon species");
        var form=((PokemonEntity)RaidEvents.get(active(),"boss")).getPokemon().getForm();check(form.getPrimaryType().getName().equalsIgnoreCase("fire")||form.getSecondaryType()!=null&&form.getSecondaryType().getName().equalsIgnoreCase("fire"),"Elemental filter checks native primary/secondary types");finish(RaidArchive.Outcome.CANCELLED);
        var eligible=RaidCatalogPokemon.species((RaidCatalogSettings)RaidEvents.get(mod,"catalogSettings")).stream().filter(p->RaidAutomaticCatalog.eligible(p,(RaidCatalogSettings)RaidEvents.get(mod,"catalogSettings"))).toList();
        String a=eligible.get(0).id(),b=eligible.get(1).id();check(command("raidadmin evento votacao "+a+" "+b)==1,"Community voting accepts two real eligible species");
        var playerSource=player.createCommandSourceStack().withPermission(0);check(server.getCommands().getDispatcher().execute("raid votar 1",playerSource)==1,"Ordinary player can cast a vote");check(server.getCommands().getDispatcher().execute("raid votar 2",playerSource)==0,"Rapid vote changes are rate-limited before disk writes");state.events.vote.lastVotes.put(player.getUUID().toString(),0L);server.getCommands().getDispatcher().execute("raid votar 2",playerSource);check(state.events.vote.votes.size()==1&&state.events.vote.votes.get(player.getUUID().toString())==1,"Repeated vote changes choice without adding votes");
        check(command("raidadmin evento shiny 50%")==0&&command("raidadmin iniciar")==0,"Active vote locks advertised options/modifiers and raid start");state.events.vote.ends=System.currentTimeMillis()-1;tick(System.currentTimeMillis());check(state.events.vote==null&&state.events.next.species.equals(b),"Vote winner persists for next raid, not immediate start");check(command("raidadmin iniciar")==1&&boss().species.equals(b),"Chosen community species reaches actual boss");finish(RaidArchive.Outcome.CANCELLED);
        check(command("raidadmin evento dupla")==1&&state.events.next.rarity.isEmpty()&&state.events.next.secondRarity.isEmpty(),"Default Desafio Duplo does not force legendary/supreme rarities");
        check(command("raidadmin iniciar")==1,"Default random duo starts a real catalog boss");String firstRandomSpecies=boss().species;finish(RaidArchive.Outcome.VICTORY);
        check(state.events.second!=null&&state.events.second.rarity.isEmpty()&&state.events.second.excludedSpecies.equals(firstRandomSpecies),"Second random stage preserves independent draw and avoids first species");
        long randomNow=System.currentTimeMillis();tick(randomNow);tick(randomNow+31000);
        check(active()!=null&&!boss().species.equals(firstRandomSpecies),"Second random duo boss differs when catalog has other eligible candidates");finish(RaidArchive.Outcome.CANCELLED);
        check(command("raidadmin evento dupla normal raro")==1&&command("raidadmin iniciar")==1,"Dupla starts first selected rarity");check(state.events.second!=null&&!state.events.chainRaid.isEmpty(),"Second stage reserved in same persisted start");check(state.events.second.seed!=boss().event.seed,"Duo stages have separate persisted random draws");finish(RaidArchive.Outcome.TIMEOUT);check(state.events.second==null,"First-stage timeout cancels second stage");
        command("raidadmin evento dupla normal raro");command("raidadmin iniciar");finish(RaidArchive.Outcome.VICTORY);check(state.events.second!=null&&state.events.chainRaid.isEmpty(),"First victory keeps second stage queued");
        var pending=new RaidState.CaptureGrant();pending.id=UUID.randomUUID().toString();pending.raid=UUID.randomUUID().toString();pending.player=player.getUUID().toString();pending.boss=definition;pending.arena=new RaidState.ReturnPosition("minecraft:overworld",0,200,0,0,0);pending.radius=48;pending.remaining=1;pending.durationSeconds=120;pending.chance=.5;pending.expiresAt=System.currentTimeMillis()+120000;state.captures.put(pending.id,pending);
        long now=System.currentTimeMillis();tick(now);check(active()==null&&state.events.safeSince==0,"Unstarted capture opportunity blocks duo countdown; capture is not cut");state.captures.clear();
        var origin=new RaidState.ReturnPosition("minecraft:overworld",200,200,200,0,0);origin.raid=pending.raid;state.returns.put(player.getUUID().toString(),origin);check(!RaidEvents.safe(mod,now),"Pending online return blocks second raid even if capture ended");state.returns.remove(player.getUUID().toString());
        state.returns.put(UUID.randomUUID().toString(),origin);check(RaidEvents.safe(mod,now),"Offline return does not permanently block sequence; recovery data retained");state.returns.clear();
        tick(now);check(state.events.safeSince!=0&&active()==null,"Safe arena begins interval without immediate second spawn");tick(now+31000);check(active()!=null&&boss().difficulty.equals("raro")&&boss().event.stage==2,"Second boss starts only after safety gate and interval");check(state.events.second==null&&!state.events.next.configured(),"Second stage consumes sequence once");finish(RaidArchive.Outcome.CANCELLED);
        check(command("raidadmin iniciar normal")==1&&boss().event!=null&&boss().event.drop==1&&boss().event.shiny==-1,"Following raid has default chances, no event leakage");finish(RaidArchive.Outcome.CANCELLED);
        // Exercise the actual patched capture entity creation, not just applyIvs directly.
        var capture=JsonFiles.copy(pending,RaidState.CaptureGrant.class);capture.id=UUID.randomUUID().toString();capture.expiresAt=System.currentTimeMillis()+120000;capture.resolved=false;capture.boss=definition;state.captures.put(capture.id,capture);origin.raid=capture.raid;state.returns.put(player.getUUID().toString(),origin);player.setPos(0,200,0);
        var manager=(RaidCapture)RaidEvents.get(mod,"captures");manager.start(player);check(manager.active(player.getUUID()),"Existing capture manager starts with persisted event boss snapshot");
        var targets=server.overworld().getEntitiesOfClass(PokemonEntity.class,new net.minecraft.world.phys.AABB(-100,150,-100,100,260,100),e->RaidCapture.protectedEntity(e));check(targets.size()==1,"Capture still creates one private target");for(var stat:List.of(Stats.HP,Stats.ATTACK,Stats.DEFENCE,Stats.SPECIAL_ATTACK,Stats.SPECIAL_DEFENCE,Stats.SPEED))check(targets.get(0).getPokemon().getIvs().getOrDefault(stat)==31,"Actual private capture target retains event perfect IV: "+stat);manager.close(player,true);state.returns.clear();state.captures.clear();
        check(RaidCommands.allowedDuringRaid("raid votar 2")&&!RaidCommands.allowedDuringRaid("op EventProbe"),"Patched command filter adds only voting/info routes");
        RaidEvents.save(mod);
    }
    void finishReport(boolean result,String error){done=true;var json=new com.google.gson.JsonObject();json.addProperty("passed",result);json.addProperty("checks",checks);json.addProperty("error",error);json.add("assertions",new com.google.gson.Gson().toJsonTree(passed));try{Files.writeString(Path.of("events-results.json"),new com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(json));}catch(Exception e){throw new RuntimeException(e);}server.halt(false);}
}
