import java.nio.file.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** All targets/counts asserted against the pinned 0.1.29 binary. Never replaces lifecycle methods. */
public final class PatchEventHooks implements Opcodes {
 static final String P="com/shirokai/raids/",E=P+"RaidEvents",M=P+"ShirokaiRaids";
 static MethodInsnNode hook(String name,String descriptor){return new MethodInsnNode(INVOKESTATIC,E,name,descriptor,false);}
 static InsnList args(int... locals){var code=new InsnList();for(int n:locals)code.add(new VarInsnNode(ALOAD,n));return code;}
 static void require(boolean value,String reason){if(!value)throw new IllegalStateException(reason);}
 public static void main(String[] argv)throws Exception{
  var node=new ClassNode();new ClassReader(Files.readAllBytes(Path.of(argv[0]))).accept(node,0);String name=node.name.substring(P.length());int changes=0;
  switch(name){
   case "RaidState"->{
    require(node.fields.stream().noneMatch(f->f.name.equals("events")),"events already present");node.fields.add(new FieldNode(0,"events","L"+P+"RaidEventState;",null,null));
    for(var method:node.methods){
     if(method.name.equals("<init>"))for(var insn:method.instructions.toArray())if(insn.getOpcode()==RETURN){var code=args(0);code.add(new TypeInsnNode(NEW,P+"RaidEventState"));code.add(new InsnNode(DUP));code.add(new MethodInsnNode(INVOKESPECIAL,P+"RaidEventState","<init>","()V",false));code.add(new FieldInsnNode(PUTFIELD,node.name,"events","L"+P+"RaidEventState;"));method.instructions.insertBefore(insn,code);changes++;}
     if(method.name.equals("validate")&&method.desc.equals("()V")){var code=args(0);code.add(new FieldInsnNode(GETFIELD,node.name,"events","L"+P+"RaidEventState;"));code.add(new MethodInsnNode(INVOKEVIRTUAL,P+"RaidEventState","validate","()V",false));method.instructions.insert(code);changes++;}
    }require(changes==2,"state hooks "+changes);
   }
   case "RaidConfig$Boss","RaidRewardSettings"->{node.fields.add(new FieldNode(ACC_PUBLIC,"event","L"+P+"RaidEventPlan;",null,null));changes++;}
   case "ShirokaiRaids"->{
    for(var method:node.methods){
     if(method.name.equals("beginAutomatic")&&method.desc.equals("()V")){var label=new LabelNode();var code=args(0);code.add(hook("overrideAutomatic","(L"+M+";)Z"));code.add(new JumpInsnNode(IFEQ,label));code.add(new InsnNode(RETURN));code.add(label);code.add(new FrameNode(F_SAME,0,null,0,null));method.instructions.insert(code);changes++;}
     if(method.name.equals("begin")&&method.desc.equals("(L"+P+"RaidConfig$Boss;L"+P+"RaidAutomaticCatalog$Draw;)V")){
      var code=args(0,1);code.add(hook("decorate","(L"+M+";L"+P+"RaidConfig$Boss;)L"+P+"RaidConfig$Boss;"));code.add(new VarInsnNode(ASTORE,1));method.instructions.insert(code);changes++;
      int count=0;for(var insn:method.instructions.toArray())if(insn instanceof MethodInsnNode call&&call.owner.equals(M)&&call.name.equals("save")){var add=args(0);add.add(hook("consumeActive","(L"+M+";)V"));method.instructions.insertBefore(insn,add);count++;}require(count==1,"begin save hooks "+count);changes++;
     }
     if(method.name.equals("finish")&&method.desc.equals("(L"+P+"RaidArchive$Outcome;Ljava/lang/String;)V")){
      int count=0;for(var insn:method.instructions.toArray())if(insn instanceof MethodInsnNode call&&call.owner.equals(M)&&call.name.equals("save")){var add=args(0,1);add.add(hook("finished","(L"+M+";L"+P+"RaidArchive$Outcome;)V"));method.instructions.insertBefore(insn,add);count++;}require(count==1,"finish save hooks "+count);changes++;
     }
    }require(changes==4,"main hooks "+changes);
   }
   case "RaidCatalogPokemon"->{for(var method:node.methods)if(method.name.equals("train"))for(var insn:method.instructions.toArray())if(insn.getOpcode()==RETURN){var code=args(0,1);code.add(hook("applyIvs","(Lcom/cobblemon/mod/common/pokemon/Pokemon;L"+P+"RaidConfig$Boss;)V"));method.instructions.insertBefore(insn,code);changes++;}require(changes==1,"train hooks "+changes);}
   case "RaidCapture"->{for(var method:node.methods)if(method.name.equals("start"))for(var insn:method.instructions.toArray())if(insn instanceof MethodInsnNode call&&call.owner.equals("com/cobblemon/mod/common/api/pokemon/PokemonProperties")&&call.name.equals("createEntity")){var code=new InsnList();code.add(new InsnNode(DUP));code.add(new VarInsnNode(ALOAD,4));code.add(hook("captureIvs","(Lcom/cobblemon/mod/common/entity/pokemon/PokemonEntity;L"+P+"RaidConfig$Boss;)V"));method.instructions.insert(insn,code);changes++;}require(changes==1,"capture hooks "+changes);}
   case "RaidCommands"->{for(var method:node.methods)if(method.name.equals("allowedDuringRaid")){var label=new LabelNode();var code=args(0);code.add(hook("allowedEventCommand","(Ljava/lang/String;)Z"));code.add(new JumpInsnNode(IFEQ,label));code.add(new InsnNode(ICONST_1));code.add(new InsnNode(IRETURN));code.add(label);code.add(new FrameNode(F_SAME,0,null,0,null));method.instructions.insert(code);changes++;}require(changes==1,"command hooks "+changes);}
   default->throw new IllegalArgumentException("Unexpected target "+name);
  }
  var writer=new ClassWriter(ClassWriter.COMPUTE_MAXS);node.accept(writer);Files.write(Path.of(argv[1]),writer.toByteArray());System.out.println(name+": "+changes+" audited hooks");
 }
}
