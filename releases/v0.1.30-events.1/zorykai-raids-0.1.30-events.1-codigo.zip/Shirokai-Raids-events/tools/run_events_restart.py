from pathlib import Path
import sys,subprocess,time,json
source=Path(__file__).with_name('run_receipts_native.py').read_text()
exec(compile(source.split("with (r/'server.log').open('w') as log:")[0],'raid-runtime-setup','exec'))
p=None
try:
 for phase,marker in [('prepare','events-restart-ready'),('recover','events-restart-recovered'),('verify','events-restart-results.json')]:
  with (r/(phase+'.log')).open('w') as log:
   p=subprocess.Popen(['/workspace/shared/jdk/bin/java',*jvm,'-Draid.events.phase='+phase,'-Xmx3G','-Xverify:all','-jar','fabric-server-launch.jar','nogui'],cwd=r,stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT)
   deadline=time.monotonic()+200
   while not (r/marker).exists():
    if (r/'events-restart-error').exists():raise RuntimeError((r/'events-restart-error').read_text())
    if p.poll() is not None:raise RuntimeError('Process exited; inspect '+phase+'.log')
    if time.monotonic()>deadline:raise TimeoutError(phase)
    time.sleep(.1)
   if phase!='verify':p.kill();p.wait(timeout=20)
   else:assert p.wait(timeout=40)==0
 result=json.loads((r/'events-restart-results.json').read_text());result.update({'passed':True,'jvms':3,'sigkillRestarts':2,'checks':8});(r/'events-restart-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
finally:
 if p is not None and p.poll() is None:p.kill();p.wait(timeout=20)
