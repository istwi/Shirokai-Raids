package com.shirokai.raids;

import com.shirokai.raids.core.RaidDamageTracker;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.LongSupplier;
import java.util.random.RandomGenerator;

/** Durable outbox embedded in the same state.json transaction as raid completion. */
final class RaidRewardJournal {
    enum Status { PENDING, IN_FLIGHT, DONE, UNCERTAIN, SKIPPED }
    static final class Choice {
        RaidRewardSettings.Reward reward;
        BigDecimal amount;
        Choice(RaidRewardSettings.Reward reward,BigDecimal amount){this.reward=JsonFiles.copy(reward,RaidRewardSettings.Reward.class);this.amount=amount;}
    }
    static final class Grant {
        String id,raid,player,scope,difficulty,originalReward;
        int rank;
        double contribution;
        Choice choice;
        List<Choice> alternatives=new ArrayList<>();
        RaidRewardSettings.Policy policy;
        RaidEventPlan event;
        long eventCap=1_000_000_000L;
        Status status=Status.PENDING;
        boolean resolved;
        List<String> audit=new ArrayList<>();
    }
    static final class Data {
        Set<String> raids=new HashSet<>();
        Map<String,Grant> grants=new LinkedHashMap<>();
        Map<String,Set<String>> unlocks=new HashMap<>();
        void validate() {
            RaidRewardSettings.require(raids!=null&&grants!=null&&unlocks!=null,"Journal modular ausente");
            for(var e:grants.entrySet()) {
                var g=e.getValue();RaidRewardSettings.require(g!=null&&e.getKey().equals(g.id)&&g.status!=null&&g.choice!=null&&g.scope!=null&&Set.of("general","special").contains(g.scope)&&g.rank>0&&g.rank<=1_000_000&&RaidRewardSettings.probability(g.contribution)&&g.alternatives!=null&&g.alternatives.size()<=64&&g.audit!=null&&g.policy!=null&&g.policy.policy!=null&&g.policy.maximumAttempts>=1&&g.policy.maximumAttempts<=64&&RaidRewardSettings.DIFFICULTIES.contains(g.difficulty)&&g.originalReward!=null,"Entrega modular inválida");
                UUID.fromString(g.id);UUID.fromString(g.player);UUID.fromString(g.raid);
                if(g.event!=null){g.event.validate();RaidRewardSettings.require(g.eventCap>=1&&g.eventCap<=1_000_000_000L,"Limite de evento inválido");}
                validateChoice(g.choice);for(var c:g.alternatives)validateChoice(c);
            }
            for(var e:unlocks.entrySet()){UUID.fromString(e.getKey());RaidRewardSettings.require(e.getValue()!=null,"Desbloqueios ausentes");}
        }
        private static void validateChoice(Choice c){RaidRewardSettings.require(c!=null&&c.reward!=null&&c.amount!=null&&c.amount.signum()>0&&c.amount.compareTo(BigDecimal.valueOf(1_000_000_000L))<=0,"Valor de entrega inválido");c.reward.validate();}
    }
    private final Data data;
    private final Runnable persist;
    private final Executor executor;
    private final Consumer<String> audit;
    private final Map<String,RaidRewardHandler> handlers=new HashMap<>();
    private final Set<String> busy=new HashSet<>();
    private final LongSupplier clock;
    private Predicate<UUID> online = id -> true;
    private final Map<String,Retry> retryPlayers=new HashMap<>();
    private final Set<String> warned=new HashSet<>();
    private record Retry(int failures,long until) {}
    private static final long[] RETRY_DELAYS={10_000,30_000,60_000};
    void online(Predicate<UUID> predicate){online=Objects.requireNonNull(predicate);}
    void wake(UUID player){retryPlayers.remove(player.toString());}
    private boolean waiting(Grant g){var retry=retryPlayers.get(g.player);return retry!=null&&clock.getAsLong()<retry.until;}
    private void defer(Grant g){if(manual)cancel(UUID.fromString(g.player));var old=retryPlayers.get(g.player);int failures=old==null?1:Math.min(RETRY_DELAYS.length,old.failures+1);retryPlayers.put(g.player,new Retry(failures,clock.getAsLong()+RETRY_DELAYS[failures-1]));}
    private void warnOnce(Grant g,String reason){if(warned.add(g.id))audit.accept("Consulta de recompensa adiada: "+g.id+" "+reason+"; nova tentativa com intervalo");}
    private boolean prepared(Grant g,RaidRewardHandler handler){
        if(!online.test(UUID.fromString(g.player))){if(manual)cancel(UUID.fromString(g.player));return false;}
        try {if(!handler.ready(UUID.fromString(g.player),g.id,g.choice.reward.reference,g.choice.amount)){defer(g);return false;}return true;}
        catch(RuntimeException|LinkageError error){defer(g);warnOnce(g,error.toString());return false;}
    }
    private boolean manual;
    private final Set<String> requested=new HashSet<>();
    void manual(boolean enabled){manual=enabled;if(enabled)requested.clear();}
    void cancel(UUID player){String owner=player.toString();requested.removeIf(id->{var grant=data.grants.get(id);return grant==null||grant.player.equals(owner);});}
    boolean requestOne(UUID player,String transaction){var grant=data.grants.get(transaction);if(grant==null||!grant.player.equals(player.toString())||grant.status!=Status.PENDING||busy.contains(transaction))return false;requested.add(transaction);wake(player);tick(1,player.toString());return true;}
    private int receiptCursor;
    private final Map<String,Long> receiptChecks=new HashMap<>();
    boolean hasReceipt(Grant grant){var handler=handlers.get(grant.choice.reward.type);try{return handler!=null&&handler.hasReceipt(UUID.fromString(grant.player),grant.id);}catch(RuntimeException|LinkageError ignored){return false;}}
    void reconcile(UUID player,int budget){reconcile(Set.of(player),budget);}
    void reconcile(Set<UUID> players,int budget){
        if(failed||budget<1||players.isEmpty())return;
        var owners=new HashSet<String>();for(var player:players)owners.add(player.toString());
        int started=0;long now=clock.getAsLong();
        var snapshot=List.copyOf(data.grants.values());if(snapshot.isEmpty())return;
        int start=Math.floorMod(receiptCursor,snapshot.size());
        for(int offset=0;offset<snapshot.size()&&started<budget;offset++){
            int index=(start+offset)%snapshot.size();receiptCursor=(index+1)%snapshot.size();var grant=snapshot.get(index);
            if(!owners.contains(grant.player)||!online.test(UUID.fromString(grant.player))||busy.contains(grant.id))continue;
            if(grant.status!=Status.UNCERTAIN&&(grant.status!=Status.PENDING||!hasReceipt(grant)))continue;
            Long next=receiptChecks.get(grant.id);if(next!=null&&now<next)continue;
            var handler=handlers.get(grant.choice.reward.type);if(handler==null)continue;
            receiptChecks.put(grant.id,now+60_000);busy.add(grant.id);started++;
            CompletionStage<Boolean> proof;
            try{proof=handler.confirmReceipt(UUID.fromString(grant.player),grant.id);}catch(RuntimeException|LinkageError error){proof=CompletableFuture.failedFuture(error);}
            if(proof==null)proof=CompletableFuture.completedFuture(false);
            proof.whenCompleteAsync((confirmed,error)->{
                try {
                    if(error!=null){warnOnce(grant,"Recibo ainda não confirmado: "+error);return;}
                    if(!Boolean.TRUE.equals(confirmed)||failed||grant.status!=Status.UNCERTAIN&&grant.status!=Status.PENDING)return;
                    commit(grant,Status.DONE,"Recibo persistido confirmado; finalização sem reenviar recompensa");
                    requested.remove(grant.id);receiptChecks.remove(grant.id);warned.remove(grant.id);
                    try{reconciled.accept(grant);}catch(RuntimeException notification){audit.accept("Confirmação salva; aviso visual não enviado: "+grant.id);}
                }catch(RuntimeException failure){failed=true;audit.accept("Confirmação de recibo suspensa; reserva preservada: "+failure);}
                finally{busy.remove(grant.id);}
            },executor);
        }
    }
    private void commit(Grant grant,Status status,String event){
        var previous=grant.status;var unlocks=data.unlocks.get(grant.player);var previousUnlocks=unlocks==null?null:new HashSet<>(unlocks);int auditSize=grant.audit.size();
        grant.status=status;if(status==Status.DONE&&grant.choice.reward.cosmetic())data.unlocks.computeIfAbsent(grant.player,k->new HashSet<>()).add(grant.choice.reward.type+":"+grant.choice.reward.reference);
        if(event!=null&&grant.audit.size()<100)grant.audit.add(event);
        try{save();}catch(RuntimeException failure){
            grant.status=previous==Status.IN_FLIGHT?Status.UNCERTAIN:previous;
            if(previousUnlocks==null)data.unlocks.remove(grant.player);else data.unlocks.put(grant.player,previousUnlocks);
            while(grant.audit.size()>auditSize)grant.audit.remove(grant.audit.size()-1);
            throw failure;
        }
        if(event!=null)audit.accept("[rewards] transaction="+grant.id+" raid="+grant.raid+" player="+grant.player+" scope="+grant.scope+" "+event);
    }
    private boolean failed;
    private int cursor;
    private Consumer<Grant> delivered = grant -> {};
    private Consumer<Grant> reconciled = grant -> {};
    private Consumer<Grant> confirmed = grant -> {};
    void onConfirmed(Consumer<Grant> listener){confirmed=listener;}
    void onReconciled(Consumer<Grant> listener){reconciled=listener;}
    void onDelivered(Consumer<Grant> listener){delivered=listener;}
    RaidRewardJournal(Data data,Runnable persist,Executor executor,Consumer<String> audit){this(data,persist,executor,audit,()->TimeUnit.NANOSECONDS.toMillis(System.nanoTime()));}
    RaidRewardJournal(Data data,Runnable persist,Executor executor,Consumer<String> audit,LongSupplier clock){this.data=data;this.persist=persist;this.executor=executor;this.audit=audit;this.clock=clock;}
    void register(String type,RaidRewardHandler handler){if(type==null||handler==null||handlers.putIfAbsent(type,handler)!=null)throw new IllegalArgumentException("Handler duplicado: "+type);}
    Map<String,RaidRewardHandler> handlers(){return Map.copyOf(handlers);}
    void recover() {
        boolean changed=false;
        for(var g:data.grants.values()) if(g.status==Status.IN_FLIGHT) {
            changed=true;var handler=handlers.get(g.choice.reward.type);
            g.status=handler!=null&&handler.retrySafe()?Status.PENDING:Status.UNCERTAIN;
            log(g,"Recuperação: "+g.status+"; efeito externo sem recibo não é repetido");
        }
        if(changed)save();
    }
    static boolean hasCapacity(long pending,int participants,RaidRewardSettings.Integrations limits) {
        return !limits.enabled || pending+(long)participants*limits.maximumRewardsPerPlayer<=limits.maximumPending;
    }
    static boolean eligible(RaidRewardSettings.Reward reward,double contribution,int rank){return contribution>=reward.minimumContribution&&(reward.maximumRank==0||rank<=reward.maximumRank);}
    void award(String raid,String boss,String difficulty,long maxHp,List<RaidDamageTracker.Entry> ranking,RaidRewardSettings settings,RandomGenerator random) {
        if(!settings.integrations.enabled||data.raids.contains(raid))return;
        var override=settings.bosses.values.get(boss);
        String category=override!=null&&override.difficulty!=null?override.difficulty:difficulty;
        var d=settings.difficulties.values.get(category);
        if(d==null)throw new IllegalArgumentException("Dificuldade desconhecida: "+category);
        var general=settings.general.pools.get(override!=null&&override.general!=null?override.general:d.general);
        var special=settings.special.pools.get(override!=null&&override.special!=null?override.special:d.special);
        double multiplier=d.quantityMultiplier*(override==null?1:override.quantityMultiplier);
        var generated=new ArrayList<Grant>();
        int rank=0;
        // Defensive sorting: callers cannot change deterministic tie-breaking or promote an ineligible TOP 4.
        var ordered=ranking.stream().sorted(Comparator.comparingLong(RaidDamageTracker.Entry::damage).reversed().thenComparing(e->e.player().toString())).toList();
        for(var entry:ordered) {
            rank++;double contribution=maxHp>0?Math.min(1,(double)entry.damage()/maxHp):0;
            if(contribution<=0||contribution<settings.integrations.minimumContribution)continue;
            int perPlayer=0;
            for(var reward:general) if(eligible(reward,contribution,rank)&&random.nextDouble()<RaidEventRewards.chance(reward,reward.chance,settings.event)) {
                if(++perPlayer>settings.integrations.maximumRewardsPerPlayer)throw new IllegalArgumentException("Prêmios por jogador excedem limite");
                generated.add(grant(raid,entry.player(),"general",category,rank,contribution,reward,general,multiplier,settings,random));
            }
            if(rank<=3) {
                boolean eventRoll=settings.event!=null&&settings.event.drop!=1;
                double topChance=settings.top3.chances.get(category).get(rank-1);
                if(eventRoll||random.nextDouble()<topChance){
                    final int place=rank;final double share=contribution;
                    var candidates=special.stream().filter(r->eligible(r,share,place)).toList();
                    if(!candidates.isEmpty()) {
                        var reward=select(candidates,random);
                        double chance=eventRoll?RaidEventRewards.chance(reward,topChance*reward.chance,settings.event):reward.chance;
                        if(random.nextDouble()<chance) {
                            if(++perPlayer>settings.integrations.maximumRewardsPerPlayer)throw new IllegalArgumentException("Prêmios por jogador excedem limite");
                            generated.add(grant(raid,entry.player(),"special",category,rank,contribution,reward,special,multiplier,settings,random));
                        }
                    }
                }
            }
        }
        long outstanding=data.grants.values().stream().filter(g->g.status!=Status.DONE&&g.status!=Status.SKIPPED).count();
        if(outstanding+generated.size()>settings.integrations.maximumPending)throw new IllegalStateException("Limite de recompensas pendentes atingido");
        for(var g:generated){data.grants.put(g.id,g);log(g,"Sorteio: "+g.choice.reward.id+" x"+g.choice.amount+" posição="+g.rank+" contribuição="+g.contribution);}
        data.raids.add(raid); // caller persists this with completed raid and legacy loot, before delivery
    }
    private static Grant grant(String raid,UUID player,String scope,String difficulty,int rank,double contribution,RaidRewardSettings.Reward r,List<RaidRewardSettings.Reward> pool,double multiplier,RaidRewardSettings settings,RandomGenerator random){
        var g=new Grant();g.event=settings.event==null?null:JsonFiles.copy(settings.event,RaidEventPlan.class);g.eventCap=settings.integrations.maximumAmount;g.raid=raid;g.player=player.toString();g.scope=scope;g.difficulty=difficulty;g.rank=rank;g.contribution=contribution;g.originalReward=r.id;
        g.id=UUID.nameUUIDFromBytes((raid+":"+player+":"+scope+":"+r.id).getBytes(StandardCharsets.UTF_8)).toString();
        g.choice=new Choice(r,RaidEventRewards.amount(r,RaidRewardSettings.scopedAmount(scope,r,contribution,multiplier,settings.integrations.maximumAmount,random),g.event,g.eventCap));
        var policy=r.type.equals("title")?settings.duplicates.titles:settings.duplicates.particles;
        g.policy=JsonFiles.copy(policy,RaidRewardSettings.Policy.class);
        if(g.policy.compensation!=null){
            long cap=g.policy.compensation.type.equals("fragment")?Math.min(64,settings.integrations.maximumAmount):settings.integrations.maximumAmount;
            g.policy.compensation.maximum=Math.min(cap,g.policy.compensation.maximum);
            g.policy.compensation.minimum=Math.min(cap,g.policy.compensation.minimum);
        }
        for(var alternative:pool)if(alternative.rarity<=r.rarity&&eligible(alternative,contribution,rank))g.alternatives.add(new Choice(alternative,RaidEventRewards.amount(alternative,RaidRewardSettings.scopedAmount(scope,alternative,contribution,multiplier,settings.integrations.maximumAmount,random),g.event,g.eventCap)));
        g.resolved=!r.cosmetic();return g;
    }
    private static RaidRewardSettings.Reward select(List<RaidRewardSettings.Reward> pool,RandomGenerator random){int n=random.nextInt(pool.stream().mapToInt(r->r.weight).sum());for(var r:pool){n-=r.weight;if(n<0)return r;}throw new AssertionError();}
    boolean matches(Data source){return data==source;}
    boolean processing(Grant grant){return busy.contains(grant.id)||grant.status==Status.IN_FLIGHT;}
    void attempt(UUID player,int budget){if(manual)for(var grant:data.grants.values())if(grant.player.equals(player.toString())&&grant.status==Status.PENDING)requested.add(grant.id);wake(player);tick(budget,player.toString());}
    void tick(int budget) {tick(budget,null);}
    private void tick(int budget,String owner) {
        if(failed||manual&&requested.isEmpty())return;
        if(manual)budget=Math.min(budget,1); // One authorized reward per dispatch, never a bulk startup burst.
        int started=0;
        var snapshot=List.copyOf(data.grants.values());
        if(snapshot.isEmpty())return;
        int start=Math.floorMod(cursor,snapshot.size());
        for(int offset=0;offset<snapshot.size() && started<budget;offset++) {
            int index=(start+offset)%snapshot.size();
            var g=snapshot.get(index);
            cursor=(index+1)%snapshot.size();
            if(owner!=null&&!g.player.equals(owner))continue;
            if(manual&&!requested.contains(g.id))continue;
            if(g.status!=Status.PENDING||busy.contains(g.id)||waiting(g))continue;
            if(!online.test(UUID.fromString(g.player))){if(manual)cancel(UUID.fromString(g.player));continue;}
            var handler=handlers.get(g.choice.reward.type);
            if(handler==null||!handler.available(g.choice.reward.reference)){if(manual)requested.remove(g.id);continue;}
            if(busy.stream().anyMatch(id->data.grants.get(id).player.equals(g.player)))continue;
            if(!prepared(g,handler))continue;
            busy.add(g.id);started++;
            resolve(g,new Random(g.id.hashCode())).whenCompleteAsync((choice,error)->{
                if(error!=null){busy.remove(g.id);defer(g);warnOnce(g,error.toString());return;}
                try {
                    if(choice==null){requested.remove(g.id);g.status=Status.SKIPPED;log(g,"Duplicata sem alternativa: ignorada");save();busy.remove(g.id);return;}
                    if(!g.resolved){g.choice=choice;g.resolved=true;log(g,"Resolução de duplicata: "+choice.reward.id);save();}
                    deliver(g);
                }catch(Throwable failure){failed=true;busy.remove(g.id);audit.accept("Journal suspenso: "+failure);}
            },executor);
        }
    }
    private CompletionStage<Choice> resolve(Grant g,Random random) {
        if(g.resolved||!g.choice.reward.cosmetic())return CompletableFuture.completedFuture(g.choice);
        return owned(g,g.choice).thenComposeAsync(owned->{
            if(!owned)return CompletableFuture.completedFuture(g.choice);
            log(g,"Cosmético já possuído: "+g.choice.reward.reference);
            if(g.policy.policy==RaidRewardSettings.Duplicate.SKIP)return CompletableFuture.completedFuture(null);
            if(g.policy.policy==RaidRewardSettings.Duplicate.COMPENSATE)return CompletableFuture.completedFuture(compensation(g,random));
            return reroll(g,random,0,new HashSet<>());
        },executor);
    }
    private CompletionStage<Boolean> owned(Grant g,Choice c) {
        var handler=handlers.get(c.reward.type);
        if(handler==null||!handler.available(c.reward.reference))return CompletableFuture.failedFuture(new IllegalStateException("Provedor cosmético indisponível"));
        return handler.owns(UUID.fromString(g.player),c.reward.reference).thenApplyAsync(value->value||data.unlocks.getOrDefault(g.player,Set.of()).contains(c.reward.type+":"+c.reward.reference),executor);
    }
    private CompletionStage<Choice> reroll(Grant g,Random random,int attempt,Set<String> excluded) {
        var available=g.alternatives.stream().filter(c->!excluded.contains(c.reward.id)&&!c.reward.id.equals(g.originalReward)).filter(c->{var h=handlers.get(c.reward.type);return h!=null&&h.available(c.reward.reference);}).toList();
        if(attempt>=g.policy.maximumAttempts||available.isEmpty())return CompletableFuture.completedFuture(compensation(g,random));
        var selected=select(available.stream().map(c->c.reward).toList(),random);
        var choice=available.stream().filter(c->c.reward.id.equals(selected.id)).findFirst().orElseThrow();excluded.add(selected.id);
        if(random.nextDouble()>=choice.reward.chance)return reroll(g,random,attempt+1,excluded);
        if(!choice.reward.cosmetic())return CompletableFuture.completedFuture(choice);
        return owned(g,choice).thenComposeAsync(owned->owned?reroll(g,random,attempt+1,excluded):CompletableFuture.completedFuture(choice),executor);
    }
    private Choice compensation(Grant g,Random random){
        var r=g.policy.compensation;
        // Fixed compensation is independent of contribution and cannot promote scope/rarity.
        return r==null?null:new Choice(r,RaidEventRewards.amount(r,BigDecimal.valueOf(random.nextLong(r.minimum,r.maximum+1)),g.event,g.eventCap));
    }
    private void deliver(Grant g) {
        if(manual&&!requested.contains(g.id)){busy.remove(g.id);return;}
        var h=handlers.get(g.choice.reward.type);
        if(h==null||!h.available(g.choice.reward.reference)){busy.remove(g.id);return;}
        if(!prepared(g,h)){busy.remove(g.id);return;}
        g.status=Status.IN_FLIGHT;save(); // Durable barrier before any external effect.
        CompletionStage<RaidRewardHandler.Result> future;
        try{future=h.deliver(UUID.fromString(g.player),g.id,g.choice.reward.reference,g.choice.amount);}catch(Throwable error){future=CompletableFuture.failedFuture(error);}
        future.whenCompleteAsync((result,error)->{
            try{
                var status=error!=null||result==null||result==RaidRewardHandler.Result.UNCERTAIN?Status.UNCERTAIN:result==RaidRewardHandler.Result.APPLIED?Status.DONE:Status.PENDING;
                commit(g,status,status==Status.PENDING?null:"Entrega: "+status+(error==null?"":" "+error));
                if(status==Status.PENDING)defer(g);
                else {requested.remove(g.id);retryPlayers.remove(g.player);warned.remove(g.id);}
                if(g.status==Status.DONE)try{delivered.accept(g);confirmed.accept(g);}catch(RuntimeException notification){audit.accept("Aviso de entrega não enviado: "+g.id);}
            }catch(Throwable failure){failed=true;audit.accept("Journal suspenso: "+failure);}finally{busy.remove(g.id);}
        },executor);
    }
    void review(String id,boolean paid,String reason){
        var g=data.grants.get(id);
        if(g==null||g.status!=Status.UNCERTAIN||reason==null||reason.isBlank()||reason.length()>500)throw new IllegalArgumentException("Entrega não incerta ou motivo inválido");
        var status=paid?Status.DONE:Status.PENDING;
        commit(g,status,"Conferência administrativa: "+status+" motivo="+reason);
    }
    private void log(Grant g,String event){String line="[rewards] transaction="+g.id+" raid="+g.raid+" player="+g.player+" scope="+g.scope+" "+event;if(g.audit.size()<100)g.audit.add(event);audit.accept(line);}
    private void save(){try{persist.run();}catch(RuntimeException error){failed=true;throw error;}}
}
