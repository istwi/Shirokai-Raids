package com.shirokai.raids;

import java.util.*;

final class RaidState {
    Map<String, ReturnPosition> returns = new HashMap<>();
    static final class ReturnPosition {
        String raid;
        String dimension;
        double x, y, z;
        float yaw, pitch;
        ReturnPosition(String dimension, double x, double y, double z, float yaw, float pitch) {
            this.dimension=dimension; this.x=x; this.y=y; this.z=z; this.yaw=yaw; this.pitch=pitch;
        }
    }
    Map<String, CaptureGrant> captures = new LinkedHashMap<>();
    static final class CaptureGrant {
        String id, raid, player;
        RaidConfig.Boss boss;
        ReturnPosition arena;
        int remaining, durationSeconds;
        double chance, radius;
        boolean resolved;
        long expiresAt;
        void validate() {
            UUID.fromString(id); UUID.fromString(raid); UUID.fromString(player);
            if (boss == null || arena == null || arena.dimension == null || !arena.dimension.matches("[a-z0-9_.-]+:[a-z0-9_./-]+")
                || !Double.isFinite(arena.x + arena.y + arena.z) || !Float.isFinite(arena.yaw + arena.pitch)
                || remaining < 0 || remaining > 64 || durationSeconds < 10 || durationSeconds > 600
                || !Double.isFinite(chance) || chance <= 0 || chance > 1 || !Double.isFinite(radius) || radius < 8 || radius > 128)
                throw new IllegalArgumentException("Direito de captura inválido");
            boss.validate();
        }
    }
    Map<String, ArenaExit> arenaExits = new HashMap<>();
    static final class ArenaExit {
        long deadline;
        String dimension;
        double x,y,z,radius;
        boolean due(long now, String currentDimension, double px, double py, double pz) {
            double dx=px-x,dy=py-y,dz=pz-z;
            return now>=deadline && dimension.equals(currentDimension) && dx*dx+dy*dy+dz*dz<=radius*radius;
        }
    }
    RaidRewardJournal.Data modularRewards = new RaidRewardJournal.Data();
    long automaticRaidStarts;
    List<String> catalogRecentNormal=new ArrayList<>(),catalogRecentSpecial=new ArrayList<>();
    long nextRaid;
    String activeRaid, bossEntity;
    long hp;
    Map<String, Long> damage = new HashMap<>();
    Map<String, List<Pending>> pending = new HashMap<>();
    Set<String> completed = new HashSet<>();
    // Reserved deliveries after a crash require operator reconciliation, never automatic replay.
    Map<String, Pending> uncertain = new HashMap<>();
    // New reservations can be reconciled using receipts stored with the player's inventory.
    Map<String, Delivery> deliveries = new HashMap<>();
    RaidArchive archive = new RaidArchive();
    Map<String, LegacyReservationReview.Review> reviews = new HashMap<>();
    static final class Delivery {
        String player;
        Pending reward;
        Delivery(String player, Pending reward) { this.player = player; this.reward = reward; }
    }
    static final class Pending {
        String id, raid, item;
        int count;
        Pending(String raid, String item, int count) {
            this.id = UUID.randomUUID().toString(); this.raid = raid; this.item = item; this.count = count;
        }
    }
    void validate() {
        if(automaticRaidStarts<0 || catalogRecentNormal==null || catalogRecentSpecial==null || catalogRecentNormal.size()>100 || catalogRecentSpecial.size()>100 || java.util.stream.Stream.concat(catalogRecentNormal.stream(),catalogRecentSpecial.stream()).anyMatch(s->s==null||!s.matches("[a-z0-9_.-]+:[a-z0-9_./-]+"))) throw new IllegalArgumentException("Histórico automático inválido");
        if(modularRewards==null)throw new IllegalArgumentException("Recompensas modulares ausentes");
        modularRewards.validate();
        if (arenaExits==null) throw new IllegalArgumentException("Retornos automáticos ausentes");
        for (var entry:arenaExits.entrySet()) {
            UUID.fromString(entry.getKey()); var exit=entry.getValue();
            if (exit==null || exit.deadline<0 || exit.dimension==null || !exit.dimension.matches("[a-z0-9_.-]+:[a-z0-9_./-]+")
                || !Double.isFinite(exit.x+exit.y+exit.z+exit.radius) || exit.radius<8 || exit.radius>128)
                throw new IllegalArgumentException("Retorno automático inválido");
        }
        if (captures == null) throw new IllegalArgumentException("Direitos de captura ausentes");
        var captureKeys = new HashSet<String>();
        for (var entry : captures.entrySet()) {
            var grant = entry.getValue();
            if (grant == null || !entry.getKey().equals(grant.id)) throw new IllegalArgumentException("ID de captura inválido");
            grant.validate();
            if (!captureKeys.add(grant.raid + ":" + grant.player)) throw new IllegalArgumentException("Captura duplicada");
        }
        if (returns == null) throw new IllegalArgumentException("Posições de retorno ausentes");
        for (var entry : returns.entrySet()) {
            UUID.fromString(entry.getKey());
            var pos = entry.getValue();
            if (pos == null || pos.dimension == null || !pos.dimension.matches("[a-z0-9_.-]+:[a-z0-9_./-]+")
                || !Double.isFinite(pos.x + pos.y + pos.z) || !Float.isFinite(pos.yaw) || !Float.isFinite(pos.pitch))
                throw new IllegalArgumentException("Posição de retorno inválida");
        }
        if (archive == null) throw new IllegalArgumentException("Histórico persistente inválido");
        archive.validate();
        if (reviews == null) throw new IllegalArgumentException("Conferências persistentes inválidas");
        for (var review : reviews.entrySet())
            if (review.getValue() == null || !review.getKey().equals(review.getValue().reservation()))
                throw new IllegalArgumentException("ID de conferência inválido");
        if (nextRaid < 0 || pending == null || completed == null || uncertain == null || damage == null || deliveries == null)
            throw new IllegalArgumentException("Estado persistente inválido; restaure um backup");
        var ids = new HashSet<String>();
        for (var list : pending.values()) {
            if (list == null) throw new IllegalArgumentException("Lista de recompensas inválida");
            for (var entry : list) {
                validate(entry);
                if (!ids.add(entry.id)) throw new IllegalArgumentException("Recompensa duplicada no estado");
            }
        }
        for (var entry : uncertain.values()) validate(entry);
        for (var entry : deliveries.entrySet()) {
            var delivery = entry.getValue();
            if (delivery == null || delivery.player == null) throw new IllegalArgumentException("Reserva inválida");
            UUID.fromString(delivery.player);
            validate(delivery.reward);
            UUID.fromString(entry.getKey());
            if (!entry.getKey().equals(delivery.reward.id) || !ids.add(entry.getKey()))
                throw new IllegalArgumentException("Reserva duplicada ou inválida");
        }
    }
    private static void validate(Pending entry) {
        if (entry == null || entry.id == null || entry.id.isBlank() || entry.raid == null || entry.item == null
            || entry.count < 1 || entry.count > 64)
            throw new IllegalArgumentException("Recompensa persistente inválida");
    }
}
