package com.shirokai.raids;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import com.shirokai.raids.core.RaidDamageTracker;
import java.nio.file.*;
import java.util.*;

/** Three separate JVMs, SIGKILL after each persisted preparation. */
public final class EventsRestartIntegration implements ModInitializer {
 int ticks,checks;boolean done;
 void require(boolean b,String reason){checks++;if(!b)throw new AssertionError(reason);}
 public void onInitialize(){ServerTickEvents.END_SERVER_TICK.register(server->{if(done||++ticks!=30)return;done=true;try{
  var mod=RaidEvents.mod();var state=RaidEvents.state(mod);String phase=System.getProperty("raid.events.phase");
  if(phase.equals("prepare")){
   state.events.chainRaid=UUID.randomUUID().toString();state.events.second=new RaidEventPlan();state.events.second.duo=true;state.events.second.stage=2;state.events.second.chainId=UUID.randomUUID().toString();state.events.second.rarity="supremo";
   var cfg=RaidRewardSettings.defaults();var reward=new RaidRewardSettings.Reward("restart_item","item","minecraft:apple",3,3);reward.chance=1;cfg.general.pools.put("normal",List.of(reward));cfg.top3.chances.put("normal",List.of(0d,0d,0d));var journal=(RaidRewardJournal)RaidEvents.get(mod,"modularRewards");journal.award(UUID.randomUUID().toString(),"probe","normal",100,List.of(new RaidDamageTracker.Entry(new UUID(0,91),"Offline",100,1,1,Set.of())),cfg,new Random(1));
   state.returns.put(new UUID(0,91).toString(),new RaidState.ReturnPosition("minecraft:overworld",0,200,0,0,0));
   state.modularRewards.heldHistory.put(new UUID(0,91).toString(),List.of(Set.of("cobblemon:choice_band")));state.modularRewards.heldHistoryRaid.put(new UUID(0,91).toString(),UUID.randomUUID().toString());
   state.events.automatic.lastProcessedRaid=UUID.randomUUID().toString();state.events.automatic.lastResult="Sem evento neste sorteio";
   RaidEvents.save(mod);Files.writeString(Path.of("events-restart-ready"),"prepared");return;
  }
  if(phase.equals("recover")){
   require(state.events.second==null&&state.events.chainRaid.isEmpty(),"Interrupted chain not resumed after real JVM restart");require(RaidEvents.get(mod,"active")==null,"Restart creates no phantom boss");require(state.captures.isEmpty(),"Restart creates no capture opportunities");require(state.returns.containsKey(new UUID(0,91).toString()),"Offline return preserved across restart");require(state.modularRewards.grants.size()==1&&state.modularRewards.grants.values().iterator().next().status==RaidRewardJournal.Status.PENDING,"Already-earned manual prize preserved without delivery or duplication");
   require(HeldItemPolicy.blocked(state.modularRewards.heldHistory.get(new UUID(0,91).toString()),1).contains("cobblemon:choice_band"),"Held cooldown survives real SIGKILL and startup");require(state.modularRewards.heldHistoryRaid.containsKey(new UUID(0,91).toString()),"Held history raid ID survives alongside reward state");
   require(!state.events.automatic.lastProcessedRaid.isEmpty(),"Automatic processed marker survives real restart");require(state.events.automatic.lastResult.equals("Sem evento neste sorteio"),"Restart does not replace a failed draw with a new result");
   state.events.next.shiny=.1;state.events.next.perfectIvs=3;state.events.next.drop=2;RaidEvents.save(mod);Files.writeString(Path.of("events-restart-recovered"),"recovered");return;
  }
  require(state.events.next.shiny==.1&&state.events.next.perfectIvs==3&&state.events.next.drop==2,"Armed but unstarted modifiers survive another SIGKILL/restart");require(state.modularRewards.grants.size()==1,"Repeated startup does not duplicate earned prizes");require(state.events.second==null&&RaidEvents.get(mod,"active")==null,"No interrupted chain/capture/boss recreated on second restart");
  require(state.events.automatic.pendingRaid.isEmpty()&&state.events.automatic.lastResult.equals("Sem evento neste sorteio"),"Repeated restart does not create another opportunity or escalate chance");
  var result=new com.google.gson.JsonObject();result.addProperty("passed",true);result.addProperty("verificationChecks",checks);Files.writeString(Path.of("events-restart-results.json"),result.toString());server.halt(false);
 }catch(Throwable error){error.printStackTrace();try{Files.writeString(Path.of("events-restart-error"),error.toString());}catch(Exception ignored){}server.halt(false);}});}
}
