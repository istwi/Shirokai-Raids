package com.shirokai.raids;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.network.chat.Component;
import java.nio.file.*;
import java.util.*;
import com.shirokai.raids.core.RaidDamageTracker;

/** Native command completion, rich chat, both original bar setters, and shared held-item policy. */
public final class EventDisplayIntegration implements ModInitializer {
 int ticks,checks;boolean done;MinecraftServer server;ShirokaiRaids mod;ServerPlayer player;final List<String> assertions=new ArrayList<>();final List<String> broadcasts=new ArrayList<>();
 void check(boolean value,String name){checks++;if(!value)throw new AssertionError(name);assertions.add(name);}
 int command(String input)throws Exception{return server.getCommands().getDispatcher().execute(input,server.createCommandSourceStack());}
 List<String> suggestions(String input){var dispatcher=server.getCommands().getDispatcher();return dispatcher.getCompletionSuggestions(dispatcher.parse(input,server.createCommandSourceStack())).join().getList().stream().map(s->s.getText()).toList();}
 void tick()throws Exception{
  mod=RaidEvents.mod();var state=RaidEvents.state(mod);player=new ItemRewardsIntegration().add(server,UUID.randomUUID());player.setPos(100,200,100);
  check(suggestions("raidadmin evento ").containsAll(List.of("shiny","ivs","drop","token","elemental","invasao","dupla","votacao","cancelar","reload")),"TAB enumerates staff events instead of a generic greedy argument");
  check(suggestions("raidadmin evento elemental ").containsAll(List.of("fogo","water","dragon")),"Elemental TAB suggests translated and native types");
  check(suggestions("raidadmin evento ivs ").equals(List.of("1","2","3","4","5","6")),"IV TAB suggests only 1 through 6");
  check(suggestions("raidadmin evento shiny ").contains("10%"),"Shiny TAB supplies percentage examples");check(suggestions("raidadmin evento drop ").contains("2"),"Drop TAB supplies multipliers");
  check(suggestions("raidadmin proxima ").containsAll(RaidCatalogSettings.ORDER),"Next rarity TAB lists all five categories");check(suggestions("raidadmin iniciar ").containsAll(RaidCatalogSettings.ORDER)&&suggestions("raidadmin iniciar ").contains("rayquaza"),"Start TAB merges rarities and existing manual boss IDs");
  check(suggestions("raidadmin evento dupla normal ").containsAll(RaidCatalogSettings.ORDER),"Duo second rarity TAB works");check(!suggestions("raidadmin evento votacao ").isEmpty(),"Vote setup suggests actual eligible species");
  var dispatcher=server.getCommands().getDispatcher();var source=player.createCommandSourceStack().withPermission(0);check(!dispatcher.getRoot().getChild("raidadmin").canUse(source),"Staff command root is excluded from the ordinary client command tree");
  check(dispatcher.getRoot().getChild("raid").getChild("evento")==null&&dispatcher.getRoot().getChild("raid").getChild("eventos")==null,"No administrative or inspection event branches remain under public /raid");
  try{dispatcher.execute("raidadmin evento drop 2",source);throw new AssertionError("Admin bypass");}catch(com.mojang.brigadier.exceptions.CommandSyntaxException expected){check(true,"Nonstaff cannot execute administration commands");}
  check(command("raidadmin eventos")==1,"Staff can inspect queued events");
  var vote=new RaidEventState.Vote();vote.options=List.of("cobblemon:charizard","cobblemon:gyarados");vote.ends=System.currentTimeMillis()+60000;state.events.vote=vote;check(suggestions("raid votar ").equals(List.of("1","2")),"Public voting TAB lists only currently available options");check(dispatcher.execute("raid votar 1",source)==1,"Public vote remains usable without OP");state.events.vote=null;
  var text=RaidEvents.text("Teste de evento");check(text.getString().startsWith("✦ ZORYKAI RAID » "),"Event chat uses the native Zorykai prefix");check(!text.getString().contains("[Zorykai Raid]"),"Old plain square-bracket prefix removed");
  var custom=new HashMap<>(RaidMessages.load(Path.of("config/shirokai-raids/messages.json")));custom.put("chat.prefixo","&9STAFF &8» &f{texto}");RaidMessages.install(custom);check(RaidEvents.text("Aviso").getString().equals("STAFF » Aviso"),"Chat honors existing configured prefix, not a second hard-coded brand");RaidMessages.install(RaidMessages.load(Path.of("config/shirokai-raids/messages.json")));
  int beforeSettings=broadcasts.size();command("raidadmin evento shiny 10%");command("raidadmin evento token 2");command("raidadmin evento token 3");check(broadcasts.size()==beforeSettings,"Changing event settings sends private staff feedback, no public chat burst");
  var cfg=(RaidConfig)RaidEvents.get(mod,"config");cfg.spawnConfigured=true;cfg.automaticRaids=true;cfg.x=0;cfg.y=200;cfg.z=0;cfg.maxConcurrentPlayers=1;
  state.nextRaid=System.currentTimeMillis()+7200000;state.events.next.shiny=.1;state.events.next.tokens=2;
  RaidEventPresentation.reset();RaidEvents.call(mod,"updateCountdown",new Class<?>[]{long.class},System.currentTimeMillis());var bar=(ServerBossEvent)RaidEvents.get(mod,"countdownBar");
  check(bar.getName().getString().contains("Chuva de Shinies")&&bar.getName().getString().contains(" em "),"Original countdown bar displays queued event and time to next raid");check(bar.getName().getString().startsWith("✦ ZORYKAI RAID |"),"Bossbar default layout matches Zorykai brand and separator");
  float progress=bar.getProgress();var viewers=Set.copyOf(bar.getPlayers());var normal=Component.literal("NORMAL CUSTOM TITLE");RaidEventPresentation.reset();long now=System.currentTimeMillis();
  check(RaidEventPresentation.title(normal,mod,now).getString().contains("Chuva de Shinies"),"Event starts with a visible notice window");check(RaidEventPresentation.title(normal,mod,now+4000)==normal,"After four seconds, returns exact original title object");check(RaidEventPresentation.title(normal,mod,now+12000).getString().contains("Fortuna de Tokens"),"Multiple events rotate without a huge combined title");check(bar.getProgress()==progress&&Set.copyOf(bar.getPlayers()).equals(viewers),"Presentation leaves progress, color/ownership and audience intact");
  int beforeCancel=broadcasts.size();command("raidadmin evento cancelar");check(broadcasts.size()==beforeCancel,"Cancelling unannounced future modifiers does not broadcast a public wall of text");check(RaidEventPresentation.title(normal,mod,now+13000)==normal,"Cancel immediately restores normal title");
  check(command("raidadmin evento shiny 100%")==1&&command("raidadmin iniciar normal")==1,"Relocated commands start actual event raid");var active=RaidEvents.get(mod,"active");var activeBar=(ServerBossEvent)RaidEvents.get(active,"bar");RaidEventPresentation.reset();RaidEvents.call(mod,"tick",new Class<?>[0]);
  check(RaidEventPresentation.title(normal,mod,System.currentTimeMillis()).getString().contains("Termina em"),"Active boss event shows remaining raid duration, not next-start time");
  // Force the real main tick to update its HP title setter, proving the second ASM hook.
  var f=mod.getClass().getDeclaredField("tick");f.setAccessible(true);f.setLong(mod,19);RaidEventPresentation.reset();RaidEvents.call(mod,"tick",new Class<?>[0]);check(activeBar.getName().getString().contains("Chuva de Shinies"),"Original active HP bar setter receives event presentation hook");
  RaidEvents.call(mod,"finish",new Class<?>[]{RaidArchive.Outcome.class,String.class},RaidArchive.Outcome.CANCELLED,"");
  check(command("raidadmin iniciar rayquaza")==1,"Existing manual boss-ID start syntax preserved after command tree replacement");RaidEvents.call(mod,"finish",new Class<?>[]{RaidArchive.Outcome.class,String.class},RaidArchive.Outcome.CANCELLED,"");
  var settings=RaidRewardSettings.defaults();settings.integrations.legacyItems=false;settings.top3.chances.put("normal",List.of(0d,0d,0d));var held=new RaidRewardSettings.Reward("display_held","item","cobblemon:choice_band",3,3);held.chance=1;held.baseMultiplier=1;held.damageMultiplier=0;var candy=new RaidRewardSettings.Reward("display_candy","item","cobblemon:exp_candy_l",5,5);candy.chance=1;settings.general.pools.put("normal",List.of(held,candy));
  var data=new RaidRewardJournal.Data();var journal=new RaidRewardJournal(data,()->{},Runnable::run,s->{});String[] raids=new String[3];for(int i=0;i<3;i++){raids[i]=UUID.randomUUID().toString();journal.award(raids[i],"probe","normal",100,List.of(new RaidDamageTracker.Entry(player.getUUID(),"P",100,1,1,Set.of())),settings,new Random(2));}
  for(int i=0;i<3;i++){final String id=raids[i];long count=data.grants.values().stream().filter(g->g.raid.equals(id)&&g.choice.reward.reference.equals(held.reference)).count();check(count==(i==1?0:1),"Held award cadence for eligible victory "+(i+1));}
  check(data.grants.values().stream().filter(g->g.choice.reward.reference.equals(held.reference)).allMatch(g->g.choice.amount.intValueExact()==1),"A held prize is at most one unit, not a stack");check(data.grants.values().stream().filter(g->g.choice.reward.reference.equals(candy.reference)).count()==3,"Consumables continue dropping every eligible raid");
  var restored=JsonFiles.copy(data,RaidRewardJournal.Data.class);restored.validate();check(restored.heldHistory.equals(data.heldHistory),"Cooldown history survives actual state serialization");
  // Real legacy hook: two wins with weighted table forced to a held item.
  var productionSettings=(RaidRewardSettings)RaidEvents.get(mod,"rewardSettings");productionSettings.integrations.legacyItems=true;productionSettings.general.pools.replaceAll((k,v)->List.of());productionSettings.special.pools.replaceAll((k,v)->List.of());
  for(int i=0;i<3;i++){
   command("raidadmin iniciar normal");active=RaidEvents.get(mod,"active");var table=(RaidConfig.Rewards)RaidEvents.get(active,"legacyRewards");table.tiers=null;table.itemPools=null;table.minimumContribution=.01;table.items=List.of(new RaidConfig.Reward(held.reference,3,3,1));
   var damage=(RaidDamageTracker)RaidEvents.get(active,"damage");var definition=(RaidConfig.Boss)RaidEvents.get(active,"definition");damage.record(player.getUUID(),"P",UUID.randomUUID(),definition.hp,System.currentTimeMillis());String id=(String)RaidEvents.get(active,"id");RaidEvents.call(mod,"finish",new Class<?>[]{RaidArchive.Outcome.class,String.class},RaidArchive.Outcome.VICTORY,"");RaidEvents.call(mod,"cancelVictory",new Class<?>[0]);
   var pending=state.pending.getOrDefault(player.getUUID().toString(),List.of()).stream().filter(p->p.raid.equals(id)&&p.item.equals(held.reference)).toList();check(pending.size()==(i==1?0:1)&&pending.stream().allMatch(p->p.count==1),"Legacy weighted reward shares held cooldown and one-unit rule: "+(i+1));
  }
  RaidEvents.save(mod);
 }
 public void onInitialize(){ServerMessageEvents.GAME_MESSAGE.register((s,message,overlay)->broadcasts.add(message.getString()));ServerTickEvents.END_SERVER_TICK.register(s->{if(done||++ticks!=40)return;server=s;done=true;var result=new com.google.gson.JsonObject();try{tick();result.addProperty("passed",true);}catch(Throwable e){e.printStackTrace();result.addProperty("passed",false);result.addProperty("error",e.toString());}result.addProperty("checks",checks);result.add("assertions",new com.google.gson.Gson().toJsonTree(assertions));try{Files.writeString(Path.of("event-display-results.json"),new com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(result));}catch(Exception e){throw new RuntimeException(e);}s.halt(false);});}
}
