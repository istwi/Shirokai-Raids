package com.shirokai.raids;

import java.util.*;
import net.minecraft.network.chat.Component;

/** Changes only a title on an already-owned bar; never creates a bar or changes its viewers/progress. */
final class RaidEventPresentation {
    private static String key="";
    private static long since;
    record Notice(String key,List<String> events,long deadline,boolean running,boolean waiting) {}
    static void reset(){key="";since=0;}
    static List<String> names(RaidEventPlan p){
        var names=new ArrayList<String>();if(p==null)return names;
        if(p.shiny>=0)names.add("Chuva de Shinies ("+java.math.BigDecimal.valueOf(p.shiny*100).stripTrailingZeros().toPlainString()+"%"+")");
        if(p.perfectIvs>0)names.add("Genética Perfeita ("+p.perfectIvs+" IVs)");
        if(p.drop!=1)names.add("Caçada Recompensada ("+p.drop+"x)");
        if(p.tokens!=1)names.add("Fortuna de Tokens ("+p.tokens+"x)");
        if(p.invasion)names.add("Invasão Lendária");
        if(!p.element.isEmpty())names.add("Raid Elemental ("+p.element+")");
        if(p.rage)names.add("Boss Enfurecido");
        if(p.duo)names.add("Dupla Ameaça ("+p.stage+"/2)");
        return List.copyOf(names);
    }
    static boolean eventWindow(long elapsed,int eventSeconds,int normalSeconds){return Math.floorMod(Math.max(0,elapsed)/1000,(long)eventSeconds+normalSeconds)<eventSeconds;}
    static int eventIndex(long elapsed,int eventSeconds,int normalSeconds,int count){return (int)((Math.max(0,elapsed)/1000/((long)eventSeconds+normalSeconds))%count);}
    private static Notice notice(ShirokaiRaids mod){
        var active=RaidEvents.get(mod,"active");
        if(active!=null){var boss=(RaidConfig.Boss)RaidEvents.get(active,"definition");var names=names(boss.event);return names.isEmpty()?null:new Notice("active:"+RaidEvents.get(active,"id"),names,(long)RaidEvents.get(active,"ends"),true,false);}
        var state=RaidEvents.state(mod);var e=state.events;
        if(e.vote!=null)return new Notice("vote:"+e.vote.ends,List.of("Votação da comunidade"),e.vote.ends,true,false);
        if(e.second!=null&&e.chainRaid.isEmpty())return new Notice("duo:"+e.second.chainId+":"+e.safeSince,List.of("Dupla Ameaça (2/2)"),e.safeSince==0?0:e.safeSince+RaidEvents.duoDelaySeconds()*1000L,false,e.safeSince==0);
        var names=names(e.next);return names.isEmpty()?null:new Notice("next:"+e.next.describe(),names,state.nextRaid,false,false);
    }
    /** Called from both original countdown/HP setters, with the original Component already built. */
    static Component title(Component normal,ShirokaiRaids mod){return title(normal,mod,System.currentTimeMillis());}
    static Component title(Component normal,ShirokaiRaids mod,long now){
        var notice=notice(mod);
        if(notice==null){reset();return normal;}
        if(!notice.key.equals(key)){key=notice.key;since=now;}
        long elapsed=Math.max(0,now-since);int eventSeconds=RaidEvents.eventBarSeconds(),normalSeconds=RaidEvents.normalBarSeconds();
        if(!eventWindow(elapsed,eventSeconds,normalSeconds))return normal;
        String name=notice.events.get(eventIndex(elapsed,eventSeconds,normalSeconds,notice.events.size()));
        String template=notice.waiting?"bossbar.evento.aguardando":notice.running?"bossbar.evento.ativo":"bossbar.evento.proximo";
        return RaidMessages.component(RaidMessages.msg(template,"evento",name,"tempo",RaidTime.format(Math.max(0,(notice.deadline-now+999)/1000))));
    }
}
